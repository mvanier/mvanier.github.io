/*
 * FILE: load.c
 *
 */

#include "xview_ext.h"

int
GetaRecord()
{
    int     i;
    char   *charptr;
    short  *shortptr;
    int    *intptr;
    double *doubleptr;

    if (((int)fread((char *)tmpdata, V->datasize, V->cellnum, fp))
        != V->cellnum)
    {
        return 0;
    }

    switch (V->datatype)
    {
    case CHAR:
        charptr = (char *)tmpdata;

        for (i = 0; i < V->cellnum; i++)
            curdata[i] = (float)(charptr[i]);

        break;

    case INT:
        intptr = (int *)tmpdata;

        for (i = 0; i < V->cellnum; i++)
            curdata[i] = (float)intptr[i];

        break;

    case SHORT:
        shortptr = (short *)tmpdata;

        for (i = 0; i < V->cellnum; i++)
            curdata[i] = (float)shortptr[i];

        break;

    case FLOAT:
        for (i = 0; i < V->cellnum; i++)
            curdata[i] = (float)tmpdata[i];

        break;

    case DOUBLE:
        doubleptr = (double *)tmpdata;

        for (i = 0; i < V->cellnum; i++)
            curdata[i] = (float)doubleptr[i];

        break;

    default:
        return 0;
    }

    /*
     * transfer the type specific data into the generic
     * data array
     */

    if (cumulative)
    {
        if (!backup)
        {
            for (i = 0; i < V->cellnum; i++)
                data[i] += curdata[i];
        }
    }
    else
    {
        for (i = 0; i < V->cellnum; i++)
            data[i] = curdata[i];
    }

    return 1;
}


void
NormalizeData()
{
    float   val;
    float   lower, upper;
    int     i;

    imageptr = image;

    for (i = 0; i < V->cellnum; i++)
    {
        /* Normalize the data using the scale factor. */
        if (posneg)
        {
            if (data[i] >= 0)
            {
                lower = max(minval, 0);
                val = data[i] / (maxval - lower);
                imageptr->sign = 1;
            }
            else
            {
                upper = min(maxval, 0);
                val = -data[i] / (upper - minval);
                imageptr->sign = -1;
            }

            /* Enforce upper and lower bounds. */
            val = max(val, 0);
            val = min(val, 1);
        }
        else
        {
            val = (data[i] - minval) / scale;

            /* Enforce upper and lower bounds. */
            val = max(val, 0);
            val = min(val, 1);
            imageptr->sign = 1;
        }

        imageptr->value = val;
        imageptr++;
    }
}


void
LoadNextFrame()
{
    /* Read in the next record. */
    if (!GetaRecord())
    {
        V->singlestep = TRUE;
    }

    /* Convert the data into a normalized form */
    NormalizeData();
}



/* GetFrame() returns 0 on failure and 1 on success. */

int
GetFrame(float time)
{
    int record;

    if (time < V->start_time)
    {
        V->singlestep = TRUE;
        return 0;
    }

    /*
     * Find the location in the data file of the specified time.
     * MAYBE-FIXME: this seems very inefficient, because it scans
     * the whole file for every frame EVERY time it's displayed.
     * How fast is fseek?
     */

    record = (time - V->start_time) / V->dt + 0.5;
    fseek(fp,
          (long)(V->headersize + V->cellnum * record * V->datasize),
          SEEK_SET);

    /* Read in the record. */
    if (!GetaRecord())
    {
        V->singlestep = TRUE;
        return 0;
    }

    if (autoscale == 2)
        do_frame_autoscale();

    /* Convert the data into a normalized form */
    NormalizeData();
    return 1;
}


/*
 * GetNFrames(): calculate the total number of frames in the data file.
 */

void
GetNFrames()
{
    int count = 0;

    /* Start with the first record */
    fseek(fp, (long)V->headersize, SEEK_SET);

    /* Read in a record at a time until there are no more. */
    while (GetaRecord())
        count++;

    V->nframes = count;
}


void
ReadCommandFile(int source, char *filename)
{
    FILE *fp;
    char  line[1001];

    if (source == 0)
    {
        /*
         * open the data file associated with the plot
         */
        if (strcmp(filename, "STDIN") == 0)
        {
            fp = stdin;
        }
        else if ((fp = fopen(filename, "r")) == NULL)
        {
            printf("can't open file '%s'\n", filename);
            return;
        }

        /*
         * read the data source file
         */
        while (!feof(fp))
        {
            /*
             * read a line from the data file
             */
            if (fgets(line, 1000, fp) == NULL)
            {
                break;
            }

            line[1000] = '\0';
            DoCommand(line);
        }
        fclose(fp);
    }
    else
    {
        DoCommand(filename);
    }
}


void
DoCommand(char *lineptr)
{
    do
    {
        if (lineptr[0] == ';')
        {
            lineptr++;

            /* skip white space */
            while (lineptr && *lineptr == ' ')
            {
                if (*lineptr == '\0' || *lineptr == '\n')
                    break;
                lineptr++;
            }
        }

        /* check to see if it is a plot command */

        if (lineptr[0] == '/')
        {
            InterpretCommand(lineptr);
            RefreshXview();
        }

        if (*lineptr == '\0')
            break;
    }
    while ((lineptr = strchr(lineptr + 1, ';')));
}
