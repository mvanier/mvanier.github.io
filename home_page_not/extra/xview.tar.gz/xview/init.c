/*
 * FILE: init.c
 *
 */

#include    "xview_ext.h"
#include    <X11/cursorfont.h>
#include    <X11/Xutil.h>

static int typeadjust = 0;

void
adjusttype(int x)
{
    typeadjust = x;
}


void
FileInit()
{
    int ival;

    zbase_size = ybase_size * 8;

    if (!V->plain)
    {
        fread(&ival, sizeof(int), 1, fp);

        if (V->xmax < 0)
            V->xmax = ival;

        fread(&ival, sizeof(int), 1, fp);

        if (V->ymax < 0)
            V->ymax = ival;

        fread(&V->dt, sizeof(float), 1, fp);
        fread(&V->datatype, sizeof(int), 1, fp);
        V->headersize = 3 * sizeof(int) + sizeof(float);
    }

    V->view_time = V->start_time = 0.0;
    V->view_step = V->dt;

    V->datatype += typeadjust;
    V->cellnum = (V->xmax + 1) * (V->ymax + 1);

    switch (V->datatype)
    {
    case CHAR:
        V->datasize = sizeof(char);
        break;

    case SHORT:
        V->datasize = sizeof(short);
        break;

    case INT:
        V->datasize = sizeof(int);
        break;

    case FLOAT:
        V->datasize = sizeof(float);
        break;

    case DOUBLE:
        V->datasize = sizeof(double);
        break;
    }

    data    = (float *)calloc(V->cellnum, sizeof(float));
    curdata = (float *)calloc(V->cellnum, sizeof(float));
    tmpdata = (float *)calloc(V->cellnum, sizeof(float));
    image   = (struct image_type *)calloc(V->cellnum,
                                          sizeof(struct image_type));

    if (autoscale)
        do_autoscale(fp);

    /* Calculate the total number of frames in the datafile. */
    GetNFrames();
}


void
InitX(char *display_name)
{
    /* Open the display. */
    G->display = XOpenDisplay(display_name);

    if (G->display == NULL)
    {
        fprintf(stderr, "Unable to open X display [%s]\n", display_name);
        exit(1);
    }

    if (debug)
    {
        /*
         * Force all calls to complete before returning;
         * this synchronizes errors with the routines that invoked them.
         */
        XSynchronize(G->display, 1);
    }

    /* Use the default screen. */
    G->screen_number = XDefaultScreen(G->display);

    /* Use the default visual. */
    G->visual = XDefaultVisual(G->display, G->screen_number);

    /* Use the default context. */
    G->context = XDefaultGC(G->display, G->screen_number);

    /* Determine whether or not color can be displayed. */
    if (XDisplayPlanes(G->display, G->screen_number) < 2)
        color_mode = 0;

    /* Create the colormap. */
    if (color_mode)
        MakeColormap();

    /* Set the foreground and background. */
    SetBackground();
    SetForeground();
    SetPSInverse(0);

    /* Select the font. */
    SetFont(G->font_string);

    /* Select the cursor. */
    XCreateFontCursor(G->display, XC_left_ptr);

    /* Create the windows. */
    CreateWindows();

    /* Use the window as the drawable. */
    G->drawable = G->imagewindow;

    /* Make sure it all got to the server. */
    XFlush(G->display);

    /* Refresh the display. */
    SetViewTime(V->init_time);
    DisplayView();
    RefreshXview();
}


void
CreateWindows()
{
    int     width;
    int     height;
    int     x;
    int     y;
    unsigned long border;
    unsigned long background;
    XWindowAttributes winfo;
    Window  root_window;
    int     borderwidth;
    XSizeHints hints;
    XSetWindowAttributes attrib;
    int     status;

    /*
     * Get the root window and its attributes.
     */
    root_window = XRootWindow(G->display, G->screen_number);
    XGetWindowAttributes(G->display, root_window, &winfo);
    status = 0;

    if (strlen(geometry) != 0)
    {
        status = XParseGeometry(geometry, &x, &y, &width, &height);

        if (!(status & XValue))
            x = winfo.width / 10;

        if (!(status & YValue))
            y = winfo.height / 10;

        if (!(status & WidthValue))
        {
            if (V->ymax > V->xmax)
            {
                width = ((float)(V->xmax + 1) / (V->ymax + 1))
                    * winfo.height / 3.0;
            }
            else
            {
                width = winfo.height / 3.0;
            }
        }

        if (!(status & HeightValue))
        {
            if (V->ymax > V->xmax)
            {
                height = winfo.height / 3.0 + 5 * G->fontheight;
            }
            else
            {
                height = ((float)(V->ymax + 1) / (V->xmax + 1))
                    * winfo.height / 3.0
                    + 5 * G->fontheight;
            }
        }

    }
    else
    {
        x = winfo.width / 10;
        y = winfo.height / 10;

        if (V->ymax > V->xmax)
        {
            width = ((float)(V->xmax + 1) / (V->ymax + 1))
                * winfo.height / 3.0;
            height = winfo.height / 3.0 + 5 * G->fontheight;
        }
        else
        {
            height = ((float)(V->ymax + 1) / (V->xmax + 1))
                * winfo.height / 3.0
                + 5 * G->fontheight;
            width = winfo.height / 3.0;
        }
    }

    borderwidth = 1;
    border = G->foreground;
    background = G->background;

    /*
     * create the image window
     */
    G->imagewindow = (Window) XCreateSimpleWindow(
        G->display, root_window, x, y, width, height,
        borderwidth, border, background);

    attrib.backing_store = WhenMapped;
    XChangeWindowAttributes(G->display,
                            G->imagewindow, CWBackingStore, &attrib);

    /*
     * request that the window be notified of certain events
     */
    XSelectInput(G->display, G->imagewindow,
                 KeyPressMask | ExposureMask | ButtonPressMask);

    /*
     * set the standard properties of the window
     */
    hints.flags = 0L;

    if (status & XValue)
    {
        hints.flags |= PPosition;
        hints.flags |= USPosition;
        hints.x = x;
    }

    if (status & YValue)
    {
        hints.flags |= PPosition;
        hints.flags |= USPosition;
        hints.y = y;
    }

    if (status & WidthValue)
    {
        hints.flags |= PSize;
        hints.flags |= USSize;
        hints.width = width;
    }

    if (status & HeightValue)
    {
        hints.flags |= PSize;
        hints.flags |= USSize;
        hints.height = height;
    }


    XSetStandardProperties(G->display, G->imagewindow,
                           V->filename,     /* window name */
                           V->filename,     /* icon name */
                           None,            /* icon pixmap */
                           NULL,            /* command argv */
                           0,               /* command argc */
                           &hints           /* window sizing hints */
        );

    /* Make the window visible. */
    if (G->mapped)
        XMapWindow(G->display, G->imagewindow);
}


void
Quit()
{
    char *tmpname = "/tmp/xview.plot";  /* Temporary xplot file name. */
    char  comstr[1000];

    XDestroyWindow(G->display, G->imagewindow);
    XCloseDisplay(G->display);

    /*
     * If any temporary files have been generated, remove them.
     * NOTE: this is not guaranteed to be portable across all Unices.
     */

    sprintf(comstr, "if [ -f %s ]; then rm %s; fi &", tmpname, tmpname);
    system(comstr);

    exit(0);
}
