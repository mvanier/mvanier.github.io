/*
 * FILE: xview_struct.h
 *
 */

#ifndef XVIEW_STRUCT_H
#define XVIEW_STRUCT_H


typedef struct
{
    short   x, y;
}
Coord;


typedef struct
{
    float   x, y;
}
FCoord;


typedef struct
{
    float x, y, z;
}
Point;


typedef struct
{
    Point   p1, p2, p3;
    float   a, b, c, d;
    float   zmin, zmax;
}
Plane;


typedef struct
{
    Point   p1, p2;
    float   a, b, c;
    int     infinite;
}
Line;


typedef struct
image_type
{
    float   value;
    short   sign;
}
Image;


typedef struct
{
    int ncontours;
    float value[MAXCONTOURS];
}
ContourList;


typedef struct
{
    Display        *display;
    GC              context;
    Drawable        drawable;
    Visual         *visual;
    int             screen_number;
    Font            font;
    XFontStruct    *fontinfo;
    Window          imagewindow;
    int             wwidth;
    int             wheight;
    int             fontheight;
    int             fontwidth;
    int             linewidth;
    unsigned long   background;
    unsigned long   foreground;
    unsigned long   color;
    int             scale_type;
    int             mapped;
    /* print_labels:
     *  1: print everything
     *  0: print only time and colorbar
     * -1: print only colorbar
     */
    short           print_labels;
    char            font_string[100];
}
GlobalContext;


typedef struct
{
    char   *filename;
    int     headersize;
    float   start_time;
    float   init_time;      /* Time to start the display at.    */
    float   end_time;       /* Don't display past this time.    */
    short   init_run_mode;  /* Flag: if 1; start animation immediately. */
    float   dt;
    int     xmax;
    int     ymax;
    int     cellnum;
    int     datatype;
    int     datasize;
    float   view_time;
    float   view_step;
    int     display_mode;
    int     singlestep;
    int     nframes;        /* Total number of frames in data.  */
    int     reverse;        /* For reverse animation.           */
    int     plain;
    int     valid_frame;
}
ViewContext;


#endif  /* XVIEW_STRUCT_H */

