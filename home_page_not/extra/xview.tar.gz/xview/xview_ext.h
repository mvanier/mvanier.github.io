/*
 * FILE: xview_ext.h
 *
 */

#ifndef XVIEW_EXT_H
#define XVIEW_EXT_H

#include    <stdio.h>
#include    <math.h>
#include    <stdlib.h>
#include    <string.h>
#include    <unistd.h>
#include    <assert.h>

#include    <X11/Xlib.h>
#include    "header.h"
#include    "xview_defs.h"
#include    "xview_struct.h"

/*
 * Global variables.
 */

extern  Display        *x_display;
extern  FILE           *fp;
extern  Image          *image, *imageptr;
extern  GlobalContext  *G;
extern  ViewContext    *V;
extern  XColor          color[MAX_COLORS];

extern  char    ch[80],
                fname[80],
                numstr[20],
                xplot_prefix_filename[1000],
                timestr[20],
                title[MAXTITLES][100],
                valstr[20],
               *command_file,
               *display,
                geometry[120],
              **global_envp;

extern int      pixel[MAX_COLORS],
                autoscale,
                background,
                backup,
                cell,
                col,
                command,
                commandsource,
                debug,
                display_mode,
                foreground,
                got_signal,
                height,
                indx,
                in_pipe,
                legend_base,
                line_width,
                mod,
                ncontours,
                out_pipe,
                pipe_step,
                placed,
                recnum,
                show,
                signal_step,
                waitval,
                width,
                xbase_size,
                yb,
                ybase_size,
                zbase_size;

extern float   *curdata,
               *data,
               *tmpdata,
                base,
                color_min,
                color_scale,
                count,
                dscale,
                inc,
                lscale,
                maxval,
                minval,
                scale,
                val,
                xs,
                xsize,
                ys,
                ysize,
                zsize;

extern  short   colorbar_flag,
                color_mode,
                cumulative,
                header,
                manual_xsize,
                manual_ysize,
                no_lines,
                ntitles,
                orient,
                posneg,
                ps_color,
                representation,
                signal_flag,
                speed,
                title_mode,
                use_xplot_prefix_file;

extern unsigned long speed_increment;


/*
 * Function declarations.
 */

extern void   BackStep();
extern void   Bell(int vol);
extern void   Box(int xl, int yb, int xr, int yt);
extern void   ButtonAction();
extern void   ClearImage();
extern void   ClearTitle();
extern void   ClearWindow();
extern int    ColorMap();
extern void   CoordAlloc(int xmax, int ymax);
extern void   CoordFree();
extern void   CreateWindows();
extern void   DebugX(char *s);
extern void   DisplayFrame();
extern void   DisplayNextFrame();
extern void   DisplayLocation(int x, int y);
extern void   DisplayView();
extern void   DoCommand(char *lineptr);
extern void   DoContours(Point p1, Point p2, Point p3,
                         ContourList *contour_list);
extern void   DrawBorder();
extern void   DrawBox(Image *image, float xsize, float ysize,
                      int xmax, int ymax);
extern void   DrawColorBar();
extern void   DrawColorBox(Image *image, float xsize, float ysize,
                           int xmax, int ymax);
extern void   DrawColorFilledSurface(Image *image, float xsize, float ysize,
                                     int xmax, int ymax);
extern void   DrawColorScale();
extern void   DrawColorSurface(Image *image, float xsize, float ysize,
                               int xmax, int ymax);
extern void   DrawContours(Image *image, float xsize, float ysize,
                           int xmax, int ymax, ContourList *contour_list);
extern void   DrawFilledBox(Image *image, float xsize, float ysize,
                            int xmax, int ymax);
extern void   DrawFilledSurface(Image *image, float xsize, float ysize,
                                int xmax, int ymax);
extern void   DrawLine(int x1, int y1, int x2, int y2);
extern void   DrawNumberBox(float xsize, float ysize,
                            int xmax, int ymax);
extern void   DrawSurface(Image *image, float xsize, float ysize,
                          int xmax, int ymax);
extern void   DumpColorMap();
extern void   DumpData();
extern void   EventLoop();
extern void   EventString();
extern void   FileInit();
extern void   FilledBox(int xl, int yb, int xr, int yt);
extern void   FilledPoly(Coord *coord, int ncoords);
extern void   FinishPS();
extern void   ForwardStep();
extern int    GetFrame(float time);
extern void   GetNFrames();
extern int    GetaRecord();
extern void   GraphCell(int x, int y, short fft);
extern void   Help();
extern void   HP(char *s);
extern void   IncrementViewTime(float inc);
extern void   InitX(char *display_name);
extern void   InterpretCommand();
extern void   KeyAction(XKeyEvent *event);
extern void   LoadNextFrame();
extern void   MakeColormap();
extern void   MakeContourList(int ncontours, float minval, float maxval,
                             ContourList *contour_list);
extern void   MatlabDump();
extern void   MultipleLines(Coord *coord, int ncoords);
extern void   NormalizeData();
extern void   ParseArgList(int argc, char **argv);
extern void   PlotData(int x, int y, int n, short fft);
extern void   PreparePS(Display *display, Window window,
                       float scale, int box, int header, short ps_header);
extern void   PrintOut();
extern void   PrintToFile(char *filename, char *mode, short first_page);
extern void   PSClosefill();
extern void   PSFont(int height);
extern void   PSHeader(XWindowAttributes *info,
                       float requested_scale, int box, int header,
                       short first_page);
extern void   PSLineto(int x, int y);
extern void   PSLinetoFloat(float x, float y);
extern void   PSMoveto(int x, int y);
extern void   PSMovetoFloat(float x, float y);
extern void   PSNewpath();
extern void   PSShow(char *s);
extern void   PSStroke();
extern void   PSSetColorPixel(float r, float g, float b);
extern void   PSSetLineWidth(int width);
extern void   PSSetPixel(Display *display, int pixel);
extern int    PSStatus();
extern void   PSTrailer();
extern void   Quit();
extern void   ReadCommandFile(int source, char *filename);
extern void   RefreshXview();
extern void   Rescale();
extern void   ScreenTransform(float x, float y, float z, Coord *coord);
extern void   SetBackground();
extern void   SetColor(int pixel);
extern void   SetFont(char *name);
extern void   SetForeground();
extern void   SetLineWidth(int width);
extern void   SetMaxGray(int val);
extern void   SetPlaneMask(int mask);
extern void   SetPSFileOutput(int state);
extern void   SetPSFilemode(char *mode);
extern void   SetPSFilename(char *name);
extern void   SetPSInverse(int state);
extern void   SetViewTime(float time);
extern void   Text(int x, int y, char *s);
extern void   TextExtent(char *s, int *height, int *width);
extern void   Usleep();
extern int    XLookupString();
extern void   XPSDrawLine(Display *display, Drawable drawable, GC context,
                          int x1, int y1, int x2, int y2);
extern void   XPSDrawLines(Display *display, Drawable drawable, GC context,
                           Coord *coord, int ncoords, int mode);
extern void   XPSDrawRectangle(Display *display, Drawable drawable,
                               GC context, int x, int y, int w, int h);
extern void   XPSDrawText(Display *display, Drawable drawable, GC context,
                          int x, int y, char *s);
extern void   XPSFillPolygon(Display *display, Drawable drawable, GC context,
                             Coord *coord, int ncoords, int shape, int mode);
extern void   XPSFillRectangle(Display *display, Drawable drawable,
                               GC context, int x, int y, int w, int h);
extern void   WorldTransform(Coord *coord, Coord *tcoord, int ncoords);
extern void   adjusttype(int x);
extern void   display_image();
extern void   do_autoscale();
extern void   do_frame_autoscale();
extern void   event_handler();
extern void   image_background();
extern void   legend_foreground();
extern void   legend_background();

#endif  /* XVIEW_EXT_H */


