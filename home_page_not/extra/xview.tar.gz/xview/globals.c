/*
 * FILE: globals.c
 *
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <strings.h>

#include <X11/Xlib.h>

#include "header.h"
#include "xview_defs.h"
#include "xview_struct.h"

/* FIXME: clean these up! */

/*
 * REALLY_FIXME: get rid of ALL globals!  Put them into a separate
 * xview_data struct or something.  This will make it possible to
 * control xview from e.g. python.
 */

XColor  color[MAX_COLORS];
int     line_width = 1;
char    numstr[80];
short   colorbar_flag = 1;   /* 1 = display color bar. */
short   ps_color      = 1;   /* 1 = use color Postscript. */
int     ncontours = 10;
short   cumulative;

char    fname[80],
        ch[80],
        valstr[20],
        timestr[20];

char   *command_file;
int     commandsource;
char   *display;
Image  *image;
Image  *imageptr;
float   ys, lscale, xs, dscale;
short   manual_xsize, manual_ysize;

float   xsize,
        ysize,
        zsize;

int     display_mode,
        legend_base,
        xbase_size,
        ybase_size,
        zbase_size,
        waitval,
        indx,
        height,
        width,
        placed,
        cell,
        yb,
        show,
        mod,
        autoscale = 1,
        command,
        recnum = 0,
        col = 0;

float   count,
        val,
        inc,
        maxval,
        minval,
        base,
        color_scale,
        color_min,
        scale,
       *tmpdata,
       *curdata,
       *data;

FILE   *fp;
int     debug;
int     backup;

short   representation;
short   title_mode;
char    title[MAXTITLES][100];
short   ntitles;
short   orient;
short   speed;
short   use_xplot_prefix_file;        /* flag */
char    xplot_prefix_filename[1000];
short   posneg;
char    geometry[120];
short   header;
int     signal_step, pipe_step;
short   signal_flag;
int     got_signal;
short   color_mode;
short   no_lines;
int     in_pipe, out_pipe;  /* Pipe file descriptors. */

unsigned long speed_increment;

GlobalContext  *G;
ViewContext    *V;
