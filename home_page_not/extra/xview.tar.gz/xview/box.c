/*
 * FILE: box.c
 *
 */

#include "xview_ext.h"

void
DrawColorBox(Image *image, float xsize, float ysize, int xmax, int ymax)
{
    Image  *imageptr;
    int     i, j;
    float   x, y;
    float   scale;

    imageptr = image + (xmax + 1) * (ymax + 1) - 1;

    for (j = 0; j <= ymax; j++)
    {
        for (i = xmax; i >= 0; i--)
        {
            x = xsize * i;
            y = yb + ysize * j;
            scale = color_scale * (imageptr->value) + color_min;
            SetColor((int)scale);

            /*
             * GAP puts a gap between the boxes.
             */

#undef GAP
#ifdef GAP
            FilledBox((int)x, (int)y,
                      (int)(x + xsize - 2 + 0.5),
                      (int)(y + ysize - 2 + 0.5));
#else
            FilledBox((int)x, (int)y,
                      (int)(x + xsize + 1),
                      (int)(y + ysize + 1));
#endif
            imageptr--;
        }
    }
}


void
DrawFilledBox(Image *image, float xsize, float ysize, int xmax, int ymax)
{
    Image  *imageptr;
    int     i, j;
    float   x, y;

    imageptr = image + (xmax + 1) * (ymax + 1) - 1;

    for (j = 0; j <= ymax; j++)
    {
        for (i = xmax; i >= 0; i--)
        {
            val = sqrt(imageptr->value);

            if (val < 0.0)
            {
                val = 0.0;
            }
            else if (val > 1)
            {
                val = 1.0;
            }

            x = xsize * i;
            y = yb + ysize * j;

            x += (xsize * (1 - val)) / 2;
            y += (ysize * (1 - val)) / 2; 

            SetColor(0);  /* Black. */

            FilledBox((int)x, (int)y,
                      x + (int)(val * xsize) + 1,
                      y + (int)(val * ysize) + 1);

            imageptr--;
        }
    }
}


void
DrawBox(Image *image, float xsize, float ysize, int xmax, int ymax)
{
    Image  *imageptr;
    int     i, j;
    float   x, y;

    imageptr = image + (xmax + 1) * (ymax + 1) - 1;

    for (j = 0; j <= ymax; j++)
    {
        for (i = xmax; i >= 0; i--)
        {
            val = sqrt(imageptr->value);

            if (val > 0)
            {
                x = xsize * i + (xsize * (1 - val)) / 2;
                y = yb + ysize * j + (ysize * (1 - val)) / 2;

                SetColor(0);  /* Black. */

                if (posneg && (imageptr->sign < 0))
                {
                    FilledBox((int)x, (int)y,
                        x + (int)(val * xsize),
                        y + (int)(val * ysize));
                }
                else
                {
                    Box((int)x, (int)y,
                        x + (int)(val * xsize),
                        y + (int)(val * ysize));
                }
            }

            imageptr--;
        }
    }
}


void
DrawNumberBox(float xsize, float ysize, int xmax, int ymax)
{
    int  i, j;
    int  x, y;
    char str[100];
    char comstr[10];
    int  n;
    int  w;

    SetColor((int)G->foreground);

    if ((w = (xsize - 4) / G->fontwidth) < 4)
        w = 4;

    sprintf(comstr, "%%%d.%dg", w, (w - 2) / 2);

    for (j = 0; j <= ymax; j++)
    {
        for (i = xmax; i >= 0; i--)
        {
            x = xsize * i;
            y = yb + ysize * j;
            n = (ymax - j) * (xmax + 1) + i;
            Box(x, y, x + (int)xsize, y + (int)ysize);
            sprintf(str, comstr, data[n]);
            Text(x + 4, y + (int)(ysize / 2), str);
        }
    }
}
