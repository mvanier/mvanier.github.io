/*
 * FILE: primitives.c
 *
 */

#include "xview_ext.h"

void
SetColor(int pixel)
{
    G->color = ColorMap(pixel);
    XSetForeground(G->display, G->context, (unsigned long)G->color);
}


void
SetForeground()
{
    G->foreground = ColorMap(XBlackPixel(G->display, G->screen_number));
    XSetForeground(G->display, G->context, (unsigned long)G->foreground);
}


void
SetBackground()
{
    G->background = WHITE;
    XSetBackground(G->display, G->context,
                   (unsigned long)G->background);
}


void
SetPlaneMask(int mask)
{
    XSetPlaneMask(G->display, G->context, (unsigned long)mask);
}


void
SetFont(char *name)
{
    G->font = XLoadFont(G->display, name);

    if (G->font == (Font)NULL)
    {
        fprintf(stderr, "unable to open text font");
        return;
    }

    G->fontinfo = XQueryFont(G->display, G->font);
    G->fontheight = G->fontinfo->ascent - G->fontinfo->descent;
    G->fontwidth = G->fontinfo->max_bounds.rbearing -
        G->fontinfo->min_bounds.lbearing;
    XSetFont(G->display, G->context, G->font);
}


void
SetLineWidth(int width)
{
    XGCValues values;

    G->linewidth = width;
    values.line_width = width;
    XChangeGC(G->display, G->context, GCLineWidth, &values);
}


void
TextExtent(char *s, int *height, int *width)
{
    int     ascent;
    int     descent;
    int     direction;
    XCharStruct overall;

    XTextExtents(G->fontinfo, s, strlen(s),
                 &direction, &ascent, &descent, &overall);
    *height = overall.ascent - overall.descent;
    *width = overall.width;
}


void
Text(int x, int y, char *s)
{
    XPSDrawText(G->display, G->drawable, G->context, x, y, s);
}


/*
 * xl = x left
 * xr = x right
 * yb = y bottom
 * yt = y top
 */

void
FilledBox(int xl, int yb, int xr, int yt)
{
    XPSFillRectangle(G->display, G->drawable, G->context,
                     xl, yb, xr - xl, yt - yb);
}


void
Box(int xl, int yb, int xr, int yt)
{
    XPSDrawRectangle(G->display, G->drawable, G->context,
                     xl, yb, xr - xl, yt - yb);
}


void
FilledPoly(Coord *coord, int ncoords)
{
    XPSFillPolygon(G->display, G->drawable, G->context,
                   coord, ncoords, Convex, CoordModeOrigin);
}


void
DrawLine(int x1, int y1, int x2, int y2)
{
    XPSDrawLine(G->display, G->drawable, G->context, x1, y1, x2, y2);
}


void
MultipleLines(Coord *coord, int ncoords)
{
    XPSDrawLines(G->display, G->drawable, G->context,
                 coord, ncoords, CoordModeOrigin);
}


void
ClearWindow()
{
    XClearWindow(G->display, G->imagewindow);
}


void
Bell(int vol)
{
    if (vol < -100)
        vol = -100;
    else if (vol > 100)
        vol = 100;

    XBell(G->display, vol);
}


void
DebugX(char *s)
{
    XEvent  E;

    fprintf(stderr, "%s\n", s);
    XNextEvent(G->display, &E);
    fprintf(stderr, "OK\n");
}
