/*
 * FILE: color.c
 *
 */

/*
 * carc color algorithm swiped from Walter Yamada 3/1/88
 * (Thanks Walter!)
 */

#include "xview_ext.h"

/*
 * This colormap algorithm uses three arcs to give the red, green, and
 * blue values.  The WI parameter is the width of the arc; it should
 * be about 1/4 of MAX_COLORS.  The 255.0 number reflects that the largest
 * intensity is 255.
 */

#define WI      63.0
#define arc(x)  (255.0 * sqrt(1.0 - (((x) - WI) / WI) * (((x) - WI) / WI)))
#define carc(x) (((0 <= (x)) && ((x) <= 2 * WI )) ? arc(x) : 0)


void
MakeColormap()
{
    int     i;
	int     last_color;  /* FIXME: a stupid hack!!! */
    float   scale, color_max;
    Colormap cmap;

    /*
     * N.B. color_min, and color_scale are global floats.
     * color_max is a float but not global. FIXME!!!!
     * This whole colormap scheme is a fucking mess!!!!
     */

    color_min   = 19.0;
    color_max   = (float)(MAX_COLORS - 1);
    color_scale = color_max - color_min;
    scale       = color_scale + 1.0;
    cmap        = DefaultColormap(G->display, G->screen_number);

    for (i = 0; i < ((int)color_min); i++)
    {
        color[i].pixel = i;
    }

    for (i = ((int)color_min); i <= ((int)color_max); i++)
    {
        /* Define RGB values. */

        switch (G->scale_type)
        {
        case SPECTRALSCALE:
            color[i].red
                = (int)(carc(i - color_min - 2 * scale / 3.5)) << 8;
            color[i].green
                = (int)(carc(i - color_min - scale / 3.5)) << 8;
            color[i].blue
                = (int)(carc((float)i - color_min)) << 8;
            break;

        case GRAYSCALE:
            color[i].red
                = (int)((i - color_min)
                        * ((MAX_COLORS - 1) - 50) / scale + 50) << 8;
            color[i].green
                = (int)((i - color_min)
                        * ((MAX_COLORS - 1) - 50) / scale + 50) << 8;
            color[i].blue
                = (int)((i - color_min)
                        * ((MAX_COLORS - 1) - 50) / scale + 50) << 8;
            break;

        case RGRAYSCALE:
            color[i].red
                = (int)((color_max - i)
                        * ((MAX_COLORS - 1) - 50) / scale + 50) << 8;
            color[i].green
                = (int)((color_max - i)
                        * ((MAX_COLORS - 1) - 50) / scale + 50) << 8;
            color[i].blue
                = (int)((color_max - i)
                        * ((MAX_COLORS - 1) - 50) / scale + 50) << 8;
            break;
        }

        color[i].flags = DoRed | DoGreen | DoBlue;
        XAllocColor(G->display, cmap, &color[i]);
    }


    /*
     * Set final color to white.  It's used for the background
     * color in a variety of contexts.
     */

    if (debug)
    {
		DumpColorMap();
    }

	last_color = MAX_COLORS - 1;
	color[last_color].red   = MAX_RGB_VALUE;
	color[last_color].green = MAX_RGB_VALUE;
	color[last_color].blue  = MAX_RGB_VALUE;

    XAllocColor(G->display, cmap, &color[last_color]);
}


int
ColorMap(int i)
{
    int val;

    if (PSStatus() == 1)
    {
        /* CHECKME: 225 should probably be changed... */
        val = (225 * (i - color_min + 2)) / (color_scale);

        if (val < 0)
            val = 0;

        if (val > MAX_COLORS)
            val = MAX_COLORS;

        return val;
    }
    else if (color_mode)
    {
//printf("i = %d\n", i);
        if (i > MAX_COLORS)
            i = MAX_COLORS;

        return color[i].pixel;
    }
    else
    {
        return i;
    }
}


void
DumpColorMap()
{
    int i;

    for (i = 0; i < MAX_COLORS; i++)
    {
        printf("COLOR[%d]: %d %d %d\n", i, 
               color[i].red, color[i].green, color[i].blue);
    }
}
