/*
 * FILE: scale.c
 *
 */

#include "xview_ext.h"

void
Rescale()
{
    XWindowAttributes winfo;

    if (header)
    {
        yb = G->fontheight * 3;
    }
    else
    {
        yb = 0;
    }

    XGetWindowAttributes(G->display, G->imagewindow, &winfo);

    G->wwidth = width = winfo.width;
    G->wheight = winfo.height;

    if (header)
    {
        height = G->wheight - (yb + 2 * G->fontheight);
    }
    else
    {
        height = winfo.height;
    }

    if (manual_xsize)
        xsize = xs;
    else
        xsize = (float)width / (V->xmax + 1);

    if (manual_ysize)
        ysize = ys;
    else
        ysize = (float)(height) / (V->ymax + 1);

    if (zsize == 0)
        zsize = ysize * 30;

    if (header)
    {
        legend_base = yb + height + G->fontheight + 3;
    }
    else
    {
        legend_base = 0;
    }
}


void
do_frame_autoscale()
{
    float  *dataptr;
    int     i;

    dataptr = data;
    maxval = *dataptr;
    minval = maxval;
    dataptr++;

    for (i = 1; i < V->cellnum; i++)
    {
        if (*dataptr > maxval)
            maxval = *dataptr;

        if (*dataptr < minval)
            minval = *dataptr;

        dataptr++;
    }

    if ((scale = maxval - minval) == 0)
    {
        scale = 1;
    }
}


void
do_autoscale(FILE * fp)
{
    float  *dataptr;
    int     i;

    maxval = -999;
    minval = 999;

    /*
     * calculate autoscale parameters
     */

    fseek(fp, (long)(V->headersize), 0);

    while (!feof(fp))
    {
        GetaRecord();
        dataptr = data;

        if (maxval < minval)
        {
            maxval = *dataptr;
            minval = maxval;
        }

        for (i = 0; i < V->cellnum; i++)
        {
            if (*dataptr > maxval)
                maxval = *dataptr;

            if (*dataptr < minval)
                minval = *dataptr;

            dataptr++;
        }
    }

    /*
     * go back to the beginning of the file
     */

    fseek(fp, (long)(V->headersize), 0);

    /*
     * clear the data
     */

    for (i = 0; i < V->cellnum; i++)
        data[i] = 0;

    if ((scale = maxval - minval) == 0)
    {
        scale = 1;
    }
}
