/*
 *      PSdriver
 *      X11 -> postscript library routines
 *      Copyright 1989  Matt Wilson
 *      California Institute of Technology
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation, and that the name of the California Institute
 * of Technology not be used in advertising or publicity pertaining to
 * distribution of the software without specific, written prior permission.
 * Neither the author nor California Institute of Technology make any
 * representations about the suitability of this software for any
 * purpose. It is provided "as is" without express or implied warranty.
 *
 * To use these functions
 * replace the X11 calls in your code with calls to the
 * comparable driver functions.
 * e.g. instead of
 *
 *   XDrawLine (display, drawable, context, x1, y1, x2, y2)
 *
 * use
 *
 *   XPSDrawLine (display, drawable, context, x1, y1, x2, y2)
 *
 *
 * Output can be directed to a file or directly to a printer using:
 *
 *   SetPSFileOutput(state)      1=file 0=printer
 *   SetPSFilename(name)
 *
 * To produce postscript output add this sequence of calls to your code:
 *
 *   PreparePS(display,window,scale,box,header);
 *   refresh_window(window);      your routine to refresh the screen
 *   FinishPS();
 *
 */

/* FIXME: can we please get rid of this? */
#define XLIB_ILLEGAL_ACCESS

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <signal.h>
#include <time.h>
#include <X11/Xlib.h>
#include "xview_ext.h"

#define XOUT    0
#define PSOUT   1


#define DEFAULTRES  72    /* Default user space coords are 1/72
                           * of an inch each.                    */
#define DPI         300
#define MAXCHUNK    10000
#define PAGEHEIGHT  11.0
#define PAGEWIDTH   8.5

static int          output_flag     = XOUT;
static FILE        *PSfp;
static int          global_window_height;
static int          global_window_width;
static float        pix_scale;
static float        page_scale;
static short        file_output     = 0;
static char        *ps_filename;
static char        *ps_filemode     = "w";
static int          current_gray    = -1;
static int          current_line    = -1;
static int          max_gray        = 256;
static int          inverse         = 1;
static XGCValues    gcr;    /* GC return value. */


int
PSStatus()
{
    return output_flag;
}


void
SetPSInverse(int state)
{
    inverse = state;
}


void
SetPSFilename(char *name)
{
    ps_filename = name;
}


void
SetPSFilemode(char *mode)
{
    ps_filemode = mode;
}


void
SetPSFileOutput(int state)
{
    file_output = state;
}


void
SetMaxGray(int val)
{
    max_gray = val;
}


float
ComputeGray(int pixel)
{
    return (1.0 - (float)pixel / max_gray);
}


void
PSSetPixel(Display *display, int pixel)
{
    /*
     * Only output a gray-level specification if the gray level
     * has changed.
     */

    if (pixel != current_gray)
    {
        current_gray = pixel;

        if (pixel == ((int)XBlackPixel(display, XDefaultScreen(display))))
        {
            fprintf(PSfp, "%d G\n", inverse);
        }
        else if (pixel == WHITE)
        {
            fprintf(PSfp, "%d G\n", !inverse);
        }
        else
        {
            fprintf(PSfp, "%5.3f G\n", ComputeGray(pixel));
        }
    }
}


void
PSSetColorPixel(float r, float g, float b)
{
    fprintf(PSfp, "%f %f %f K\n", r, g, b);
}


void
PSSetLineWidth(int width)
{
    if (width == 0)
        width = 1;

    if (current_line != width)
    {
        current_line = width;
        fprintf(PSfp, "%f setlinewidth\n", current_line / pix_scale);
    }
}


void
PSClosefill()
{
    fprintf(PSfp, "C\n");
}


void
PSNewpath()
{
    fprintf(PSfp, "N\n");
}


void
PSStroke()
{
    fprintf(PSfp, "S\n");
}


/*
 * NOTE: X uses a different coordinate scheme than Postscript, where y
 * coordinates go from top to bottom instead of from bottom to top.
 * In both systems x coordinates go from left to right.
 */

void
PSMoveto(int x, int y)
{
    fprintf(PSfp, "%d %d M\n", x, global_window_height - y);
}


void
PSLineto(int x, int y)
{
    fprintf(PSfp, "%d %d L\n", x, global_window_height - y);
}


void
PSMovetoFloat(float x, float y)
{
    fprintf(PSfp, "%g %g M\n", x, global_window_height - y);
}


void
PSLinetoFloat(float x, float y)
{
    fprintf(PSfp, "%g %g L\n", x, global_window_height - y);
}


void
PSShow(char *s)
{
    fprintf(PSfp, "(%s) show\n", s);
}


void
PSFont(int height)
{
    fprintf(PSfp, "/Helvetica findfont %d scalefont setfont\n", height);
}


void
XPSDrawText(Display *display, Drawable drawable, GC context,
            int x, int y, char *s)
{
    XFontStruct *finfo;
    int     height;

    if (output_flag == XOUT)
    {
        XDrawImageString(display, drawable, context, x, y, s, strlen(s));
    }
    else  /* Postscript output. */
    {
        finfo = XQueryFont(display, context->gid);
        height = finfo->ascent + finfo->descent;
        PSFont(height);
        PSMoveto(x, y);
        PSShow(s);
    }
}


void
XPSDrawLine(Display *display, Drawable drawable, GC context,
            int x1, int y1, int x2, int y2)
{
    XGCValues  *GC_return = &gcr;

    if (output_flag == XOUT)
    {
        XDrawLine(display, drawable, context, x1, y1, x2, y2);
    }
    else  /* Postscript output. */
    {
        /* Get the current foreground color from the graphics context. */

        /*PSSetPixel(display,context->values.foreground); */
        if (XGetGCValues(display, context, GCForeground, GC_return) == 0)
        {
            printf("XPSDrawline: could not get foreground value\n");
            return;
        }

        PSSetPixel(display, GC_return->foreground);

        /*PSSetLineWidth(context->values.line_width); */
        if (XGetGCValues(display, context, GCLineWidth, GC_return) == 0)
        {
            printf("XPSDrawline: could not get line width\n");
            return;
        }

        PSSetLineWidth(GC_return->line_width);

        PSNewpath();
        PSMoveto(x1, y1);
        PSLineto(x2, y2);
        PSStroke();
    }
}


void
XPSDrawLines(Display *display, Drawable drawable, GC context,
             Coord *coord, int ncoords, int mode)
{
    int         i;
    int         pcount;
    int         nchunks;
    int         chunksize;
    XGCValues  *GC_return = &gcr;

    if (output_flag == XOUT)
    {
        /*
         * Avoid the limit on the length of a multiple line vector
         * by doing it in multiple calls.
         */
        nchunks = (ncoords - 1) / MAXCHUNK + 1;

        for (i = 0; i < nchunks; i++)
        {
            if ((chunksize = ncoords - i * MAXCHUNK) > MAXCHUNK)
            {
                chunksize = MAXCHUNK;
            }

            /*
             * Draw one point past to connect this chunk with the
             * next.  Don't do it for the last chunk.
             */
            if (i < nchunks - 1)
                chunksize++;

            XDrawLines(display, drawable, context,
                       (XPoint *)(coord + i * MAXCHUNK), chunksize, mode);
        }
    }
    else  /* Postscript output. */
    {
        if (ncoords <= 0)
            return;

        PSNewpath();

        /*PSSetPixel(display,context->values.foreground); */
        if (XGetGCValues(display, context, GCForeground, GC_return) == 0)
        {
            printf("XPSDrawline: could not get foreground value\n");
            return;
        }

        PSSetPixel(display, GC_return->foreground);

        /*PSSetLineWidth(context->values.line_width); */
        if (XGetGCValues(display, context, GCLineWidth, GC_return) == 0)
        {
            printf("XPSDrawline: could not get line width\n");
            return;
        }

        PSSetLineWidth(GC_return->line_width);

        PSMoveto(coord[0].x, coord[0].y);
        pcount = 0;

        for (i = 1; i < ncoords; i++)
        {
            if ((coord[i].x == coord[i - 1].x)
                && (coord[i].y == coord[i - 1].y)
                && i < ncoords - 1)
            {
                continue;
            }

            PSLineto(coord[i].x, coord[i].y);

            /* Break it up into managable chunks. */
            if (pcount > 200)
            {
                PSStroke();
                PSNewpath();
                PSMoveto(coord[i].x, coord[i].y);
                pcount = 0;
            }

            pcount++;
        }

        PSStroke();
    }
}


void
XPSDrawLinesFloat(Display *display, Drawable drawable, GC context,
                  Coord *coord, int ncoords, int mode, FCoord *fcoord)
{
    int         i;
    int         pcount;
    int         nchunks;
    int         chunksize;
    XGCValues  *GC_return = &gcr;

    if (output_flag == XOUT)
    {
        /*
         * Avoid the limit on the length of a multiple line vector
         * by doing it in multiple calls.
         */
        nchunks = (ncoords - 1) / MAXCHUNK + 1;

        for (i = 0; i < nchunks; i++)
        {
            if ((chunksize = ncoords - i * MAXCHUNK) > MAXCHUNK)
            {
                chunksize = MAXCHUNK;
            }

            /*
             * Draw one point past to connect this chunk with the
             * next.  Don't do it for the last chunk.
             */
            if (i < nchunks - 1)
                chunksize++;

            XDrawLines(display, drawable, context,
                       (XPoint *)(coord + i * MAXCHUNK), chunksize, mode);
        }
    }
    else  /* Postscript output. */
    {
        if (ncoords <= 0)
            return;

        PSNewpath();

        /*PSSetPixel(display,context->values.foreground); */
        if (XGetGCValues(display, context, GCForeground, GC_return) == 0)
        {
            printf("XPSDrawline: could not get foreground value\n");
            return;
        }

        PSSetPixel(display, GC_return->foreground);

        /*PSSetLineWidth(context->values.line_width); */
        if (XGetGCValues(display, context, GCLineWidth, GC_return) == 0)
        {
            printf("XPSDrawline: could not get line width\n");
            return;
        }

        PSSetLineWidth(GC_return->line_width);

        PSMovetoFloat(fcoord[0].x, fcoord[0].y);
        pcount = 0;

        for (i = 1; i < ncoords; i++)
        {
            if ((fcoord[i].x == fcoord[i - 1].x)
                && (fcoord[i].y == fcoord[i - 1].y)
                && i < ncoords - 1)
            {
                continue;
            }

            PSLinetoFloat(fcoord[i].x, fcoord[i].y);

            /* Break it up into managable chunks. */
            if (pcount > 200)
            {
                PSStroke();
                PSNewpath();
                PSMovetoFloat(fcoord[i].x, fcoord[i].y);
                pcount = 0;
            }

            pcount++;
        }

        PSStroke();
    }
}


void
XPSDrawRectangle(Display *display, Drawable drawable, GC context,
                 int x, int y, int w, int h)
{
    XGCValues  *GC_return = &gcr;

    if (output_flag == XOUT)
    {
        XDrawRectangle(display, drawable, context, x, y, w, h);
    }
    else  /* Postscript output. */
    {
        /*PSSetPixel(display,context->values.foreground); */
        if (XGetGCValues(display, context, GCForeground, GC_return) == 0)
        {
            printf("XPSDrawline: could not get foreground value\n");
            return;
        }

        PSSetPixel(display, GC_return->foreground);

        /*PSSetLineWidth(context->values.line_width); */
        if (XGetGCValues(display, context, GCLineWidth, GC_return) == 0)
        {
            printf("XPSDrawline: could not get line width\n");
            return;
        }

        PSSetLineWidth(GC_return->line_width);

        PSNewpath();
        PSMoveto(x, y);
        PSLineto(x + w, y);
        PSLineto(x + w, y + h);
        PSLineto(x, y + h);
        PSLineto(x, y);
        PSStroke();
    }
}


void
XPSFillRectangle(Display *display, Drawable drawable, GC context,
                 int x, int y, int w, int h)
{
    XGCValues  *GC_return = &gcr;

    if (output_flag == XOUT)
    {
        XFillRectangle(display, drawable, context, x, y, w, h);
    }
    else  /* Postscript output. */
    {
        if (XGetGCValues(display, context, GCForeground, GC_return) == 0)
        {
            printf("XPSDrawline: could not get foreground value\n");
            return;
        }

        if (ps_color)
        {
            float r, g, b;
            int   i;

            i = (int)GC_return->foreground + color_min;
            r = (((float)color[i].red)   / ((float)MAX_RGB_VALUE));
            g = (((float)color[i].green) / ((float)MAX_RGB_VALUE));
            b = (((float)color[i].blue)  / ((float)MAX_RGB_VALUE));

            PSSetColorPixel(r, g, b);
        }
        else
        {
            PSSetPixel(display, GC_return->foreground);
        }

        PSNewpath();
        PSMoveto(x, y);
        PSLineto(x + w, y);
        PSLineto(x + w, y + h);
        PSLineto(x, y + h);
        PSClosefill();
    }
}


void
XPSFillPolygon(Display *display, Drawable drawable, GC context,
               Coord *coord, int ncoords, int shape, int mode)
{
    int         i;
    int         pcount;
    XGCValues  *GC_return = &gcr;

    if (output_flag == XOUT)
    {
        XFillPolygon(display, drawable, context, (XPoint *)coord,
                     ncoords, shape, mode);
    }
    else  /* Postscript output. */
    {
        if (ncoords <= 0)
            return;

        PSNewpath();

        if (XGetGCValues(display, context, GCForeground, GC_return) == 0)
        {
            printf("XPSDrawline: could not get foreground value\n");
            return;
        }

        PSSetPixel(display, GC_return->foreground);

        PSMoveto(coord[0].x, coord[0].y);
        pcount = 0;

        for (i = 1; i < ncoords; i++)
        {
            PSLineto(coord[i].x, coord[i].y);

            /* Break it up into managable chunks. */
            if (pcount > 200)
            {
                PSClosefill();
                PSMoveto(coord[i].x, coord[i].y);
                pcount = 0;
            }

            pcount++;
        }

        PSClosefill();
    }
}


void
PSHeader(XWindowAttributes *info, float requested_scale, int box,
         int header, short first_page)
{
    float   scale, scalex, scaley, xorigin, yorigin, xend, yend;
    long    clock;
    char    headerstr[200];
    char   *namestr;
    char   *ptr;
    char    clockstr[100];

    /*
     * Calculate scale factors.
     */

    global_window_width  = info->width;
    global_window_height = info->height;

    /* Scaling units: inches/screenpixel. */
    scalex = PAGEWIDTH  / global_window_width;
    scaley = PAGEHEIGHT / global_window_height;

    /*
     * Use the smaller scale factor so that everything will fit on the
     * page.
     */
    scale = requested_scale * ((scalex < scaley) ? scalex : scaley);

    /* Calculate the dots/screenpixel scale factor. */
    pix_scale = scale * DPI;

    /* Convert to postscriptpoints/screenpixel. */
    page_scale = scale * DEFAULTRES;

    /* Calculate the x and y origins. */
    xorigin = DEFAULTRES * (PAGEWIDTH  - scale * global_window_width)  / 2.0;
    yorigin = DEFAULTRES * (PAGEHEIGHT - scale * global_window_height) / 2.0;

    /* Calculate the x and y endpoints. */
    xend    = DEFAULTRES * (scale * global_window_width)  + xorigin;
    yend    = DEFAULTRES * (scale * global_window_height) + yorigin;

    if (first_page)
    {
        /*
         * Write out Postscript header.
         */

        fprintf(PSfp, "%%!PS-Adobe-3.0 EPSF-3.0\n");
        fprintf(PSfp, "%%%%Creator: xview\n");
        fprintf(PSfp, "%%%%BoundingBox: %d %d %d %d\n",
                ((int) xorigin), ((int) yorigin),
                ((int) xend), ((int) yend));
        fprintf(PSfp, "%%%%DocumentData: Clean7Bit\n");
        fprintf(PSfp, "%%%%LanguageLevel: 1\n");
        fprintf(PSfp, "%%%%Orientation: Portrait\n");
        fprintf(PSfp, "%%%%PageOrder: Ascend\n");
        fprintf(PSfp, "%%%%EndComments\n");
        fprintf(PSfp, "\n");

        fprintf(PSfp, "%%%%BeginDefaults\n");
        fprintf(PSfp, "%%%%PageOrientation: Portrait\n");
        fprintf(PSfp, "%%%%EndDefaults\n");
        fprintf(PSfp, "\n");

        /*
         * MCV: commented this out; it isn't necessary and violates
         *      the EPSF conventions.
         */
        /* fprintf(PSfp, "initgraphics\n"); */

        fprintf(PSfp, "%%%%BeginProlog\n");  /* Not strictly necessary. */
        fprintf(PSfp, "/M { moveto } bind def\n");
        fprintf(PSfp, "/L { lineto } bind def\n");
        fprintf(PSfp, "/S { stroke } bind def\n");
        fprintf(PSfp, "/N { newpath } bind def\n");
        fprintf(PSfp, "/C { closepath fill } bind def\n");
        fprintf(PSfp, "/G { setgray } bind def\n");
        fprintf(PSfp, "/K { setrgbcolor } bind def\n");
        /* Hook for alternative color mappings. */
        fprintf(PSfp, "%% Place alternative color mapping code here:\n");
        fprintf(PSfp, "%%%%COLORTRANSFORM\n");
        fprintf(PSfp, "%%%%EndProlog\n");  /* Not strictly necessary. */
        fprintf(PSfp, "\n");
    }

    if (header)
    {
        if ((namestr = getenv("NAME")) == NULL)
        {
            namestr = "";
        }

        time(&clock);
        strcpy(clockstr, ctime(&clock));

        if ((ptr = strchr(clockstr, '\n')))
        {
            *ptr = '\0';
        }

        sprintf(headerstr, "%s ::  %s ::  %s",
                clockstr, getcwd(NULL, 100), namestr);
        PSNewpath();
        //PSFont(12);
        fprintf(PSfp, "75 15 M\n");
        PSShow(headerstr);
        PSStroke();
    }

    /* Center the image on the page and scale it. */
    fprintf(PSfp, "%f %f translate\n", xorigin, yorigin);
    fprintf(PSfp, "%f %f scale\n", page_scale, page_scale);

    if (box)
    {
        fprintf(PSfp, "0.5 G\n");
        PSNewpath();
        PSMoveto(0, 0);
        PSLineto(0, global_window_height);
        PSLineto(global_window_width, global_window_height);
        PSLineto(global_window_width, 0);
        PSLineto(0, 0);
        PSStroke();
    }

    PSNewpath();
    PSMoveto(0, 0);
    PSLineto(0, global_window_height);
    PSLineto(global_window_width, global_window_height);
    PSLineto(global_window_width, 0);
    PSLineto(0, 0);
    fprintf(PSfp, "eoclip\n");
}



void
PSTrailer()
{
    fprintf(PSfp, "showpage\n");
}


void
PreparePS(Display *display, Window window, float scale, int box,
          int header, short first_page)
{
    char    command[80];
    XWindowAttributes info;
    char   *printer;

    current_gray = -1;
    current_line = -1;
    XGetWindowAttributes(display, window, &info);

    if (file_output)
    {
        PSfp = fopen(ps_filename, ps_filemode);
    }
    else
    {
        if ((printer = (char *)getenv("PRINTER")) == NULL)
            printer = "lw";

        sprintf(command, "lpr -h -P%s", printer);
        PSfp = popen(command, "w");
    }

    PSHeader(&info, scale, box, header, first_page);

    output_flag = PSOUT;
}


void
FinishPS()
{
    PSTrailer();
    output_flag = XOUT;

    if (file_output)
        fclose(PSfp);
    else
        pclose(PSfp);
}
