/*
 * FILE: keys.c
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include "xview_ext.h"
#include <stdlib.h>
#include <string.h>

#include "xview_ext.h"

static float plot_scale = 0.7;


void
PrintToFile(char *filename, char *mode, short first_page)
{
    /* Create a postscript file. */
    SetPSFileOutput(1);
    SetPSFilename(filename);
    SetPSFilemode(mode);
    PreparePS(G->display, G->imagewindow, plot_scale, 0, 0, first_page);
    RefreshXview();
    /* DrawBorder(); */  /* MCV: this messes up the time and title display */
    FinishPS();
    SetPSFileOutput(0);
}


void
PrintOut()
{
    PreparePS(G->display, G->imagewindow, plot_scale, 0, 0, 1);
    RefreshXview();
    /* DrawBorder(); */  /* MCV: this messes up the time and title display */
    FinishPS();
}


void
BackStep()
{
    IncrementViewTime(-V->view_step);
    DisplayView();
}


void
ForwardStep()
{
    IncrementViewTime(V->view_step);
    DisplayView();
}


long
fsize(char *name)
{
    struct stat stbuf;

    if (stat(name, &stbuf) == -1)
    {
        fprintf(stderr, "fsize: can't find %s\n", name);
        return 0;
    }

    if ((stbuf.st_mode & S_IFMT) == S_IFDIR)
    {
        fprintf(stderr, "fsize: %s is a directory\n", name);
        return 0;
    }

    return (stbuf.st_size);
}


int
LocateCell(int x, int y, int *cx, int *cy, int *cn)
{
    *cx = (x / (float)width) * (V->xmax + 1);
    *cy = ((yb + height - y) / (float)(height)) * (V->ymax + 1);
    *cn = *cy * (V->xmax + 1) + *cx;

    if ((*cn >= V->cellnum) || (*cn < 0))
    {
        return 0;
    }

    return 1;
}


void
GraphCell(int x, int y, short fft)
{
    int     cell_x;
    int     cell_y;
    int     cell_n;

    /*
     * Calculate the cell coordinates
     * based on their location in the window.
     */

    if (LocateCell(x, y, &cell_x, &cell_y, &cell_n))
        PlotData(cell_x, cell_y, cell_n, fft);
    else
        Bell(0);
}


void
DisplayLocation(int x, int y)
{
    int     cell_x;
    int     cell_y;
    int     cell_n;
    char    comstr[200];

    /*
     * Calculate the cell coordinates
     * based on their location in the window.
     */

    if (LocateCell(x, y, &cell_x, &cell_y, &cell_n))
    {
        /*
         * Print the coordinates and the data value
         * of the cell pointed to by the cursor.
         */

        if (fabs(data[cell_n]) < 0.1)
        {
            sprintf(comstr, "x=%d y=%d n=%d v=%12.6e       ",
                    cell_x, cell_y, cell_n, data[cell_n]);
        }
        else
        {
            sprintf(comstr, "x=%d y=%d n=%d v=%12.6f       ",
                    cell_x, cell_y, cell_n, data[cell_n]);
        }

        SetColor(G->foreground);
        Text(G->fontwidth, G->fontheight * 3, comstr);
    }
    else
    {
        Bell(0);
    }
}


void
KeyAction(XKeyEvent *event)
{
    int     i, j, n;
    char    buffer[100];
    char    c;
    KeySym  key;
    float   time;

    buffer[0] = '\0';

    /* Do key mapping to determine the actual key pressed. */
    XLookupString(event, buffer, 100, &key, NULL);
    c = *buffer;

    /* Check for numeric strings. */
    if ((c >= '0' && c <= '9') || (c == '.') || (c == '-') || (c == 'e'))
    {
        sprintf(numstr, "%s%c", numstr, c);
    }
    else
    {
        switch (c)
        {
        case '':
            /* Append to a postscript file. */
            PrintToFile("xview.ps", "a", 0);
            RefreshXview();
            break;

        case '':
            Quit();
            break;

        case '':
            PrintToFile("xview.ps", "w", 1);
            RefreshXview();
            break;

        case '':
            /* Erase the current command string. */
            numstr[0] = '\0';
            break;

        case 'A':
            autoscale = 1;
            do_autoscale(fp);
            V->valid_frame = GetFrame(V->view_time);
            NormalizeData();
            RefreshXview();
            break;

        case 'B':
            /* Black and white color Postscript output. */
            ps_color = 0;
            break;

        case 'C':
            /*
             * Toggle display of colorbar.
             * This only works for postscript output, which is all it's
             * really needed for.  FIXME: make it work for X output too.
             */
            colorbar_flag = 1 - colorbar_flag;

        case 'D':
            DumpData();
            break;

        case 'G':  /* go to the last time step */
            SetViewTime((V->nframes - 1) * V->dt);
            DisplayView();
            break;

        case 'K':
            /* Full color Postscript output. */
            ps_color = 1;
            break;

        case 'L':
            /*
             * set the line_width
             */
            if (strlen(numstr) > 0)
                line_width = atoi(numstr);
            else
                line_width = 1;
            numstr[0] = '\0';
            break;

        case 'M':
#if 0
/* FIXME */
            MatlabDump("");
            break;
#endif

        case 'P':
            /*
             * Do the postscript output at the desired scale
             * which blanks the screen.
             */
            PrintOut();

            /* Redisplay the screen. */
            RefreshXview();
            break;

        case 'S':
            /*
             * set the plotting scale from 0-1
             */
            if (strlen(numstr) > 0)
                plot_scale = atof(numstr);
            else
                plot_scale = 0.7;
            numstr[0] = '\0';
            break;

        case 'a':
            autoscale = 2;
            do_frame_autoscale();
            NormalizeData();
            RefreshXview();
            break;

        case 'b':  /* backup one timestep */
            BackStep();
            break;

        case 'c':
            /*
             * set the number of contours
             */

            if (strlen(numstr) > 0)
                ncontours = atoi(numstr);

            numstr[0] = '\0';
            NormalizeData();
            RefreshXview();
            break;

        case 'd':  /* Toggle the animation direction. */
            V->reverse = !V->reverse;
            break;

        case 'f':  /* forward step */
            ForwardStep();
            break;

        case 'g':  /* go to a specific time step */
            if (strlen(numstr) > 0)
                time = atof(numstr);
            else
                time = V->init_time;

            numstr[0] = '\0';
            SetViewTime(time);
            DisplayView();
            break;

        case 'i':
            if (strlen(numstr) > 0)
                V->view_step = atof(numstr);
            else
                V->view_step = V->dt;

            numstr[0] = '\0';
            break;

        case 'j':
            V->init_time = atof(numstr);
            numstr[0] = '\0';
            break;

        case 'l':  /* Dump "lots" of data to stdout. */
            for (i = 0; i <= V->xmax; i++)
            {
                for (j = 0; j <= V->ymax; j++)
                {
                    n = j * (V->xmax + 1) + i;
                    printf("x = %d\ty = %d\tv = %20.10g\n",
                           i, j, data[n]);
                }
            }

            break;

        case 'm': /* set the display mode */
            if (strlen(numstr) > 0)
                V->display_mode = atoi(numstr);
            else
                V->display_mode = 0;

            numstr[0] = '\0';
            RefreshXview();
            break;

        case 'n':
            /* cycle through the titles displayed in the legend */
            title_mode = (title_mode + 1) % ntitles;
            legend_background();
            break;

        case 'o':
            /* use oriented lines as the display mode */
            if (strlen(numstr) > 0)
                orient = atoi(numstr);
            else
                orient = 0;

            numstr[0] = '\0';
            RefreshXview();
            break;

        case 'p':
            /*
             * Plot the data corresponding to the cell
             * pointed to by the cursor.
             */
            GraphCell(event->x, event->y, 0);
            break;

        case 'q':  /* quit */
            Quit();
            break;

        case 'r':  /* set the display representation */
            if (strlen(numstr) > 0)
                representation = atoi(numstr);
            else
                representation = 0.0;

            numstr[0] = '\0';
            RefreshXview();
            break;

        case 's':  /* toggle single stepping */
            V->singlestep = !V->singlestep;
            break;

        case 't':
            /*
             * Plot the data corresponding to the cell
             * pointed to by the cursor.  Do an fft before plotting.
             */
            GraphCell(event->x, event->y, 1);
            break;

        case 'w':  /* Set the animation speed: 0 = fastest */
            if (strlen(numstr) > 0)
                speed = atoi(numstr);
            else
                speed = 0;

            numstr[0] = '\0';
            RefreshXview();
            break;

        case 'z':
            /*
             * set the z scale factor used in the
             * surface display modes
             */
            if (strlen(numstr) > 0)
                zsize = atof(numstr);
            else
                zsize = 0;

            numstr[0] = '\0';
            RefreshXview();
            break;

        case '+':  /* set the rectification mode */
            if (strlen(numstr) > 0)
                posneg = atoi(numstr);
            else
                posneg = 0;

            numstr[0] = '\0';
            NormalizeData();
            RefreshXview();
            break;

        case ']':  /* set the upper z bound */
            if (strlen(numstr) > 0)
            {
                if (atof(numstr) - minval != 0)
                {
                    maxval = atof(numstr);
                    scale = maxval - minval;
                }
            }

            numstr[0] = '\0';
            NormalizeData();
            RefreshXview();
            break;

        case '[':  /* set the lower z bound */
            if (strlen(numstr) > 0)
            {
                if (maxval - atof(numstr) != 0)
                {
                    minval = atof(numstr);
                    scale = maxval - minval;
                }
            }

            numstr[0] = '\0';
            NormalizeData();
            RefreshXview();
            break;
        }
    }
}


void
PlotData(int x, int y, int n, short fft)
{
    int     dnum = 0;
    float   fval;
    float   val = 0.0;
    double  dval;
    int     ival;
    short   sval;

    /*
     * tfp is the temporary file pointer for the xplot data; pfp is the
     * (read-only) file pointer for the xplot prefix, which is a file
     * of commands that is concatenated onto the xplot data at the end
     * of the file.
     */

    FILE   *tfp, *pfp;
    float   time;
    char    comstr[1000];
    char   *tmpname;
    char    xplot_prefix_line[1000];
    char   *mktemp(char *);

    tmpname = "/tmp/xview.plot";

    if ((tfp = fopen(tmpname, "w")) == NULL)
    {
        fprintf(stderr, "unable to open temporary file\n");
        return;
    }

    fseek(fp, n * V->datasize + V->headersize, 0);
    time = V->start_time;
    sprintf(comstr, "/graphtitle \"%s x=%d y=%d n=%d\"",
            V->filename, x, y, n);
    fprintf(tfp, "%s\n", comstr);


    /*
     * Add the xplot_prefix lines (if any) to the temporary file.
     */

    if (use_xplot_prefix_file)
    {
        if ((pfp = fopen(xplot_prefix_filename, "r")) == NULL)
        {
            fprintf(stderr, "unable to open xplot prefix file\n");
            return;
        }

        rewind(pfp);

        while (fgets(xplot_prefix_line, 1000, pfp) != NULL)
            fprintf(tfp, "%s", xplot_prefix_line);

        fclose(pfp);
    }


    /* Load the data into the temporary file. */

    while (!feof(fp))
    {
        switch (V->datatype)
        {
        case FLOAT:
            dnum = fread(&fval, V->datasize, 1, fp);
            val = fval;
            break;

        case DOUBLE:
            dnum = fread(&dval, V->datasize, 1, fp);
            val = dval;
            break;

        case INT:
            dnum = fread(&ival, V->datasize, 1, fp);
            val = ival;
            break;

        case SHORT:
            dnum = fread(&sval, V->datasize, 1, fp);
            val = sval;
            break;
        }

        if (dnum <= 0)
            break;

        time += V->dt;
        fprintf(tfp, "%g %g\n", time, val);
        fseek(fp, (long)((V->cellnum - 1) * V->datasize), 1);
    }

    fclose(tfp);


    /* Plot the data. */

    if (fft)
        sprintf(comstr, "power_spectrum %s | xplot &", tmpname);
    else
        sprintf(comstr, "xplot %s &", tmpname);

    system(comstr);
}


void
DumpData()
{
    int     i;
    FILE   *fp;
    int     x, y;

    if ((fp = fopen("xview.data", "w")) == NULL)
    {
        fprintf(stderr, "unable to open file xview.data\n");
        return;
    }

    for (i = 0; i < V->cellnum; i++)
    {
        x = i % (V->xmax + 1);
        y = i / (V->xmax + 1);
        fprintf(fp, "%d %d %d %g\n", i, x, y, data[i]);
    }

    fclose(fp);
}
