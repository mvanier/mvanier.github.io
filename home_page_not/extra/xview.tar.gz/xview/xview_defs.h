/*
 * FILE: xview_defs.h
 *
 */

#ifndef XVIEW_DEFS_H
#define XVIEW_DEFS_H

#define TINY 1.0e-5

#define setchar(i, j, s)    for (k = i; k <= j; k++) ch[k] = s
#define mvp(x, y, p)        move(y,x); printw("%s", p)

#define MAXASC              50
#define MGP                 0
#define TEXT                1
#define DEFAULTMIN         -80
#define DEFAULTMAX          20
#define HEADER_SIZE         (3 * sizeof (int) + sizeof (float))
#define STATOFS             140

#define FILLEDBOX           0
#define BOX                 1
#define COLORBOX            2
#define SURFACE             3
#define COLORSURFACE        4
#define FILLEDSURFACE       5
#define COLORFILLEDSURFACE  6
#define CONTOUR             7
#define COLORCONTOUR        8
#define NUMBERBOX           9
#define GRAYSCALE           0
#define SPECTRALSCALE       1
#define RGRAYSCALE          2

#define AREA                0
#define LENGTH              1

#define MAXTITLES           10
#define MAXCONTOURS         500

#define SHIFT               5

#define FONT_FOR_TEXT       "6x13p"

#define min(a,b) ((a) < (b) ? (a) : (b))
#define max(a,b) ((a) > (b) ? (a) : (b))

/*
 * Colors.
 */

#define MAX_COLORS 256
#ifndef _8_BIT_COLOR_HACK
#define WHITE 255
#else /* Emulating 8-bit color on a 16-bit display. */
#define WHITE 65535
#endif

#ifdef  _16_BIT_COLOR
#define MAX_RGB_VALUE 65535
#else
#define MAX_RGB_VALUE 255
#endif


/*
 * Miscellaneous.
 */

#define MAX_LINE_LEN 80

#endif  /* XVIEW_DEFS_H */

