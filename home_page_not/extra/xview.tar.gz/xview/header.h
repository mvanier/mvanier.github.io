/*
 * FILE: header.h
 *
 */

#ifndef HEADER_H
#define HEADER_H

#define INVALID 0
#define CHAR    1
#define SHORT   2
#define INT 3
#define FLOAT   4
#define DOUBLE  5
#define FUNC    6
#define FFUNC   7

#ifndef TRUE
#define TRUE    1
#define FALSE   0
#endif

#define arg_is(s)   (strcmp(argv[nxtarg],s) == 0)
#define iarg()  (atoi(argv[++nxtarg]))
#define farg()  (atof(argv[++nxtarg]))
#define arg_starts_with(c)  (argv[nxtarg][0] == c)

#endif  /* HEADER_H */

