/*
 * FILE: legend.c
 *
 */

#include "xview_ext.h"

void
DrawBorder()
{
    int ymin;
    int ymax;
    int space;

    space = G->fontheight * 0.5;
    ymin  = G->fontheight * 2 + space;
    ymax  = legend_base - space;

    DrawLine(-space, ymin, width + space, ymin);
    DrawLine(width + space, ymin, width + space, ymax);
    DrawLine(width + space, ymax, -space, ymax);
    DrawLine(-space, ymax, -space, ymin);
}


void
DrawColorScale()
{
    int xbase, ybase;
    int maxbase;

    SetColor(G->foreground);
    xbase = G->fontwidth;
    ybase = 2.5 * G->fontheight;

    /* scale labels */

    /* minval */

    if (fabs(minval) < 0.001)
        sprintf(valstr, "%-7.3e", minval);
    else
        sprintf(valstr, "%-7.3f", minval);

    Text(G->fontwidth, ybase, valstr);

    /* maxval */

    if (fabs(maxval) < 0.001)
        sprintf(valstr, "%.3e", maxval);
    else
        sprintf(valstr, "%.3f", maxval);

    /*maxbase = width - G->fontwidth * 10;*/
    maxbase = width - G->fontwidth * 5;

    /*
      if (maxbase < G->fontwidth * 10)
      maxbase = G->fontwidth * 10;
    */

    Text(maxbase, ybase, valstr);
}


void
DrawColorBar()
{
    float   color_width;
    int     i, x;
    int     xbase, ybase;

    xbase = G->fontwidth;
    ybase = G->fontheight;

    /*
     * color bar
     */
    color_width = width / color_scale;

    for (i = 0; i < (int)(color_scale); i++)
    {
        SetColor((int)(i + color_min));

        /*
         * x = xbase + (int)(i*G->fontwidth/5);
         */
        x = (i * color_width);
        FilledBox(
            x, 0,
            (int)(x + color_width + 1),
            G->fontheight);
    }
}


void
ClearTitle()
{
    SetColor(G->background);
    FilledBox(0, 0, width, G->fontheight);
}


void
legend_background()
{
    SetColor(G->foreground);

    if (header)
    {
        if (G->print_labels >= 1)
        {
            /* Time label. */
            Text(G->fontwidth * 9, legend_base, "sec");

            /* Title. */
            Text(G->fontwidth * 18, legend_base, title[title_mode]);
        }
    }
    else
    {
        SetColor(G->background);
        FilledBox(0, legend_base, width, legend_base + G->fontheight);
    }

    DrawColorScale();
}


void
legend_foreground()
{
    if (G->print_labels <= -1)
    {
        return;
    }

    /* Display the time. */

    SetColor(G->foreground);

    if (V->valid_frame)
    {
        sprintf(timestr, "%7.4f", V->view_time);
    }
    else
    {
        sprintf(timestr, "<<END>>");
    }

    Text(G->fontwidth, legend_base, timestr);
}

