/*
 * FILE: eventhandler.c
 *
 */

#include    "xview_ext.h"


void
event_handler(XEvent *event)
{
    switch (event->type)
    {
    case Expose:
        RefreshXview();
        break;

    case ButtonPress:
        ButtonAction(event);
        break;

    case KeyPress:
        KeyAction((XKeyEvent *)event);
        break;

    default:
        break;
    }
}


void
RefreshXview()
{
    if ((V->display_mode != COLORBOX)
        && (V->display_mode != COLORCONTOUR))
    {
        ClearWindow(G->imagewindow);
    }

    Rescale();

    if (header && colorbar_flag)
        legend_background();

    DisplayFrame();

    if (header && colorbar_flag)
    {
        if (V->display_mode == COLORBOX
            || V->display_mode == COLORCONTOUR
            || V->display_mode == COLORSURFACE
            || V->display_mode == COLORFILLEDSURFACE)
        {
            DrawColorBar();
        }
    }
}


void
ButtonAction(XButtonPressedEvent *buttonevent)
{
    if (buttonevent->button == 1)
    {
        BackStep();
    }
    else if (buttonevent->button == 2)
    {
        DisplayLocation(buttonevent->x, buttonevent->y);
    }
    else if (buttonevent->button == 3)
    {
        ForwardStep();
    }
}


void
EventString(XEvent *E)
{
    XButtonPressedEvent *B;

    switch (E->type)
    {
    case ButtonPress:
        B = (XButtonPressedEvent *) E;
        printf("ButtonPress ");

        if (B->button == 1)
            printf("1 ");

        if (B->button == 2)
            printf("2 ");

        if (B->button == 3)
            printf("3");

        printf("\n");
        break;

    case Expose:
        printf("Expose\n");
        break;

    case KeyPress:
        printf("KeyPress\n");
        break;

    default:
        printf("unknown event type %d\n", E->type);
        break;
    }
}
