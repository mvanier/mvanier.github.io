/*
 * FILE: arg.c
 *
 */

#include "xview_ext.h"
#include <stdlib.h>
#include <string.h>
#include <signal.h>


int
error()
{
    /* FIXME: this usage statement is missing TONS of options! */
    fprintf(stderr, "\nusage: xview file [file ..][-a][-step]"
            "[-wait #][-display_mode #]\n");
    fprintf(stderr,
            "               [-maxmin # #][-scale #][-xs #][-ys #][-add]\n");
    fprintf(stderr,
            "               [-plainformat xmax ymax dt datatype]\n");
    fprintf(stderr,
            "               [-command_file name]\n");
    fprintf(stderr,
            "               [-xplot_prefix_file name]\n");
    exit(0);
}


void
ParseArgList(int argc, char **argv)
{
    int     nxtarg;
    int     filecnt;
    extern  void sigadvance(), sigtoggle();
    char   *type;

    if (argc < 2)
        error();

    nxtarg          = 0;
    display         = NULL;     /* use the environ DISPLAY */
    command_file    = NULL;

    signal(SIGUSR1, sigadvance);
    signal(SIGUSR2, sigtoggle);

    /* If autoscaling is off then assume nominal intracellular bound. */
    xbase_size  = ybase_size    = 15;
    minval      = DEFAULTMIN;
    maxval      = DEFAULTMAX;
    autoscale   = TRUE;
    waitval     = 0;

    V->display_mode = COLORBOX;
    V->xmax         = -1;
    V->ymax         = -1;
    V->reverse      = FALSE;
    V->singlestep   = TRUE;
    G->scale_type   = SPECTRALSCALE;
    V->plain        = 0;

    ys = xs = 1;
    cumulative      = FALSE;
    backup          = FALSE;
    manual_xsize    = 0;
    manual_ysize    = 0;
    representation  = 0;
    title_mode      = 0;
    speed           = 0;

    /*
     * The `speed_increment' variable is supposed to represent how many
     * microseconds to delay between frames for a `w' key setting of 1.
     * It does not, possibly due to a bug in "select" or system overhead.
     * Instead, what happens is that 0 gives no delay, while any nonzero
     * value whatsoever gives about the same delay.
     * FIXME: figure out why.
     */

    speed_increment         = 1;
    ntitles                 = 1;
    posneg                  = 0;
    header                  = 1;
    signal_step             = FALSE;
    pipe_step               = FALSE;
    color_mode              = 1;
    no_lines                = 0;

    filecnt                 = 0;
    V->init_time            = 0.0;
    V->end_time             = -1.0;  /* Default: no specified end time. */
    use_xplot_prefix_file   = 0;

    strcpy(geometry, "");

    while (argc > ++nxtarg)
    {
        if (arg_is("-command_file"))
        {
            command_file  = argv[++nxtarg];
            commandsource = 0;
        }
        else if (arg_is("-xplot_prefix_file"))
        {
            use_xplot_prefix_file = 1;
            strcpy(xplot_prefix_filename, argv[++nxtarg]);
        }
        else if (arg_is("-d"))
        {
            display = argv[++nxtarg];
        }
        else if (arg_is("-ncontours"))
        {
            ncontours = iarg();
            V->display_mode = COLORCONTOUR;
        }
        else if (arg_is("-bw"))
        {
            color_mode = 0;
        }
        else if (arg_is("-nomap"))
        {
            G->mapped = FALSE;
        }
        else if (arg_is("-command"))
        {
            command_file  = argv[++nxtarg];
            commandsource = 1;
        }
        else if (arg_is("-font"))
        {
            strcpy(G->font_string, argv[++nxtarg]);
        }
        else if (arg_is("-rep"))
        {
            representation = iarg();
        }
        else if (arg_is("-xsize"))
        {
            manual_xsize = 1;
            xs = farg();
        }
        else if (arg_is("-ysize"))
        {
            manual_ysize = 1;
            xs = farg();
        }
        else if (arg_is("-t"))
        {
            strcpy(title[ntitles++], argv[++nxtarg]);
        }
        else if (arg_is("-add"))
        {
            cumulative = TRUE;
        }
        else if (arg_is("-debug"))
        {
            debug = TRUE;
        }
        else if (arg_is("-signal"))
        {
            signal_step = TRUE;
        }
        else if (arg_is("-pipe"))
        {
            pipe_step   = TRUE;

            /* If using pipes, interpret signals differently. */
            signal_flag = TRUE;

            /* FIXME: should do error checking here. */
            in_pipe   = atoi(argv[++nxtarg]);
            out_pipe  = atoi(argv[++nxtarg]);

            if (debug)
            {
                printf("IN_PIPE: %d\tOUT_PIPE: %d\n", in_pipe, out_pipe);
            }
        }
        else if (arg_is("-maxmin"))
        {
            autoscale = FALSE;
            maxval = farg();
            minval = farg();
        }
        else if (arg_is("-zsize"))
        {
            zsize = farg();
        }
        else if (arg_is("-xmax"))
        {
            V->xmax = iarg();
        }
        else if (arg_is("-ymax"))
        {
            V->ymax = iarg();
        }
        else if (arg_is("-plainformat"))
        {
            V->xmax = iarg();
            V->ymax = iarg();
            V->dt = farg();
            type = argv[++nxtarg];

            if (strcmp(type, "float") == 0)
            {
                V->datatype = FLOAT;
            }
            else if (strcmp(type, "char") == 0)
            {
                V->datatype = CHAR;
            }
            else if (strcmp(type, "short") == 0)
            {
                V->datatype = SHORT;
            }
            else if (strcmp(type, "int") == 0)
            {
                V->datatype = INT;
            }
            else if (strcmp(type, "double") == 0)
            {
                V->datatype = DOUBLE;
            }
            else
            {
                fprintf(stderr, "invalid type specification\n");
                V->datatype = INVALID;
            }

            V->headersize = 0;
            V->plain = 1;
        }
        else if (arg_is("-noheader"))
        {
            header = 0;
        }
        else if (arg_is("-nolines"))
        {
            no_lines = 1;
        }
        else if (arg_is("-scale"))
        {
            ybase_size = xbase_size = iarg();
        }
        else if (arg_is("-adjust"))
        {
            adjusttype(iarg());
        }
        else if (arg_is("-geometry"))
        {
            strcpy(geometry, argv[++nxtarg]);
        }
        else if (arg_is("-gray"))
        {
            G->scale_type = GRAYSCALE;
        }
        else if (arg_is("-rgray"))
        {
            G->scale_type = RGRAYSCALE;
        }
        else if (arg_is("-mode"))
        {
            V->display_mode = iarg();
        }
        else if (arg_is("-box"))
        {
            V->display_mode = BOX;
        }
        else if (arg_is("-filledbox"))
        {
            V->display_mode = FILLEDBOX;
        }
        else if (arg_is("-colorbox"))
        {
            V->display_mode = COLORBOX;
        }
        else if (arg_is("-surface"))
        {
            V->display_mode = SURFACE;
        }
        else if (arg_is("-filledsurface"))
        {
            V->display_mode = FILLEDSURFACE;
        }
        else if (arg_is("-colorfilledsurface"))
        {
            V->display_mode = COLORFILLEDSURFACE;
        }
        else if (!arg_starts_with('-'))
        {
            strcpy(fname, argv[nxtarg]);
            if ((fp = fopen(fname, "r")) == NULL)
            {
                fprintf(stderr, "xview: unable to open file: %s\n", fname);
            }
            else
            {
                filecnt++;
            }
        }
        else
        {
            error();
        }
    }

    if (filecnt == 0)
    {
        printf("xview: Please specify a valid file.\n");
        exit(0);
    }

    V->filename = fname;
    strcpy(title[0], fname);

    if (cumulative)
    {
        strcat(title[0], "    ADD");
    }
}
