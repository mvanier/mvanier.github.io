/*
 * FILE: event_loop.c
 *
 */

#include "xview_ext.h"

void
IncrementViewTime(float inc)
{
    float time;

    time = V->view_time + inc;

    if (time < V->start_time)
        time = V->start_time;

    if ((V->end_time > 0) && (time > V->end_time))
    {
        time = V->end_time;

        /* Pop out of animation into singlestep mode. */
        V->singlestep = 1;
    }

    V->view_time = (int)(time / V->dt + 0.5) * V->dt;
}


void
SetViewTime(float time)
{
    if (time < V->start_time)
        time = V->start_time;

    V->view_time = (int)(time / V->dt + 0.5) * V->dt;
}


void
DisplayView()
{
    if ((V->display_mode != COLORBOX) && (V->display_mode != COLORCONTOUR))
        ClearImage();

    V->valid_frame = GetFrame(V->view_time);
    DisplayFrame();
}


void
EventLoop()
{
    XEvent event;
    int    i;
    extern int signal_step, got_signal;
    char   in_pipe_buf[1], out_pipe_buf[2];
    short  long_command_flag = 0;
    int    nread, nwritten;
    char   in_char;
    float  time;


    XFlush(G->display);

    /* display the first frame */
    V->valid_frame = GetFrame(V->view_time);
    Rescale();

    if (command_file)
        ReadCommandFile(commandsource, command_file);

    got_signal = 0;
    RefreshXview();

    for (;;)
    {
        if (signal_step)
        {
            while (!got_signal)
                sleep(1);

            got_signal = 0;

            /* Get rid of any events on the event queue. */

            if (XPending(G->display) != 0)
            {
                while (XCheckMaskEvent(G->display, ExposureMask, &event))
                    ;
            }

            V->singlestep = 0;
            RefreshXview();
        }  /* signal_step */


        /*
         * WARNING: the following code has gotten bloated beyond belief!
         */

        if (pipe_step)
        {
            /* Get rid of any events on the event queue. */

            if (XPending(G->display) != 0)
            {
                while (XCheckMaskEvent(G->display, ExposureMask, &event))
                    ;
            }

            V->singlestep = 0;

            if (!long_command_flag)
            {
                /* Read in a single character from the input pipe. */
                nread = read(in_pipe, in_pipe_buf, 1);

                if (nread == 1)
                {
                    in_char = in_pipe_buf[0];

                    if (debug)
                        printf("PIPE READ: %c\n", in_char);

                    switch (in_char)
                    {
                    case 'E':  /* Exit program. */
                        exit(0);
                        break;

                    case 'D':  /* Done with pipes, but don't exit. */
                        pipe_step = FALSE;
                        V->singlestep = 1;
                        break;

                    case 'R':  /* Reset simulation. */
                        time = V->init_time;
                        SetViewTime(time);
                        DisplayView();
                        break;

                    case '/':  /* Read in full command later. */
                        long_command_flag = 1;
                        break;

                    default:
                        if (V->valid_frame)
                        {
                            ForwardStep();

                            if (speed > 0)
                            {
                                for (i = 0; i < speed; i++)
                                    Usleep(speed_increment);
                            }
                        }
                    }
                }
                else
                {
                    fprintf(stderr, "Error reading from input pipe: %d\n",
                            in_pipe);
                }

                /*
                 * Write a two-character acknowledgement to the output
                 * pipe.
                 */

                if (V->valid_frame)
                {
                    out_pipe_buf[0] = 'a';
                    out_pipe_buf[1] = in_pipe_buf[0];
                    nwritten = write(out_pipe, out_pipe_buf, 2);
                }
                else
                {
                    out_pipe_buf[0] = 'a';
                    out_pipe_buf[1] = 'X';  /* This means we're done. */
                    nwritten = write(out_pipe, out_pipe_buf, 2);
                }

                if (nwritten != 2)
                {
                    fprintf(stderr, "Error writing to output pipe: %d\n",
                            out_pipe);
                }
                else
                {
                    if (debug)
                    {
                        printf("PIPE WROTE: %c%c\n",
                               out_pipe_buf[0], out_pipe_buf[1]);
                    }
                }

                RefreshXview();
            }
            else  /* Set up to receive long command. */
            {
                short cmd_str_done = 0;
                char  cmd_str[MAX_LINE_LEN];
                int   i;

                /*
                 * The first character is a `/', to make
                 * InterpretCommand() happy.
                 */

                cmd_str[0] = '/';

                /*
                 * Read in a line from the input pipe.
                 * This is somewhat inefficient, but who cares?
                 */

                for (i = 1;
                     (i < (MAX_LINE_LEN - 1)) && !cmd_str_done;
                     i++)
                {
                    nread = read(in_pipe, in_pipe_buf, 1);

                    if (nread == 1)
                    {
                        in_char = in_pipe_buf[0];

                        if (in_char == '\n')
                            cmd_str_done = 1;
                        else
                            cmd_str[i] = in_char;
                    }
                    else
                    {
                        fprintf(stderr, "Error reading from input pipe: %d\n",
                                in_pipe);
                    }

                    /*
                     * Write a two-character acknowledgement to the output
                     * pipe.
                     */

                    out_pipe_buf[0] = 'a';
                    out_pipe_buf[1] = in_pipe_buf[0];
                    nwritten = write(out_pipe, out_pipe_buf, 2);

                    if (nwritten != 2)
                    {
                        fprintf(stderr, "Error writing to output pipe: %d\n",
                                out_pipe);
                    }
                    else
                    {
                        if (debug)
                        {
                            printf("PIPE WROTE: %c%c\n",
                                   out_pipe_buf[0], out_pipe_buf[1]);
                        }
                    }
                }

                cmd_str[i-1] = '\0';
                long_command_flag = 0;
                InterpretCommand(cmd_str);
                RefreshXview();
            }
        }  /* pipe_step */

        if (!V->singlestep && !pipe_step)
        {
            /* continuous display */
            if (V->reverse)
                BackStep();
            else
                ForwardStep();

            if (speed > 0)
            {
                for (i = 0; i < speed; i++)
                    Usleep(speed_increment);
            }
        }

        if (V->init_run_mode)
        {
            /*
             * Start the animation immediately.
             * Remove all the unwanted expose events from the queue.
             */
            while (XCheckMaskEvent(G->display, ExposureMask, &event))
                ;

            V->init_run_mode = 0;
        }

        /*
         * Only go into the event loop if in singlestep mode
         * or there is an event pending.
         */

        if (!pipe_step
            && (V->singlestep
                || (XPending(G->display) != 0)))
        {
            /*
             * Remove all the unwanted expose events from the queue.
             */
            while (XCheckMaskEvent(G->display, ExposureMask, &event))
                ;

            /*
             * `pipe_step' may have changed its value if a signal was
             * received.  If so, don't go into the event handler.
             */

            if (!pipe_step)
            {
                XNextEvent(G->display, &event);

                if (debug)
                    EventString(&event);

                event_handler(&event);
            }
        }
    }
}
