/*
 * FILE: display.c
 *
 */

#include "xview_ext.h"

void
DisplayFrame()
{
    /* Display the image according to the display mode. */

    if (header)
    {
        legend_foreground();
        image_background();
    }

    display_image();
}


void
DisplayNextFrame()
{
    LoadNextFrame();
    DisplayFrame();
}


void
display_image()
{
    ContourList contour_list;

    switch (V->display_mode)
    {
    case SURFACE:
        DrawSurface(image, xsize, ysize, V->xmax, V->ymax);
        break;

    case COLORSURFACE:
        DrawColorSurface(image, xsize, ysize, V->xmax, V->ymax);
        break;

    case FILLEDSURFACE:
        DrawFilledSurface(image, xsize, ysize, V->xmax, V->ymax);
        break;

    case COLORFILLEDSURFACE:
        DrawColorFilledSurface(image, xsize, ysize, V->xmax, V->ymax);
        break;

    case BOX:
        DrawBox(image, xsize, ysize, V->xmax, V->ymax);
        break;

    case FILLEDBOX:
        DrawFilledBox(image, xsize, ysize, V->xmax, V->ymax);
        break;

    case COLORBOX:
        DrawColorBox(image, xsize, ysize, V->xmax, V->ymax);
        break;

    case COLORCONTOUR:
        DrawColorBox(image, xsize, ysize, V->xmax, V->ymax);

    case CONTOUR:
        MakeContourList(ncontours, minval, maxval, &contour_list);
        DrawContours(image, xsize, ysize, V->xmax, V->ymax, &contour_list);
        break;

    case NUMBERBOX:
        DrawNumberBox(xsize, ysize, V->xmax, V->ymax);
        break;
    }
}


void
ClearImage()
{
	if ((V->display_mode == BOX)
		|| (V->display_mode == FILLEDBOX))
	{
		SetColor(MAX_COLORS - 1); /* White. */
	}
	else
	{
		SetColor(G->background);
	}

    FilledBox(0, yb, width, height + yb);
}


void
image_background()
{
    Coord coord[5];

    if ((V->display_mode == SURFACE)
        || (V->display_mode == COLORSURFACE)
        || (V->display_mode == COLORFILLEDSURFACE)
        || (V->display_mode == FILLEDSURFACE))
    {
        SetColor(G->background);

        /* Draw the baseline plane. */

        /* xmax ymax */
        coord[0].x = xsize * V->xmax * 0.7;
        coord[0].y = yb + ysize * SHIFT + V->ymax * ysize * 0.7;

        /* 0 ymax */
        coord[1].x = 0;
        coord[1].y = yb + ysize * SHIFT + V->ymax * ysize * 0.7;

        /* 0 0 */
        coord[2].x = V->ymax * ysize / 3;
        coord[2].y = yb + ysize * SHIFT;

        /* xmax 0 */
        coord[3].x = xsize * V->xmax * 0.7 + V->ymax * ysize / 3;
        coord[3].y = yb + ysize * SHIFT;

        /* xmax ymax */
        coord[4].x = xsize * V->xmax * 0.7;
        coord[4].y = yb + ysize * SHIFT + V->ymax * ysize * 0.7;

        MultipleLines(coord, 5);
    }
}


