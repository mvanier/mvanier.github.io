/*
 * FILE: command.c
 *
 */

#include "xview_ext.h"
#include <stdlib.h>
#include <string.h>

static int helpcol;

#define ARG(N)   CommandArgument(line, N)
#define Match(S) (strncmp(line, S, strlen(S)) == 0)


float
Atof(char *s)
{
    if (s == NULL)
    {
        return 0;
    }

    return (atof(s));
}


int
Atoi(char *s)
{
    if (s == NULL)
    {
        return 0;
    }

    return (atoi(s));
}


char *
NextDelimiter(char *s, int *quote)
{
    if (s == NULL)
        return NULL;

    *quote = 0;

    for (; *s != '\0'; s++)
    {
        /*
         * look for a quote delimiter
         */

        if (*s == '"')
        {
            *quote = 1;
            break;
        }

        /*
         * look for a space delimiter
         * which is the first white space followed by non-white space
         */

        if ((*s == ' ' || *s == '\t') &&
            (*(s + 1) != ' ' && *(s + 1) != '\t' && *(s + 1) != '"'))
        {
            break;
        }
    }

    return s;
}



void
Setenv(char *var, char *value)
{
    char   *newenv;

    newenv = (char *)malloc(strlen(var) + strlen(value) + 4);
    strcpy(newenv, var);
    strcat(newenv, " = ");
    strcat(newenv, value);

    if (putenv(newenv) == 0)
    {
        fprintf(stderr, "%s=%s\n", var, value);
    }
    else
    {
        fprintf(stderr, "could not change %s\n", var);
    }
}


/*
 * Return an argument string delimited by white space or by quotes.
 */

char *
CommandArgument(char *line, int argnumber)
{
    int     i;
    int     count;
    char   *ptr;
    char   *ptr2;
    char   *copy;
    int     quote;

    ptr = line;

    /* Advance to the correct argument. */

    for (i = 0; i < argnumber; i++)
    {
        /* Locate the open delimiter. */

        ptr = NextDelimiter(ptr, &quote);

        if (ptr == NULL)
            return NULL;

        /* Advance past the open delimiter. */

        ptr++;
    }

    /* Copy the contents of the line up to the closing delimiter. */

    for (ptr2 = ptr, count = 0; *ptr2 != '\0'; ptr2++, count++)
    {
        if (quote)
        {
            if (*ptr2 == '"')
                break;
        }
        else
        {
            if (*ptr2 == ' ' || *ptr2 == '\t' || *ptr2 == '\n')
                break;
        }
    }
    if (count > 0)
    {
        copy = (char *)malloc((count + 1) * sizeof(char));

        strncpy(copy, ptr, count);
        copy[count] = '\0';
    }
    else
    {
        copy = NULL;
        fprintf(stderr, "missing argument #%d\n", argnumber);
    }

    return copy;
}


/*
 * Interpret / (slash) commands.
 */

void
InterpretCommand(char *line)
{
    float time;

    if (Match("/appendtofile"))
    {
        PrintToFile(ARG(1), "a", 0);
    }
    else if (Match("/back"))
    {
        BackStep();
    }
    else if (Match("/colorbar"))
    {
        if (strcmp(ARG(1), "off") == 0)
            colorbar_flag = 0;
        else
            colorbar_flag = 1;
    }
    else if (Match("/dummy_step"))
    {
        ForwardStep();
        BackStep();
    }
    else if (Match("/end_time"))
    {
        V->end_time = atof(ARG(1));
    }
    else if (Match("/forward"))
    {
        ForwardStep();
    }
#if 0
    /* FIXME!!! */
    else if (Match("/matlab_dump"))
    {
        MatlabDump(ARG(1));
    }
#endif
    else if (Match("/go"))
    {
        time = atof(ARG(1));
        SetViewTime(time);
        DisplayView();
    }
    else if (Match("/help"))
    {
        Help();
    }
    else if (Match("/increment"))
    {
        V->view_step = atof(ARG(1));
    }
    else if (Match("/init_time"))
    {
        V->init_time = atof(ARG(1));
    }
    else if (Match("/labels"))
    {
        G->print_labels = Atoi(ARG(1));
    }
    else if (Match("/mode"))
    {
        V->display_mode = Atoi(ARG(1));
    }
    else if (Match("/noheader"))
    {
        header = 0;
    }
    /* N.B. MUST put printtofile before print because of how Match works...
     * FIXME!!!!!!
     */
    else if (Match("/printtofile"))
    {
        PrintToFile(ARG(1), "w", 1);
    }
    else if (Match("/print"))
    {
        PrintOut();
    }
    else if (Match("/ps_color"))
    {
        if (strcmp(ARG(1), "off") == 0)
            ps_color = 0;
        else
            ps_color = 1;
    }
    else if (Match("/quit"))
    {
        Quit();
    }
    else if (Match("/run"))
    {
        /* Start the animation immediately. */
        V->singlestep = 0;
        V->init_run_mode = 1;
    }
    else if (Match("/setenv"))
    {
        Setenv(ARG(1), ARG(2));
    }
    else if (Match("/speed"))
    {
        speed = atof(ARG(1));

        if (speed < 0)
            speed = 0;
    }
    else if (Match("/wait"))
    {
        RefreshXview();
        sleep(Atoi(ARG(1)));
    }
    else if (Match("/zlower"))
    {
        if (maxval - atof(ARG(1)) != 0)
        {
            minval = atof(ARG(1));
            scale = maxval - minval;
        }
    }
    else if (Match("/zupper"))
    {
        if (atof(ARG(1)) - minval != 0)
        {
            maxval = atof(ARG(1));
            scale = maxval - minval;
        }
    }
    else
    {
        if (line[0] != '\0')
        {
            fprintf(stderr, "unrecognized command : %s\n", line);
        }
    }
}


void
HP(char *s)
{
    if ((helpcol++) % 4 == 0)
    {
        fprintf(stderr, "\n");
    }

    fprintf(stderr, "%-20s", s);
}


void
Help()
{
    /* FIXME: this is woefully incomplete. */
    fprintf(stderr, "AVAILABLE COMMANDS:\n");
    helpcol = 0;
    HP("mode [0-9]");
    HP("printtofile [file]");
    HP("appendtofile [file]");
    HP("print");
    HP("setenv [var value]");
    HP("geometry [str]");
    HP("wait [sec]");
    HP("quit");
    fprintf(stderr, "\n");
}
