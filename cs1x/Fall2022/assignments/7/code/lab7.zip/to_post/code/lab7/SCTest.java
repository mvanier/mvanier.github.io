/**
 * Tests of the calculator as a whole.
 */

package sc;

import java.io.*;
import java.util.*;

public class SCTest {
    private static int testsRun = 0;
    private static int testsPassed = 0;

    private static void testError(String label, String expected, String got) {
        System.err.println("Test " + label + ": ERROR: expected: " + expected +
          ", got: " + got);
    }

    public static void checkString(String label, String expected, String got) {
        testsRun++;
        if (!expected.equals(got)) {
            testError(label, "\"" + expected + "\"", "\"" + got + "\"");
        } else {
            testsPassed++;
        }
    }

    public static void testString(String label, String given, String expected_result) {
        var inputs = new ArrayList<Input>();
        inputs.add(new StringInput(given));
        var sc = new SC(inputs);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        // We use System.err for all messages because we've redirected
        // System.out.
        System.err.println("Running test " + label + " ...");
        sc.run();
        String result = out.toString();
        /*
        System.err.println("Actual result:");
        System.err.print(result);
        */

        // We reset System.out once we've run the test.
        System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));

        checkString(label, result, expected_result);
    }

    public static void testErrorString(String label, String given, String expected_result) {
        var inputs = new ArrayList<Input>();
        inputs.add(new StringInput(given));
        var sc = new SC(inputs);

        ByteArrayOutputStream err = new ByteArrayOutputStream();
        System.setErr(new PrintStream(err));

        // We use System.out for all messages because we've redirected
        // System.err.
        System.out.println("Running test " + label + " ...");
        sc.run();
        String result = err.toString();
        /*
        System.out.println("Actual result:");
        System.out.print(result);
        */

        // We reset System.err once we've run the test.
        System.setErr(new PrintStream(new FileOutputStream(FileDescriptor.err)));

        checkString(label, result, expected_result);
    }

    public static void main(String[] args) {
        System.out.println("*** Starting tests.");
        System.out.println();

        // '#' - discard (comment out) the rest of the line
        testString("0", "# this is a comment", "");

        System.out.println();

        // Value parsing and 'p' (print top of stack)
        testString("1a", "0p", "0\n");
        testString("1b", "10p", "10\n");
        testString("1c", "_53p", "-53\n");
        testString("1d", "1.p", "1.0\n");
        testString("1e", "0.1p", "0.1\n");
        testString("1f", "[]p", "\n");
        testString("1g", "[foo]p", "foo\n");

        System.out.println();

        // 'c' and 'f' - clear and print the stack
        testString("2a", "f", "");
        testString("2b", "1 2 3 4 5f", "5\n4\n3\n2\n1\n");
        testString("2c", "1 2 3 4 5cf", "");

        System.out.println();

        // 'd' - duplicate top of stack
        testErrorString("3a", "d", "d: empty stack\n");
        testString("3b", "1 2d", "");  // no output!
        testString("3c", "1 2df", "2\n2\n1\n");

        System.out.println();

        // 'k' - pop and discard the top of stack
        testErrorString("4a", "k", "k: empty stack\n");
        testString("4b", "1k", "");  // no output
        testString("4c", "1 2 3kf", "2\n1\n");

        System.out.println();

        // 'l' - copy the top value of a register stack
        // 's' - store to the top value of a register stack
        testErrorString("5a", "lA", "l: register must be in the range [a-z]\n");
        testErrorString("5b", "la", "l: register [a] is empty\n");
        testErrorString("5c", "s", "s: empty stack\n");
        testErrorString("5d", "10sA", "s: register must be in the range [a-z]\n");
        testString("5e", "10sala", "");  // no output
        testString("5f", "10salaf", "10\n");
        testString("5g", "10salalalaf", "10\n10\n10\n");
        testString("5h", "10sa20salaf", "20\n");

        System.out.println();

        // 'L' - pop the top value of a register stack
        // 'S' - push top of stack to a register stack
        testErrorString("6a", "LA", "L: register must be in the range [a-z]\n");
        testErrorString("6b", "La", "L: register [a] is empty\n");
        testErrorString("6c", "S", "S: empty stack\n");
        testErrorString("6d", "10SA", "S: register must be in the range [a-z]\n");
        testString("6e", "10SaLa", "");  // no output
        testString("6f", "10SaLaf", "10\n");
        testErrorString("6g", "10SaLaLa", "L: register [a] is empty\n");
        testString("6h", "10Sa20SaLaLaf", "10\n20\n");
        testString("6i", "10Sa20Salalaf", "20\n20\n");

        System.out.println();

        // 'n' - pop and print the top of the stack
        // 'p' - print the top of the stack without popping
        // 'N' - pop and print the top of the stack (no newline)
        testString("7a", "10 20 30n", "30\n");
        testString("7b", "10 20 30nnn", "30\n20\n10\n");
        testString("7c", "10 20 30p", "30\n");
        testString("7d", "10 20 30ppp", "30\n30\n30\n");
        testString("7e", "10 20 30NNN", "302010");

        System.out.println();

        // 'r' - rotate the top two stack items
        testErrorString("8a", "r", "r: not enough stack items\n");
        testErrorString("8b", "1r", "r: not enough stack items\n");
        testString("8c", "1 2r", ""); // no output
        testString("8d", "1 2rf", "1\n2\n");
        testString("8e", "1 2rrf", "2\n1\n");

        System.out.println();

        // 'x' - execute a string popped off the stack.
        testErrorString("9a", "[r]x", "r: not enough stack items\n");
        testErrorString("9b", "[1r]x", "r: not enough stack items\n");
        testString("9c", "[1 2r]x", ""); // no output
        testString("9d", "[1 2rf]x", "1\n2\n");
        testString("9e", "[1 2rrf]x", "2\n1\n");

        System.out.println();

        // '?' - conditional execution:
        //       pop three items from stack (int, string 1, string 2);
        //       if int == 0, execute string 1, else execute string 2
        testErrorString("9a", "1[r][d]?", "r: not enough stack items\n");
        testErrorString("9b", "_1[r][d]?", "r: not enough stack items\n");
        testErrorString("9c", "0[r][d]?", "d: empty stack\n");
        testString("9d", "1[10p][d]?", "10\n");
        testString("9e", "0[d][10p]?", "10\n");

        System.out.println();

        // '+' operator
        testErrorString("10a", "+", "+: not enough stack items\n");
        testErrorString("10b", "1+", "+: not enough stack items\n");
        testString("10c", "1 2+p", "3\n");
        testString("10d", "1 _2+p", "-1\n");
        testString("10e", "_1 2+p", "1\n");
        testString("10f", "_1 _2+p", "-3\n");
        testString("10g", "1.2 3.4+p", "4.6\n");
        testString("10h", "_1.2 3.4+p", "2.2\n");
        testString("10i", "1.2 _3.4+p", "-2.2\n");
        testString("10j", "_1.2 _3.4+p", "-4.6\n");
        testString("10k", "[][]+p", "\n");
        testString("10l", "[foo][]+p", "foo\n");
        testString("10m", "[][bar]+p", "bar\n");
        testString("10n", "[foo][bar]+p", "foobar\n");
        testString("10o", "1 3.4+p", "4.4\n");
        testString("10p", "1.1 3+p", "4.1\n");
        testErrorString("10q", "1[foo]+", "+: invalid operation: can't add number and string\n");
        testErrorString("10r", "[foo]1+", "+: invalid operation: can't add string and number\n");
        testErrorString("10s", "1.1[foo]+", "+: invalid operation: can't add number and string\n");
        testErrorString("10t", "[foo]1.1+", "+: invalid operation: can't add string and number\n");

        System.out.println();

        // '-' operator
        testErrorString("11a", "-", "-: not enough stack items\n");
        testErrorString("11b", "1-", "-: not enough stack items\n");
        testString("11c", "1 2-p", "-1\n");
        testString("11d", "1 _2-p", "3\n");
        testString("11e", "_1 2-p", "-3\n");
        testString("11f", "_1 _2-p", "1\n");
        testString("11g", "1.2 3.4-p", "-2.2\n");
        testString("11h", "_1.2 3.4-p", "-4.6\n");
        testString("11i", "1.2 _3.4-p", "4.6\n");
        testString("11j", "_1.2 _3.4-p", "2.2\n");
        testErrorString("11k", "[][]-", "-: invalid operation: can't subtract anything from string\n");
        testErrorString("11l", "[foo][]-", "-: invalid operation: can't subtract anything from string\n");
        testErrorString("11m", "[][bar]-", "-: invalid operation: can't subtract anything from string\n");
        testErrorString("11n", "[foo][bar]-", "-: invalid operation: can't subtract anything from string\n");
        testErrorString("11o", "1[foo]-", "-: invalid operation: can't subtract string from number\n");
        testErrorString("11p", "[foo]1-", "-: invalid operation: can't subtract anything from string\n");
        testErrorString("11q", "1.1[foo]-", "-: invalid operation: can't subtract string from number\n");
        testErrorString("11r", "[foo]1.1-", "-: invalid operation: can't subtract anything from string\n");

        System.out.println();

        // '*' operator
        testErrorString("12a", "*", "*: not enough stack items\n");
        testErrorString("12b", "1*", "*: not enough stack items\n");
        testString("12c", "1 2*p", "2\n");
        testString("12d", "1 _2*p", "-2\n");
        testString("12e", "_1 2*p", "-2\n");
        testString("12f", "_1 _2*p", "2\n");
        testString("12g", "0 2*p", "0\n");
        testString("12h", "2 0*p", "0\n");
        testString("12i", "1.2 3.4*p", "4.08\n");
        testString("12j", "_1.2 3.4*p", "-4.08\n");
        testString("12k", "1.2 _3.4*p", "-4.08\n");
        testString("12l", "_1.2 _3.4*p", "4.08\n");
        testString("12m", "0. 2.*p", "0.0\n");
        testString("12n", "2. 0.*p", "0.0\n");
        testString("12o", "0 2.*p", "0.0\n");
        testString("12p", "2. 0*p", "0.0\n");
        testErrorString("12k", "[][]*", "*: invalid operation: can't multiply string by anything\n");
        testErrorString("12l", "[foo][]*", "*: invalid operation: can't multiply string by anything\n");
        testErrorString("12m", "[][bar]*", "*: invalid operation: can't multiply string by anything\n");
        testErrorString("12n", "[foo][bar]*", "*: invalid operation: can't multiply string by anything\n");
        testErrorString("12o", "1[foo]*", "*: invalid operation: can't multiply int by string\n");
        testErrorString("12p", "[foo]1*", "*: invalid operation: can't multiply string by anything\n");
        testErrorString("12q", "1.1[foo]*", "*: invalid operation: can't multiply float by string\n");
        testErrorString("12r", "[foo]1.1*", "*: invalid operation: can't multiply string by anything\n");

        System.out.println();

        // '/' operator
        testErrorString("13a", "/", "/: not enough stack items\n");
        testErrorString("13b", "1/", "/: not enough stack items\n");
        testString("13c", "1 2/p", "0\n");
        testString("13d", "1 _2/p", "0\n");
        testString("13e", "_1 2/p", "0\n");
        testString("13f", "_1 _2/p", "0\n");
        testString("13g", "0 2/p", "0\n");
        testErrorString("13h", "2 0/", "/: invalid operation: can't divide by zero\n");
        testString("13h", "4 2/p", "2\n");
        testString("13i", "2 4/p", "0\n");
        // TODO: more tests: strings, int / float, etc.

        System.out.println();

        // '=' operator
        testErrorString("14a", "=", "=: not enough stack items\n");
        testErrorString("14b", "1=", "=: not enough stack items\n");
        testString("14c", "1 1=p", "1\n");
        testString("14d", "1 2=p", "0\n");
        testString("14e", "2 1=p", "0\n");
        // NOTE: floating-point equality comparisons are a bad idea,
        // but we still support them.
        testString("14f", "1.1 1.1=p", "1\n");
        testString("14g", "1.1 1.0=p", "0\n");
        testString("14h", "[][]=p", "1\n");
        testString("14h", "[foo][]=p", "0\n");
        testString("14h", "[][foo]=p", "0\n");
        testString("14h", "[foo][bar]=p", "0\n");
        testString("14h", "[foo][foo]=p", "1\n");

        System.out.println();

        // '<' operator
        testErrorString("15a", "<", "<: not enough stack items\n");
        testErrorString("15b", "1<", "<: not enough stack items\n");
        testString("15c", "2 1<p", "0\n");
        testString("15d", "1 2<p", "1\n");
        testString("15e", "2.2 1.1<p", "0\n");
        testString("15f", "1.1 2.2<p", "1\n");
        testString("15g", "[foo][bar]<p", "0\n");
        testString("15h", "[bar][foo]<p", "1\n");
        testString("15i", "[][bar]<p", "1\n");
        testString("15j", "[bar][]<p", "0\n");
        // TODO: more tests: int < float, int < string, etc.

        System.out.println();

        // '>' operator
        testErrorString("16a", ">", ">: not enough stack items\n");
        testErrorString("16b", "1>", ">: not enough stack items\n");
        testString("16c", "2 1>p", "1\n");
        testString("16d", "1 2>p", "0\n");
        testString("16e", "2.2 1.1>p", "1\n");
        testString("16f", "1.1 2.2>p", "0\n");
        testString("16g", "[foo][bar]>p", "1\n");
        testString("16h", "[bar][foo]>p", "0\n");
        testString("16i", "[][bar]>p", "0\n");
        testString("16j", "[bar][]>p", "1\n");
        // TODO: more tests: int < float, int < string, etc.

        System.out.println();

        // '!' operator
        testErrorString("17a", "!", "!: empty stack\n");
        testString("17b", "0!p", "1\n");
        testString("17c", "1!p", "0\n");
        testString("17d", "42!p", "0\n");
        // TODO: more tests: strings, float, etc.

        System.out.println();

        // ',' - execute a stored function;
        //       ",a" is equivalent to "lax" but more concise
        testErrorString("18a", ",A", ",: registers must be in the range [a-z]\n");
        testErrorString("18b", ",a", ",: nothing in register stack\n");

        System.out.println();

        //
        // More complicated examples.
        //

        //
        // Recursive factorial function.
        //
        //   [d0=[k1][d1-,f*]?]sf
        //
        // Translation:
        //
        //   * duplicate the top of the stack
        //   * if it's 0, pop the stack and return 1
        //   * otherwise, duplicate the top of the stack,
        //     subtract 1, compute its factorial, multiply
        //     to get the factorial of the original number
        //   * give the factorial function the name "f", so ",f" calls it
        //
        testString("19a", "[d0=[k1][d1-,f*]?]sf0,fn", "1\n");
        testString("19b", "[d0=[k1][d1-,f*]?]sf1,fn", "1\n");
        testString("19c", "[d0=[k1][d1-,f*]?]sf1lfxn", "1\n");
        testString("19d", "[d0=[k1][d1-,f*]?]sf4,fn", "24\n");
        testString("19e", "[d0=[k1][d1-,f*]?]sf5,fn", "120\n");
        testString("19f", "[d0=[k1][d1-,f*]?]sf10,fn", "3628800\n");

        System.out.println();

        //
        // Recursive fibonacci function.
        //
        //   [d2<[][d1-r2-,fr,f+]?]sf
        //
        // Translation:
        //
        //   * duplicate the top of the stack
        //   * if it's less than 2, do nothing
        //   * otherwise, duplicate the top of the stack,
        //     subtract 1, swap ("rotate") the top two stack values,
        //     subtract 2, call fibonacci on both values and add them
        //   * give the fibonacci function the name "f", so ",f" calls it
        //

        testString("20a", "[d2<[][d1-r2-,fr,f+]?]sf0,fn", "0\n");
        testString("20b", "[d2<[][d1-r2-,fr,f+]?]sf1,fn", "1\n");
        testString("20c", "[d2<[][d1-r2-,fr,f+]?]sf2,fn", "1\n");
        testString("20d", "[d2<[][d1-r2-,fr,f+]?]sf3,fn", "2\n");
        testString("20e", "[d2<[][d1-r2-,fr,f+]?]sf4,fn", "3\n");
        testString("20f", "[d2<[][d1-r2-,fr,f+]?]sf5,fn", "5\n");
        testString("20g", "[d2<[][d1-r2-,fr,f+]?]sf10,fn", "55\n");
        testString("20h", "[d2<[][d1-r2-,fr,f+]?]sf20,fn", "6765\n");

        System.out.println();
        System.out.println("****************");
        System.out.println("Tests run: " + testsRun);
        System.out.println("Tests passed: " + testsPassed);
        System.out.println("****************");
    }
}
