/**
 * Values in the sc language.
 * Values can be either numbers (ints or doubles) or strings.
 * Solution set.
 */

package sc;

/**
 * The basic value class.
 * All values in the language are Values.
 */
public abstract class Value {}

class StringValue extends Value {
    private String contents;

    public StringValue(String s) {
        contents = s;
    }

    public String toString() {
        return contents.toString();
    }

    public String getContents() { return contents; }
}

class IntValue extends Value {
    private int contents;

    public IntValue(int i) {
        contents = i;
    }

    public int getContents() { return contents; }

    @Override
    public String toString() {
        return String.valueOf(contents);
    }
}

class FloatValue extends Value {
    private double contents;

    public FloatValue(double x) {
        contents = x;
    }

    public double getContents() { return contents; }

    @Override
    public String toString() {
        return String.valueOf(contents);
    }
}

