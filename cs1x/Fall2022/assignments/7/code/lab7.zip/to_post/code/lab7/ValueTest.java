/**
 * Tests for the Value classes.
 */

package sc;

import java.util.*;

public class ValueTest {
    // TODO: Set up tests so that null return values or parse errors
    // are handled correctly.
 
    private static void testError(int n, String expected, String got) {
        System.err.println("Test " + n + ": error; expected: " + expected +
          ", got: " + got);
    }

    public static void checkValue(int n, Value expected, Value got) {
       var es = expected.toString();
       var gs = got.toString();

       if (expected instanceof StringValue) {
           if (got instanceof StringValue) {
               if (!es.equals(gs)) {
                   testError(n, "\"" + es + "\"", "\"" + gs + "\"");
               }
           } else {
               testError(n, "\"" + es + "\"", gs);
           }
       } else if (expected instanceof IntValue) {
           if (got instanceof IntValue) {
               if (!es.equals(gs)) {
                   testError(n, es, gs);
               }
           } else {
               testError(n, es, gs);
           }
       } else if (expected instanceof FloatValue) {
           if (got instanceof FloatValue) {
               if (!es.equals(gs)) {
                   testError(n, es, gs);
               }
           } else {
               testError(n, es, gs);
           }
       }
    }

    public static void testString(int n, String s, Value[] vals) {
        var expected = new ArrayList<>(Arrays.asList(vals));
        var got      = new ArrayList<Value>();
        var input    = new StringInput(s);

        System.out.println("Running test " + n + " ...");

        try {
            while (true) {
                var v = Parser.parseValue(input);
                if (v == null) {
                    break;
                }
                got.add(v);
            }
        } catch (ParseErrorException e) {
            System.err.println("PARSE ERROR: " + e);
        }

        for (int i = 0; i < expected.size(); i++) {
            try {
                checkValue(n, expected.get(i), got.get(i));
            } catch (IndexOutOfBoundsException e) {
                System.err.println("missing expected value(s)");
                break;
            }
        }

        if (expected.size() < got.size()) {
             System.err.println("extra unexpected value(s)");
        }
    }

    public static void main(String[] args) {
        testString(1, "1234", new Value[] {
          new IntValue(1234)
        });
        testString(2, "1234 5678", new Value[] {
          new IntValue(1234),
          new IntValue(5678),
        });
        testString(3, "_1234 5678", new Value[] {
          new IntValue(-1234),
          new IntValue(5678),
        });
        testString(4, "1234 _5678", new Value[] {
          new IntValue(1234),
          new IntValue(-5678),
        });
        testString(5, "_1234 _5678", new Value[] {
          new IntValue(-1234),
          new IntValue(-5678),
        });
        testString(6, "0 _5678", new Value[] {
          new IntValue(0),
          new IntValue(-5678),
        });
        testString(7, "0. 0.0", new Value[] {
          new FloatValue(0.0),
          new FloatValue(0.0),
        });
        testString(8, "0.1 1.0 1.1", new Value[] {
          new FloatValue(0.1),
          new FloatValue(1.0),
          new FloatValue(1.1),
        });
        testString(9, "0.1 1. 1.0 1.1", new Value[] {
          new FloatValue(0.1),
          new FloatValue(1.0),
          new FloatValue(1.0),
          new FloatValue(1.1),
        });
        testString(10, "[] [foo] [foo bar baz]", new Value[] {
          new StringValue(""),
          new StringValue("foo"),
          new StringValue("foo bar baz"),
        });
        testString(11, "[foo [bar] baz]", new Value[] {
          new StringValue("foo [bar] baz"),
        });
        testString(12, "[foo\n[bar]\nbaz]", new Value[] {
          new StringValue("foo\n[bar]\nbaz"),
        });
        System.out.println("End of tests.");
    }
}
