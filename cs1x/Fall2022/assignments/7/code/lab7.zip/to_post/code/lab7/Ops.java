/**
 * Basic calculator operations.
 */

package sc;

/**
 * Exception class for invalid operations.
 */
class InvalidOperationException extends Exception {
    InvalidOperationException(String errorMessage) {
        super(errorMessage);
    }
}


/**
 * Interface to encapsulate operations as arguments.
 */
@FunctionalInterface
interface Operator {
    Value apply(Value v1, Value v2) throws InvalidOperationException;
}


/**
 * Class of basic operations.
 */
public class Ops {
    /**
     * Print a value.
     *
     * @param v  the value to print
     * @param quotes  if true, print quotes around a string
     */
    public static void print(Value v, boolean quotes) {
        if (v instanceof IntValue) {
            int i = ((IntValue) v).getContents();
            System.out.print(i);
        } else if (v instanceof FloatValue) {
            double f = ((FloatValue) v).getContents();
            System.out.print(f);
        } else if (v instanceof StringValue) {
            String s = ((StringValue) v).getContents();
            if (quotes) {
                System.out.print("\"" + s + "\"");
            } else {
                System.out.print(s);
            }
        }
    }

    /**
     * Add two values.
     *
     * @param v1  the first value
     * @param v2  the second value
     * @return  the sum of the two values
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like adding a string to a number)
     */
    public static Value add(Value v1, Value v2)
      throws InvalidOperationException {
        if (v1 instanceof IntValue) {
            int i1 = ((IntValue) v1).getContents();
            if (v2 instanceof IntValue) {
               int i2 = ((IntValue) v2).getContents();
               return new IntValue(i1 + i2);
            } else if (v2 instanceof FloatValue) {
               double f2 = ((FloatValue) v2).getContents();
               return new FloatValue(i1 + f2);
            } else {
                throw new InvalidOperationException(
                  "can't add number and string");
            }
        } else if (v1 instanceof FloatValue) {
            double f1 = ((FloatValue) v1).getContents();
            if (v2 instanceof IntValue) {
               int i2 = ((IntValue) v2).getContents();
               return new FloatValue(f1 + i2);
            } else if (v2 instanceof FloatValue) {
               double f2 = ((FloatValue) v2).getContents();
               return new FloatValue(f1 + f2);
            } else {
                throw new InvalidOperationException(
                  "can't add number and string");
            }
        } else if (v1 instanceof StringValue) {
            String s1 = ((StringValue) v1).getContents();
            if (v2 instanceof StringValue) {
               String s2 = ((StringValue) v2).getContents();
               return new StringValue(s1 + s2);
            } else {
                throw new InvalidOperationException(
                  "can't add string and number");
            }
        } else {
           return null;  // This should never happen.
        }
    }

    /**
     * Subtract two values.
     *
     * @param v1  the first value
     * @param v2  the second value
     * @return  the difference of the two values (second - first)
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like subtracting a string from a number)
     */
    public static Value subtract(Value v1, Value v2)
      throws InvalidOperationException {
        // TODO
    }

    /**
     * Multiply two values.
     *
     * @param v1  the first value
     * @param v2  the second value
     * @return  the product of the two values
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like multiplying a string by a number)
     */
    public static Value multiply(Value v1, Value v2)
      throws InvalidOperationException {
        // TODO
    }

    /**
     * Divide two values.
     *
     * @param v1  the first value
     * @param v2  the second value
     * @return  the quotient of the two values (second / first)
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like dividing a string by a number, or dividing by zero)
     */
    public static Value divide(Value v1, Value v2)
      throws InvalidOperationException {
        if (v1 instanceof IntValue) {
            int i1 = ((IntValue) v1).getContents();
            if (v2 instanceof IntValue) {
               int i2 = ((IntValue) v2).getContents();
               if (i2 == 0) {
                   throw new InvalidOperationException(
                     "can't divide by zero");
               }
               return new IntValue(i1 / i2);
            } else if (v2 instanceof FloatValue) {
               double f2 = ((FloatValue) v2).getContents();
               // NOTE: floating-point equality comparisons are evil!
               if (f2 == 0.0) {
                   throw new InvalidOperationException(
                     "can't divide by zero");
               }
               return new FloatValue(i1 / f2);
            } else {
                throw new InvalidOperationException(
                  "can't divide int by string");
            }
        } else if (v1 instanceof FloatValue) {
            double f1 = ((FloatValue) v1).getContents();
            if (v2 instanceof IntValue) {
               int i2 = ((IntValue) v2).getContents();
               if (i2 == 0) {
                   throw new InvalidOperationException(
                     "can't divide by zero");
               }
               return new FloatValue(f1 / i2);
            } else if (v2 instanceof FloatValue) {
               double f2 = ((FloatValue) v2).getContents();
               // NOTE: floating-point equality comparisons are evil!
               if (f2 == 0.0) {
                   throw new InvalidOperationException(
                     "can't divide by zero");
               }
               return new FloatValue(f1 / f2);
            } else {
                throw new InvalidOperationException(
                  "can't divide float by string");
            }
        } else {
            throw new InvalidOperationException(
              "can't divide string by anything");
        }
    }

    /**
     * Boolean NOT a value, which should be an integer which represents a boolean.
     * (0 means false and nonzero means true).
     *
     * @param v  the value argument
     * @return  an integer value (0 for false and 1 for true)
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like NOT-ing a non-integer)
     */
    public static Value not(Value v)
      throws InvalidOperationException {
        // TODO
    }

    /**
     * Compare two values.
     *
     * @param v1  the first value
     * @param v2  the second value
     * @return  an integer value:
     *    0 if the two values are equal
     *    1 if the second value is larger
     *   -1 if the first value is larger
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like comparing values of different types)
     *
     * NOTE: We don't compare floats to ints, even though this could be supported.
     */
    private static int compare(Value v1, Value v2)
      throws InvalidOperationException {
        if (v1 instanceof IntValue && v2 instanceof IntValue) {
            int i1 = ((IntValue) v1).getContents();
            int i2 = ((IntValue) v2).getContents();
            if (i1 < i2) {
                return -1;
            } else if (i1 == i2) {
                return 0;
            } else {
                return 1;
            }
        } else if (v1 instanceof FloatValue && v2 instanceof FloatValue) {
            double f1 = ((FloatValue) v1).getContents();
            double f2 = ((FloatValue) v2).getContents();
            if (f1 < f2) {
                return -1;
            // NOTE: floating-point equality comparison is evil!
            } else if (f1 == f2) {
                return 0;
            } else {
                return 1;
            }
        } else if (v1 instanceof StringValue && v2 instanceof StringValue) {
            String s1 = ((StringValue) v1).getContents();
            String s2 = ((StringValue) v2).getContents();
            return s1.compareTo(s2);
        } else {
            throw new InvalidOperationException(
              "can't compare different types");
        }
    }

    /**
     * Equality comparison operator.
     *
     * @param v1  the first value
     * @param v2  the second value
     * @return  an integer value: 1 if the two values are equal, otherwise 0
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like comparing values of different types)
     */
    public static Value equals(Value v1, Value v2)
      throws InvalidOperationException {
        int i = compare(v1, v2);
        // TODO
    }

    /**
     * Less-than operator.
     *
     * @param v1  the first value
     * @param v2  the second value
     * @return  an integer value: 1 if v1 < v2, otherwise 0
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like comparing values of different types)
     */
    public static Value lessThan(Value v1, Value v2)
      throws InvalidOperationException {
        int i = compare(v1, v2);
        // TODO
    }

    /**
     * Greater-than operator.
     *
     * @param v1  the first value
     * @param v2  the second value
     * @return  an integer value: 1 if v1 > v2, otherwise 0
     * @throws InvalidOperationException  if an invalid operation is attempted
     *   (like comparing values of different types)
     */
    public static Value greaterThan(Value v1, Value v2)
      throws InvalidOperationException {
        int i = compare(v1, v2);
        // TODO
    }
}
