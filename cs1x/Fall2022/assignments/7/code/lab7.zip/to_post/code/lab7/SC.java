/**
 * Stack calculator.
 */

package sc;

import java.util.*;
import java.util.function.*;
import java.math.BigDecimal;

public class SC {
    ArrayList<Input> inputs;
    Stack<Value> stack;
    Map<Character, Register> registers;

    public static void main(String[] args) {
        ArrayList<Input> inputs = Args.processArgs(args);
        SC sc = new SC(inputs);
        sc.run();
    }

    public SC(ArrayList<Input> inputs) {
        this.inputs = inputs;
        stack       = new Stack<Value>();
        registers   = new HashMap<Character, Register>();

        // Add registers, one for each letter of the alphabet.
        char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        for (char c : chars) {
             Register r = new Register();
             registers.put(c, r);
        }
    }

    /**
     * Run the calculator on all inputs.
     */
    public void run() {
        for (var input : inputs) {
            runInput(input);
        }
    }

    /**
     * Run the calculator on a single input.
     *
     * @param input  the input source
     */
    public void runInput(Input input) {
        try {
            while (true) {
                evaluate(input);
            }
        } catch (NoMoreInputException|ParseErrorException e) {}
    }

    /**
     * Parse and evaluate the input.
     *
     * @param input  the input source
     * @throws  NoMoreInputException if the input is exhausted
     * @throws  ParseErrorException if a parse error occurs
     */
    public void evaluate(Input input)
      throws NoMoreInputException, ParseErrorException {
        Value val;

        // Try to parse a value.
        // If that doesn't work, assume the input is a command.
        try {
            val = Value.parseValue(input);
            if (val == null) {
                evaluateCommand(input);
            } else {
                stack.push(val);
            }
        } catch (ParseErrorException e) {
            System.err.println("ERROR: " + e);
            if (input instanceof StdInput) {
                // If input is from stdin, execution can continue.
                return;
            } else {
                // Rethrow the error for anything but stdin input
                // so that invalid inputs can be discarded.
                throw e;
            }
        }
    }

    /**
     * Handle errors.
     * Print an error message.
     *
     * @param msg  the error message
     */
    private void handleError(String msg) {
        System.err.println(msg);
    }

    /**
     * Evaluate a command.
     *
     * @param input  the input source
     * @throws  NoMoreInputException if the input is exhausted
     * @throws  ParseErrorException if a parse error occurs
     */
    public void evaluateCommand(Input input)
      throws NoMoreInputException, ParseErrorException {
        char cmd = input.getNextChar();
        switch (cmd) {
            case 'c': {
                // Clear the stack.
                stack.clear();
                break;
            }

            case 'd': {
                // Duplicate the top stack item.
                if (stack.empty()) {
                    handleError("d: empty stack");
                } else {
                    // TODO
                }
                break;
            }

            case 'f': {
                // Print the stack non-destructively.
                // Strings are printed with surrounding quotes.
                // TODO
                break;
            }

            case 'k': {
                // Drop ("kill") the top stack item.
                // TODO
                break;
            }

            case 'l': {
                // Load a register's value by copying the top value of the
                // register stack.
                char c = input.getNextChar();
                if (c < 'a' || c > 'z') {
                    handleError("l: register must be in the range [a-z]");
                } else {
                    // TODO
                }
                break;
            }

            case 'L': {
                // Load a register's value by popping the top value of the
                // register stack.
                char c = input.getNextChar();
                if (c < 'a' || c > 'z') {
                    handleError("L: register must be in the range [a-z]");
                } else {
                    // TODO
                }
                break;
            }

            case 'n': {
                // Pop and print the top of the stack (with newline).
                if (stack.empty()) {
                    handleError("n: empty stack");
                } else {
                    // TODO
                }
                break;
            }

            case 'N': {
                // Pop and print the top of the stack (no newline).
                if (stack.empty()) {
                    handleError("N: empty stack");
                } else {
                    // TODO
                }
                break;
            }

            case 'p': {
                // Print the value at the top of the stack.
                if (stack.empty()) {
                    handleError("p: empty stack");
                } else {
                    // TODO
                }
                break;
            }

            case 'q': {
                // Quit the calculator.
                System.exit(0);
                break;  // not needed
            }

            case 'r': {
                // Swap ("rotate") the top two stack items.
                if (stack.size() < 2) {
                    handleError("r: not enough stack items");
                } else {
                    // TODO
                    break;
                }
            }

            case 's': {
                // Pop the stack and store the value into the top value
                // of a register stack.
                if (stack.empty()) {
                    handleError("s: empty stack");
                } else {
                    // TODO
                }
                break;
            }

            case 'S': {
                // Pop the stack and push the value onto a register stack.
                if (stack.empty()) {
                    handleError("S: empty stack");
                } else {
                    // TODO
                }
                break;
            }

            case 'x': {
                // Execute a string popped from the stack.
                if (stack.empty()) {
                    handleError("x: empty stack");
                } else {
                    // TODO
                }

                break;
            }

            case '?': {
                // Conditional execution:
                // Pop an int and two strings off the stack.
                // If the int is nonzero, execute the first string.
                // Otherwise, execute the second string.
                if (stack.size() < 3) {
                    handleError("?: not enough stack items");
                } else {
                    Value v1 = stack.pop();  // else
                    Value v2 = stack.pop();  // then
                    Value v3 = stack.pop();  // boolean
                    if (v3 instanceof IntValue && v2 instanceof StringValue &&
                      v1 instanceof StringValue) {
                        // TODO
                    } else {
                        handleError("?: usage: <int> <string> <string> ?");
                    }
                }
                break;
            }

            case '+': {
                // NOTE: The syntax:
                //
                //   (v1, v2) -> Ops.add(v1, v2)
                //
                // is a "lambda expression" i.e. a function argument.
                // The actual argument is of interface type Operator,
                // which is compatible with a lambda expression because
                // it defines an `apply` method which takes two Values
                // and returns a Value.
                // Reference: https://www.w3schools.com/java/java_lambda.asp
                binaryOp((v1, v2) -> Ops.add(v1, v2), "+");
                break;
            }

            case '-': {
                // TODO
                break;
            }

            case '*': {
                // TODO
                break;
            }

            case '/': {
                // TODO
                break;
            }

            case '=': {
                // TODO
                break;
            }

            case '<': {
                // TODO
                break;
            }

            case '>': {
                // TODO
                break;
            }

            case '!': {
                // Pop a value (S1) from the stack, compute !S1 (i.e. NOT S1),
                // and push back the result.
                if (stack.empty()) {
                    handleError("!: empty stack");
                } else {
                    // TODO
                }
                break;
            }

            case '#': {
                // Discard all characters up to and including the first
                // newline (\n) character.  This will work for both
                // Windows and Unix.
                while (true) {
                    char c = input.getNextChar();
                    if (c == '\n') {
                        break;
                    }
                }
                break;
            }

            case ',': {
                // Execute the (string) contents of a register.
                char c = input.getNextChar();
                if (c < 'a' || c > 'z') {
                    handleError(",: registers must be in the range [a-z]");
                } else {
                    // TODO
                }
                break;
            }

            default:
                handleError("unknown command: " + cmd);
        }
    }

    /**
     * Apply a binary operator to the stack.
     *
     * @param op     the binary operator to evaluate
     * @param opname the name of the operator (for error reporting purposes)
     */
    private void binaryOp(Operator op, String opname) {
        // Pop two values from the stack, apply the operator (S2 op S1),
        // and push back the result.
        // Handle errors internally (this function doesn't throw exceptions).
        if (stack.size() < 2) {
            handleError(opname + ": not enough stack items");
        } else {
            // TODO
        }
    }
}
