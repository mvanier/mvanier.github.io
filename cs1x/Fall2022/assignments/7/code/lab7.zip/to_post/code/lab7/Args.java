/**
 * Command-line argument processing.
 */

package sc;

import java.util.*;

public class Args {
    public static String usage = """
        Usage: java sc.SC [OPTION] [filename ...]
          -e expr  evaluate expression
          -h,      display this help message and exit
        """;

    public static String progname = "java sc.SC";

    /**
     * Go through all the command-line arguments, collect all
     * the input sources in the correct order, and print out
     * any informative messages requested.
     *
     * @param args  the command-line arguments
     * @return  a list of Inputs
     */
    public static ArrayList<Input> processArgs(String[] args) {
        ArrayList<Input> inputs = new ArrayList<Input>();
        ArrayList<Input> implicitFileInputs = new ArrayList<Input>();

        // Default with no inputs is just to read from stdin.
        if (args.length == 0) {
            inputs.add(new StdInput());
            return inputs;
        }

        // Otherwise, process the arguments as follows:
        // 1) explicit `-e` arguments
        // 2) any remaining arguments are considered to be files
        // 3) a `-` argument means to read from stdin
        //    after everything else has been done.
        // A `-h` wipes out the rest of the argument list
        // and prevents stdin from being read, and also wipes out
        // all implicit file arguments.
        boolean readStdin = false;
        int i = 0;
        while (i < args.length) {
            if (args[i].equals("-h")) {
                System.err.print(usage);
                return inputs;
            } else if (args[i].equals("-e")) {
                // Check that there is another argument.
                if (i + 1 == args.length) {
                    System.err.println(progname
                      + ": option requires an argument -- e");
                }
                // Add a new input.
                inputs.add(new StringInput(args[i+1]));
                i++;
            } else if (args[i].equals("-")) {
                readStdin = true;
            } else if (args[i].charAt(0) == '-') {
                // Invalid optional argument.  This time we print to stderr.
                if (args[i].startsWith("--")) {
                    System.err.println(progname + ": unrecognized option -- `"
                      + args[i] + "'");
                    System.err.print(usage);
                    System.exit(1);
                } else {
                    System.err.println(progname + ": invalid option -- `"
                      + args[i].substring(1) + "'");
                    System.err.print(usage);
                    System.exit(1);
                }
            } else {
                // Assume the argument is a filename.
                implicitFileInputs.add(new FileInput(args[i]));
            }
            i++;
        }

        // Add implicit file argument inputs to the inputs.
        for (i = 0; i < implicitFileInputs.size(); i++) {
            inputs.add(implicitFileInputs.get(i));
        }

        if (readStdin) {
            // Add stdin reader to inputs.
            inputs.add(new StdInput());
        }

        return inputs;
    }
}
