/**
 * Parsing values in the sc language.
 */

package sc;

import java.util.*;
import java.math.*;


/**
 * Exception class for parse errors.
 */
class ParseErrorException extends Exception {
    ParseErrorException(String errorMessage) {
        super(errorMessage);
    }
}

class Parser {
    /**
     * Parse a single value.
     *
     * @param input  the input source
     * @return  the Value parsed, or null if there is no value
     * @throws ParseErrorException  if input ends before the string is complete
     */
    public static Value parseValue(Input input) 
      throws ParseErrorException {
        // Skip whitespace characters.
        // If there are no non-whitespace characters, return `null`.
        // Get the first non-whitespace character.
        // TODO

        // Push the first non-whitespace character back to the input stream.
        // Try to parse a string if the character was '['.
        // Try to parse a number otherwise.
        // TODO
    }

    /**
     * Parse a sequence of zero or more digits from 0-9.
     *
     * @param input  the input source
     * @return  a string containing the digits parsed
     */
    public static String parseDigits(Input input) {
        // TODO
    }

    /**
     * Parse an integer with an optional leading minus (_) sign.
     * Return the string version of the integer.
     *
     * @param input  the input source
     * @throws ParseErrorException  if input ends before the string is complete
     */
    public static String parseInt(Input input) 
        throws ParseErrorException {
        boolean readingDigits = false;
        boolean negative      = false;

        // Get the digits in the integer, checking for a leading
        // '_' (minus) sign. Any other character that can't be in an int
        // terminates the int.
        try {
            while (true) {
                char c = input.getNextChar();
                if (c == '_') {
                    if (negative) {
                        throw new ParseErrorException(
                          "two consecutive minus signs");
                    } else {
                        negative = true;
                    }
                } else {
                    input.putCharBack(c);  // Replace character parsed.
                    String intChars = parseDigits(input);
                    if (intChars == "") {
                        if (negative) {
                            throw new ParseErrorException(
                              "minus sign not followed by digits");
                        } else {
                            // No integer to parse.
                            return null;
                        }
                    } else {
                        if (negative) {
                            intChars = "-" + intChars;
                        }
                        return intChars;
                    }
                }
            }
        } catch (NoMoreInputException e) {
            return null;
        }
    }

    /**
     * Parse a number.  Try to parse it as a float; if that doesn't work,
     * try to parse it as an int.
     * Return null if there is no parse.
     * Floats are required to have at least one digit before the decimal point.
     *
     * @param input  the input source
     * @return the Value parsed
     * @throws ParseErrorException  if a parse error occurs
     */
    public static Value parseNumber(Input input)
        throws ParseErrorException {
        // TODO
    }

    /**
     * Parse a string.
     * A string starts with '[', ends with ']',
     * doesn't contain the starting or ending square brackets.
     * and can contain internal square brackets.
     *
     * @param input  the input source
     * @return  the StringValue parsed, or `null` if unsuccessful.
     * @throws ParseErrorException  if input ends before the string is complete
     */
    public static StringValue parseString(Input input)
      throws ParseErrorException {
        // TODO
    }
}

