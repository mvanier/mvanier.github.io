/**
 * Classes for terminal, file, and string inputs.
 */

package sc;

import java.io.*;
import java.util.*;

/** Class whose instances are thrown when there is no more input. */
class NoMoreInputException extends Exception {}

/** Abstract class representing input to the calculator. */
public abstract class Input {
    ArrayDeque<Character> current;
    int index;
    int lastIndex;

    /**
     * Get the next character, reloading if necessary.
     *
     * @return  the next character
     * @throws  NoMoreInputException if there is no more input
     */
    public char getNextChar() throws NoMoreInputException {
        if (current.isEmpty()) {
            reload();
        }
        return current.removeFirst();
    }

    /**
     * Put a character back into the character buffer at the beginning.
     *
     * @param c  the character to put back into the buffer
     */
    public void putCharBack(char c) {
        current.addFirst(c);
    }

    /**
     * Reload the current string buffer when more input is needed.
     *
     * @throws NoMoreInputException  if there is no more input
     */
    public abstract void reload() throws NoMoreInputException;
}

/** Input from a file. */
class FileInput extends Input {
    private BufferedReader br;
    boolean closed;

    public FileInput(String filename) {
        current = new ArrayDeque<Character>();
        try {
            br = new BufferedReader(new FileReader(filename));
            closed = false;
        } catch (FileNotFoundException e) {
            System.err.println(e);
            closed = true;
        }
    }

    public void reload() throws NoMoreInputException {
        // Add the characters from the next line of the file
        // (if there is one) to the buffer.
        if (closed) {
            throw new NoMoreInputException();
        }

        // TODO
    }
}


/** Input from a string. */
class StringInput extends Input {
    public StringInput(String s) {
        current = new ArrayDeque<Character>();
        // TODO
    }

    public void reload() throws NoMoreInputException {
        // String input can't be reloaded.
        throw new NoMoreInputException();
    }
}


/** Input from standard input (terminal input). */
class StdInput extends Input {
    private Scanner sc;

    public StdInput() {
        current = new ArrayDeque<Character>();
        sc = new Scanner(System.in);
    }

    public void reload() throws NoMoreInputException {
        // Get the next line from stdin if it hasn't been closed.
        // Make sure it has a newline character at the end.
        // TODO
    }
}

