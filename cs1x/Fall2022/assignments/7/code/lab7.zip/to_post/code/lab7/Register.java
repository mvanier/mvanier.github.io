/**
 * Implementation of registers.
 */

package sc;

import java.util.*;

/**
 * A register is a stack of values.
 * It can be used as a stack or as a place to store/load a single value.
 */
public class Register {
    private Stack<Value> stack;

    public Register() {
        stack = new Stack<Value>();
    }

    /**
     * Return `true` if the register (stack) is empty.
     *
     * @return  `true` if the stack is empty, otherwise `false`
     */
    public boolean empty() {
        // TODO
    }

    /**
     * Store a value at the top of the stack, replacing the existing value.
     * If the stack is empty, push the value.
     *
     * @param v  the value to store
     */
    public void storeTop(Value v) {
        // TODO
    }

    /**
     * Store a value into the stack by pushing
     * onto the existing stack.
     *
     * @param v  the value to store
     */
    public void storePush(Value v) {
        // TODO
    }

    /**
     * Copy and return the top value of the stack.
     *
     * @return the top value of the stack
     * @throws EmptyStackException if the stack is empty
     */
    public Value loadTop()
      throws EmptyStackException {
        // TODO
    }

    /**
     * Pop and return the top value of the stack.
     *
     * @return the top value of the stack
     * @throws EmptyStackException if the stack is empty
     */
    public Value loadPop()
      throws EmptyStackException {
        // TODO
    }
}
