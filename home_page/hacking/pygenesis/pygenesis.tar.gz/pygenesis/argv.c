#include <stdlib.h>
#include <string.h>

extern void StringToArgList(); /* defined in shell/shell_argv.c */

#define WORKING_STRLEN 1024

/*
 * This is a version of string_to_arg_list which is meant to be
 * used as an interface to genesis functions.  It not only turns
 * a string into an arglist, it also puts the function name (which
 * has to be supplied) in as the first argument.
 */


void genesis_string_to_arglist( char *funcname, char *string, int *argc, char ***argv )
{
  char wstring[WORKING_STRLEN]; /* "Working" string length. */

  /*
   * This is a hack.  We prepend the function name to the front of the
   * arglist.
   */

  strcpy( wstring, funcname );
  strcat( wstring, " " );
  strcat( wstring, string );

  StringToArgList( wstring, argc, argv, 0 );
}


