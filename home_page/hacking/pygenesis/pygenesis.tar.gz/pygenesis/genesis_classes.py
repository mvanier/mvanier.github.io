#
# genesis_classes.py
#

import string
import sys
from gen import cwe
from genesis_wrappers import *

#
# This file is for python class wrappers around genesis
# objects.  
#

#
# object names:
#

objectnames = string.split( gen.ListObjectsAsString() )
objectnames.sort()

#
# _ is a global variable used to store the most-recently-created
# instance of a genesis class.  It has to be in the global scope;
# hence the exec statement.
#

import __main__
exec "_ = None" in __main__.__dict__, __main__.__dict__


#
# Utility functions.
#

#
# Build a list of the actions for a genesis object.
#

def GetActions( object ):
    actionstr = gen.GetActionsAsString( object )
    list = string.split( actionstr )

    #
    # Remove duplicates from list.  Some actions that
    # are added after the original object definition
    # can occur twice in the action list.
    #

    dict = {}
    for action in list:
	dict[action] = 1

    list = dict.keys()
    list.sort()
    return list


#
# "GenesisAction" is a class to get around the lack of proper closures 
# in python.  It allows me to return an action function which takes
# a variable number of arguments.
#

class GenesisAction:
    #
    # "name" is the action name.
    # "path" is the full element pathname.
    #

    def __init__( self, path, name ):
	self.path = path
        self.name = name

    #
    # When the action instance is returned it
    # can behave like a function that accepts
    # an arbitrary number of arguments.
    #
 
    def __call__( self, *args ):
	argstr = ""

	for arg in args:
	    argstr = argstr + " " + str( arg )

        call( self.path, self.name, argstr )


#
# "GenesisObject" is an abstract base class for all other genesis object 
# classes.  It provides most if not all of the functionality of those classes.
#

class GenesisObject:
    #
    # Figure out what the absolute pathname is and
    # set "path" to it.
    #

    def _setpath( self, pathname ):
	if pathname[0] != "/":
	    if cwe() != '/':
		self.__dict__['path'] = cwe() + '/' + pathname
	    else:
		self.__dict__['path'] = '/' + pathname
	else:
	    self.__dict__['path'] = pathname

    # ----------------------------------------------------------------------
    # Access control functions.  Trying to set a value is construed 
    # as being trying to do a setfield.  Trying to get a value
    # is construed as being either a getfield (default) or 
    # IF the attribute name is one of the valid actions for 
    # the object, then it's assumed to be a method call (i.e.
    # it calls the "call" function in genesis).
    #
    # Note that the attribute "field" is a special case, intended 
    # to be used when the genesis field name is something that is 
    # too gnarly for python syntax to handle e.g.
    #
    #     print chan.field( 'X_A->table[10]' )
    #
    # In fact, I really wish I could do this:
    #
    #     chan.field( 'X_A->table[10]' ) = 0.5
    #
    # but this fails since in python you can't use a function call
    # on the lhs of an assignment statement.  Oh well, nothing is 
    # infinitely flexible, not even python :-(  Instead, I have to
    # do this:
    #
    #     chan.set( 'X_A->table[10]', 0.5 )
    #
    # which is not too gross.  For uniformity I also allow the word
    # "get" as a synonym for "field" (since I use "set" below as well).
    # ----------------------------------------------------------------------

    def __setattr__( self, name, value ):
	if not is_string( value ):
	    set( "%s %s %s" % ( self.__dict__['path'], name, str( value ) ) )
	else:
	    #
	    # If it's a string we have to wrap it in double quotes.
	    #
	    set( "%s %s \"%s\"" % ( self.__dict__['path'], name, str( value ) ) )


    def __getattr__( self, name ):
	if name in self.__dict__['actions']:
	    #
	    # We have to return an action "function" (here it's actually a
	    # GenesisAction instance that behaves like a function).
	    #

	    return GenesisAction( self.__dict__['path'], name )

	elif name == "field" or name == "get":
	    def field( fieldname, path = self.__dict__['path'] ):
		return getfield( path, fieldname )

	    return field

	else:
	    cmd = self.__dict__['path'] + " " + name
	    return get( self.__dict__['path'] + " " + name )

    def set( self, name, val ):
	argstr = "%s %s %s" % ( self.__dict__['path'], name, val )
	setfield( argstr )

    #
    # Other goodies.
    #

    def __repr__( self ):
	return "%s: %s" % ( self.type, self.__dict__['path'] )

    def show( self ):
	showfield( self.__dict__['path'] + ' *' )

    def showall( self ):
	showfield( self.__dict__['path'] + ' **' )

    def showinfo( self ):
	showfield( self.__dict__['path'] + ' ***' )



#
# Specific genesis classes.  These all have the same form.
#

class_template = '''
class %s( GenesisObject ):
    type = "%s"

    def __init__( self, pathname, new = 1 ):
	#
	# Set the absolute path.
	#

	self._setpath( pathname )

	#
	# Create the element if desired.
	#

	if new:
	    create( '%s', self.__dict__['path'] )

	#
	# Get the list of permissible actions for the element.
	#

	self.__dict__['actions'] = GetActions( self.type )

	#
	# Assign this instance to the default element name.
	#

	import __main__
	__main__.__dict__['_'] = self
''' 


#
# Wrappers for all the classes.  These also all have the same form.
# They are used to wrap pre-existing elements of known type with a
# pygenesis class.  They are almost identical to the element() function
# described below, except that they check that the element being wrapped 
# is of the correct type.
#

NonexistentElement = "NonexistentElement"
WrongElement = "WrongElement"

class_wrapper_template = '''
def %s( name = "." ):
    #
    # Get the full pathname.
    #

    if name == ".":
	pathname = cwe()
    elif name[0] != "/":
	pathname = cwe() + name
    else:
	pathname = name

    if not exists( pathname ):
	raise NonexistentElement, "Element %%s does not exist!" %% pathname

    type = get( pathname, 'object->name' )

    if type != "%s":
	raise WrongElement, "Element %%s is not a %s!" %% name

    #
    # Now that we have the type, create and return the object.
    #

    exec( "elem = %%s( '%%s', 0 )" %% ( type, pathname ) )

    return elem
'''


#
# Create all the classes.  
#

for obj in objectnames:
    exec( class_template % ( obj, obj, obj ) )
    name = obj + "_"
    exec( class_wrapper_template % ( name, obj, obj ) )


#
# "element" is a function which creates a python object around an
# arbitrary preexisting genesis object.  You can call it like this:
#
#     element( '/foo' ) # to wrap element /foo
#
# or
#
#     element() # to wrap current working element
#

def element( name = "." ):
    #
    # Get the full pathname.
    #

    if name == ".":
	pathname = cwe()
    elif name[0] != "/":
	pathname = cwe() + name
    else:
	pathname = name

    if not exists( pathname ):
	raise NonexistentElement, "Element %s does not exist!" % pathname

    type = get( pathname, 'object->name' )

    #
    # Now that we have the type, create and return the object.
    #

    exec( "elem = %s( '%s', 0 )" % ( type, pathname ) )

    return elem

