#
# genesis.py -- pygenesis initialization script.
#

#
# This is the file which is imported by other files intending
# to use genesis functions.  This file is mainly for initializing
# pygenesis and for defining some "non-standard" wrapper functions 
# that don't conform to the usual form, plus additional helper 
# functions.  In some cases these functions override earlier versions.
#

# ======================================================================
#
#              Initialization of pygenesis.
#
# ======================================================================

#
# Python services we want by default.
#

import os
import sys
import string
import types
from math import *
import whrandom # Random number generator.


#
# Load the standard wrapper functions.
#

from genesis_wrappers import *

#
# Load the default simulation schedule.
#

deletetasks()
 
addtask( 'Simulate /##[CLASS=buffer]      -action INIT' )
addtask( 'Simulate /##[CLASS=segment]     -action INIT' )
 
addtask( 'Simulate /##[CLASS=buffer]      -action PROCESS' )
addtask( 'Simulate /##[CLASS=projection]  -action PROCESS' )
addtask( 'Simulate /##[CLASS=spiking]     -action PROCESS' )
addtask( 'Simulate /##[CLASS=gate]        -action PROCESS' )
addtask( 'Simulate /##[CLASS=segment][CLASS!=membrane][CLASS!=gate][CLASS!=concentration] -action PROCESS' )
 
addtask( 'Simulate /##[CLASS=membrane]  -action PROCESS' )
addtask( 'Simulate /##[CLASS=hsolver]   -action PROCESS' )
addtask( 'Simulate /##[CLASS=concentration]     -action PROCESS' )
 
addtask( 'Simulate /##[CLASS=device]    -action PROCESS' )
addtask( 'Simulate /##[CLASS=output]    -action PROCESS' )
 
resched()

#
# Set up the cellreader.
#

initcellreader()

#
# Other stuff.
#

floatformat( "%g" )


# ======================================================================
#
#             Utility functions.
#
# ======================================================================

#
# This function turns numeric strings into their corresponding numbers
# but leaves all other strings untouched.  It is used by get().
#

def eval_number( numstr ):
    import string
    try:
	val = string.atoi( numstr )
    except ValueError:
	try:
	    val = string.atof( numstr )
	except ValueError:
	    val = numstr

    return val


	    
#
# This function tests if its argument is a dictionary.
#

def is_dict( d ):
    return type( d ) == types.DictType


#
# This function tests if its argument is a string.
#

def is_string( d ):
    return type( d ) == types.StringType

#
# This function turns a tuple into a list.
#

def tuple2list( tup ):
    list = []
    for i in range( len( tup ) ):
	list.append( tup[i] )

    return list


#
# This function takes all string entries in a
# dictionary and puts single quotes around them.
# This seems silly, but it's necessary in order
# for dict2str to work (which in turn makes set 
# work).
#
# KLUDGE ALERT: If you are going to use quoted
#               strings in set(), use double-quotes
#               or this WILL NOT WORK!
#

def munge_dict( dict ):
    for key in dict.keys():
        entry = dict[key]
        if is_string( entry ):
            dict[key] = "'" + entry + "'"
    return dict

#
# This function converts a dictionary to a string.  This
# is useful in passing arguments to set.
#

def dict2str( dict ):
    formatstr = ""
    for i in dict.keys():
	formatstr = formatstr + i + " %(" + i + ")s "
    dict = munge_dict( dict )
    return formatstr % dict



# ======================================================================
#
#             Genesis-specific utility functions.
#
# ======================================================================

#
# Return the current working element as a string.
#

from gen import cwe

#
# Load the (py)genesis classes, which are class wrappers around 
# genesis objects.  This has to be done here since the classes
# depend on stuff defined above.
#

pygenesis_home = os.environ['PYGENESIS_HOME']
execfile( pygenesis_home + '/genesis_classes.py' )

#
# Load the string interpolation module.
#

from Itpl import itpl2


# ======================================================================
#
#           Non-standard genesis wrapper functions.
#
# ======================================================================

# ----------------------------------------------------------------------
#
#                   sim library functions:
#
# ----------------------------------------------------------------------

#
# This is the "setfield" wrapper function. I use the word "set" 
# instead of "setfield" because I hate the pseudo-word "setfield".
#
# set can take these arguments in addition to the standard ones 
# for pygenesis wrapper functions:
#
#     set( ['/element', ] { 'var1': val1, 'var2': val2, ...} )
#
# We also do string interpolations, so we can write things like this:
#
#     set( '/element', { 'var[$i]' :val } )
#
# NOTE: since interpolation will look back in the
# stack until it finds what it wants, we have to use
# great care to avoid name conflicts.  In particular,
# we have to use _ to start all our variable names.
#

def set(*_args, **_kw):
    _largs = len(_args)

    _argstr = ''

    #
    # Process the non-keyword arguments.
    # Do interpolation if any is needed.
    #

    if _largs == 1:    # string or dict
	if is_string(_args[0]):
	    _argstr = itpl2(_args[0], 2)
	elif is_dict(_args[0]):         
	    _argstr = itpl2(dict2str(_args[0]), 2)
	else:
	    raise ArgsError, "set: first argument must be string or dictionary!"
    elif _largs == 2:  # string, dict
	if not is_string(_args[0]):
	    raise ArgsError, "set: first argument must be string or dictionary!"
	elif not is_dict(_args[1]):
	    raise ArgsError, "set: second argument must be dictionary!"
	else:
	    _argstr = itpl2(_args[0] + " " + dict2str(_args[1]), 2)
    else:
	raise ArgsError, "set: only two arguments allowed!"

    return gen.genesis__set(_argstr)


#
# get (getfield).  This function returns a string which may be a
# number (actually, it usually is), so we do an eval_number() at the end 
# if we get anything back from genesis.  We also do interpolation on the 
# field; the same considerations described for set() apply here.
#

def get(*_args):
    _largs = len(_args)

    if _largs < 1 or _largs > 2:
	return gen.genesis__get('')
    elif _largs == 1:
	#
	# A single string argument to function;
	# interpolate if necessary.
	#
	_cmd = itpl2(_args[0], 2)
    else:
	_path  = _args[0]
	_value = itpl2(_args[1], 2)
	_cmd = _path + " " + _value

    _returnval = gen.genesis__get(_cmd)

    if _returnval:
	#
	# If the string represents a number,
	# evaluate it and return the number.
	# Otherwise just return the string.
	#
	return eval_number(_returnval)
    else:
	#
	# If there's an error nothing is returned.
	#
	return None


#
# create.  This is the same as the generic wrapper function
# except that if the first argument is a (python) class we
# use the class type field.
#

def create( *args, **kw ):
    if type( args[0] ) == types.ClassType:
	#
	# We have to change the tabchannel "object" into
	# a string representing its type.  First we change
	# the args tuple into a list, then substitute for
	# the first value, then turn it back into a tuple.
	#
	
	arglist = []
	
	for i in range( len( args ) ):
	    arglist.append( args[i] )
	    
        arglist[0] = args[0].type
	args = tuple( arglist )

    return gen.genesis__create( make_cmdstr( args, kw ) )


#
# The old "cl -f" function.
#

def cl():
    deleteall( '-f' )


#
# step_t is an abbreviation for step( time, '-t' )
#

def step_t( time ):
    return gen.genesis__step( `time` + ' -t' )


def silent( *args ):
    largs = len( args )

    if largs == 0:
	#
	# Return the current silent status.
	#
	return gen.genesis__silent('')
    elif largs > 1:
	#
	# FIXME! Raise an error here?
	#
	cmd = ''
    else:
	cmd = `args[0]`

    #
    # If we're changing the silent status,
    # don't return anything.
    #

    gen.genesis__silent( cmd )


# ----------------------------------------------------------------------
#
#                   olf library functions:
#
# ----------------------------------------------------------------------


#
# setupalpha
#
# KLUDGE ALERT: we use "xrange" here because "range"
# is one of the options to the function!!!
#

def setupalpha( *args, **opts ):
    largs = len( args )

    #
    # We need at least 12 arguments:
    # element name, gate, and 10 numeric arguments.
    #

    argstr = ""

    if largs == 12:
	for i in xrange( 12 ):
	    argstr = argstr + "%s " % args[i]

    #
    # Process the rest of the arguments. 
    # They include: -size n -range min max
    # Use keyword arguments for this.
    #

    try:  # Is there a "size" keyword?
	size  = opts['size']
    except KeyError:  # Nope.
	pass
    else: # Yup.
	argstr = argstr + "-size %s " % size
	
    try:  # Is there a "range" keyword?
	range = opts['range']
    except KeyError:
	pass
    else:
	argstr = argstr + "-range %s %s " % range

    return gen.genesis__setupalpha( argstr )


# ----------------------------------------------------------------------
#
#                     non-library functions:
#
# ----------------------------------------------------------------------

#
# A function that mimics the genesis "include" statement
# (except that you can pass string variables to it, of
# course!).  
#
# FIXME: set it up so there is a genesis search path that is
# searched through.
#

def include( filename ):
    if filename[-3:] != '.py':
	filename = filename + '.py'
    
    cmd = "execfile( '" + filename + "' )"
    import __main__
    exec cmd in __main__.__dict__, __main__.__dict__


#
# quit command -- and why not?
#

def quit():
    raise SystemExit


#
# Random number functions.
#

def randseed( new_seed ):
    if type( new_seed ) != types.IntType:
	raise ArgsError, "randseed: argument must be an integer!"

    #
    # The following is bogus; I'm just doing a hack to change a single
    # seed into three.
    #

    whrandom.seed( new_seed, int( sqrt( new_seed ) ), int( new_seed ** 2.345 ) )


def rand( lo, hi ):
    if lo >= hi:
	raise ArgsError, "rand: usage: rand( lo, hi); lo must be lower than hi!"
    num = whrandom.random() * ( hi - lo ) + lo
    return num


	

#
# Functions that need better wrappers:
#
# getfield -- need eval() at end
#
# addmsg?
#
# setfield: what about setfield ^ field val ... stuff?
# -- also too bad you have to do this kind of thing:
#    set( 'my_tabchan', { 'X_A->table[%d]' % i : 0.34 } )
#    -- if there was interpolation it'd be much nicer
#    -- could fake it with eval, maybe...
#
# call
#
# tweaktau
#
# scaletabchan
#
# addfield
#
# setmethod
#
# showfield
#





 
# ======================================================================
#
#                  Standard "aliases" I use.
#
# ======================================================================

q  = quit
s  = show
sf = set
sm = showmsg 
cm = listcommands
lo = listobjects

#
# For backwards-compatibility...
#

setfield  = set
getfield  = get
showfield = show


# ==============================================================
#
#                 Miscellaneous other stuff.
#
# ==============================================================

#
# Execute a string as a command, much like the standard
# genesis interpreter.  This is a primitive SLI interpreter :-)
#
# IMPROVEME!  -- add the ability to handle args in {}
#             -- add command completion
#             -- add element-name completion
#

def gexec( str ):
    strlist = string.split( str )

    if len( strlist ) > 1:
	args = " "
	for i in range( 1, len( strlist ) ):
	    args = args + strlist[i] + " "
	cmd = strlist[0] + "('" + args + "')"
    else:
	cmd = strlist[0] + "()"

    exec( cmd )


#
# Execute a series of one-liner commands using gexec.  You
# get out of this using control-c.  This is useful for
# debugging simulations.  It is NOT meant to be used in
# scripts.
#

shell_prompt = "genesis> "


def set_shell_prompt( str ):
    global shell_prompt

    if is_string( str ):
	shell_prompt = str


def gsh():
    global shell_prompt

    print
    print "Entering pygenesis shell mode..."
    print

    while 1:
	try:
	    str = raw_input( shell_prompt )
	except KeyboardInterrupt:
	    print
	    print
	    print "Exiting pygenesis shell mode..."
	    print
	    break
	else:
	    if str:
		gexec( str )


