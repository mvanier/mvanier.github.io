"""Itpl, string interpolation for Python (by Ka-Ping Yee, 20 Oct 1996)
   Heavily modified by Mike Vanier, April/May 1997"""

import sys, string
from types import StringType, TupleType
from tokenize import tokenprog

#
# ItplError means a real error.  BogusError is a bogus error
# used solely to get the stack frame.
#

ItplError = "ItplError"
BogusError = "BogusError"

class Itpl:
    def __init__(self, fmt):
        if type(fmt) != StringType:
            raise TypeError, "needs string initializer"

        namechars = 'abcdefghijklmnopqrstuvwxyz' \
            'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_';
        chunks = []
        pos = 0

        try:
            while 1:
                dollar = string.index(fmt, '$', pos)
                nextchar = fmt[dollar+1]

                if nextchar == '{':
                    chunks.append((0, fmt[pos:dollar]))
                    pos, level = (dollar + 2), 1

                    while level:
                        pos = pos + tokenprog.match(fmt, pos)
                        tstart, tend = tokenprog.regs[3]
                        token = fmt[tstart:tend]

                        if token == '{': 
			    level = level + 1
                        elif token == '}': 
			    level = level - 1

                    chunks.append((1, fmt[dollar+2:pos-1]))

                elif nextchar in namechars:
                    chunks.append((0, fmt[pos:dollar]))
                    pos = dollar + 1
                    pos = pos + tokenprog.match(fmt, pos)

                    while pos < len(fmt):
                        if fmt[pos] == '.'  and \
			   pos+1 < len(fmt) and \
			   fmt[pos+1] in namechars:
                            pos = pos + 2
                            pos = pos + tokenprog.match(fmt, pos)
                        elif fmt[pos] in '([':
                            pos, level = pos + 1, 1

                            while level:
                                pos = pos + tokenprog.match(fmt, pos)
                                tstart, tend = tokenprog.regs[3]
                                token = fmt[tstart:tend]

                                if token[0] in '([': 
				    level = level + 1
                                elif token[0] in ')]': 
				    level = level - 1
                        else: 
			    break

                    chunks.append((1, fmt[dollar+1:pos]))

                else:
                    chunks.append((0, fmt[pos:dollar+1]))
                    pos = dollar + 1 + (nextchar == '$')

        except TypeError:       # token regex did not match, regs[] failed
            import traceback
            traceback.print_exc()
            raise ItplError, "unfinished expression"

        except ValueError:      # index did not find a dollar sign
            pass

        if pos < len(fmt): 
	    chunks.append((0, fmt[pos:]))

        self.chunks = chunks


    #
    # This function turns the Itpl object back into a string with the
    # interpolated parts switched to the variables they represent.
    # The "n" argument is the number of extra stack frames to go 
    # back to find the argument.  If make_string is used from the
    # top level of a program, n will be zero.  This is not maximally
    # flexible (see make_string2 for a different solution).
    #

    def make_string(self, n):
        try: 
	    raise BogusError # A hack to get the stack frame.
        except: 
	    frame = sys.exc_traceback.tb_frame

	#
	# Backtrack until you're out of this (Itpl) module.
	#

        while frame.f_globals['__name__'] == __name__: 
	    frame = frame.f_back

	#
	# Now backtrack an extra n frames.
	#

	for i in range(n):
	    frame = frame.f_back
	    if not frame:
		raise ItplError, "No more stack frames!"

        loc, glob = frame.f_locals, frame.f_globals

        result = []

        for live, chunk in self.chunks:
            if live: 
		#
		# "live" means we have a variable that needs
		# interpolation.  "chunkroot" is the variable
		# root i.e. the actual variable name, without
		# any subscripts etc.  We use a _really_ crude
		# algorithm to get chunkroot which may not
		# work in all cases.
		#

		_i = 0
		while _i < len(chunk):
		    if chunk[_i] == '[':
			break
		    else:
			_i = _i + 1

		chunkroot = chunk[:_i]

		if chunkroot not in loc.keys() and \
		   chunkroot not in glob.keys():
		    raise ItplError, "variable %s not found!" % chunk

		#
		# Evaluate the chunk in the appropriate namespaces.
		#

		result.append(str(eval(chunk, loc, glob)))
            else: 
		result.append(chunk)

        return string.join( result, '' )


    #
    # This version of make_string goes back through the stack until
    # it finds what it wants, or until at most n extra stack frames
    # have been backtracked through.
    #

    def make_string2(self, n):
        try: 
	    raise BogusError  # A hack to get the stack frame.
        except: 
	    frame = sys.exc_traceback.tb_frame

	#
	# Backtrack until you're out of this (Itpl) module.
	#

        while frame.f_globals['__name__'] == __name__: 
	    frame = frame.f_back

	loc, glob = frame.f_locals, frame.f_globals
	oldframe = frame  # Save the stack frame.
        result = []

        for live, chunk in self.chunks:
            if live: 
		#
		# "live" means we have a variable that needs
		# interpolation.  "chunkroot" is the variable
		# root i.e. the actual variable name, without
		# any subscripts etc.  We use a _really_ crude
		# algorithm to get chunkroot which may not
		# work in all cases.
		#

		if frame != oldframe:  # Start with the original frame.
		    frame = oldframe
		    loc, glob = frame.f_locals, frame.f_globals

		frame_index = 0

		_i = 0
		while _i < len(chunk):
		    if chunk[_i] == '[':
			break
		    else:
			_i = _i + 1

		chunkroot = chunk[:_i]

		while 1:
		    if chunkroot not in loc.keys() and \
		       chunkroot not in glob.keys():
		       #
		       # Backtrack up to n more stack frames until
		       # we find what we're looking for.
		       #
		       
		       frame = frame.f_back
		       frame_index = frame_index + 1

		       if not frame:
			   raise ItplError, "variable %s not found!" % chunk
		       elif frame_index > n:
			   raise ItplError, "Exceeded depth of search: %d extra frames" % n

		       loc, glob = frame.f_locals, frame.f_globals
		    else:
			break

		# Evaluate the chunk in the appropriate namespaces.
		result.append(str(eval(chunk, loc, glob)))
            else: 
		result.append(chunk)

        return string.join( result, '' )

#
# This function looks at a specific frame only.
#

def itpl(_str, n = 0): 
    if type(_str) == StringType:
	it = Itpl(_str)
	return it.make_string(n)
    else:
	return str(_str)


#
# This function looks up to a specific frame, stopping
# when it finds a variable with the correct name.  This
# can be dangerous!
#

def itpl2(_str, n = 0):
    if type(_str) == StringType:
	it = Itpl(_str)
	return it.make_string2(n)
    else:
	return str(_str)

