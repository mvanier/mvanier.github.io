/*
 * sim_main.c
 *
 * This is NOT the default version.  This version of the file is
 * by Mike Vanier and is for use with the python-genesis interface
 * ONLY!
 */

#ifdef sgi
#include <malloc.h>
#endif

#include <setjmp.h>
#include "sim.h"
#include "system_deps.h"
#include "hash.h"

#define BUFFERSIZE 1024

char	**global_envp;
jmp_buf main_context;

extern char          *CopyString();
extern GenesisObject *GetObject();


/***********************************************************************
 *
 * Various useful helper functions.
 *
 ***********************************************************************/

/*
 * Return current working element as a string.
 */

char *cwe()
{
    return CopyString( Pathname( WorkingElement() ) );
}


/*
 * Return string containing list of all actions for a given object.
 */

char *GetActionsAsString( objectname )
  char *objectname;
{
  GenesisObject *object;
  ActionList    *alist;
  char           actionlist[BUFFERSIZE];

  object = GetObject( objectname );

  strcpy( actionlist, "" );

  if ( object != NULL )
    {
      if ( object->valid_actions )
	{
	  for ( alist = object->valid_actions; alist; alist = alist->next )
	    {
	      strcat( actionlist, alist->name );
	      strcat( actionlist, " " );
	    }
	}
    }

  return ( CopyString( actionlist ) );  /* CORE LEAK! */
}


/*
 * This function is like do_list_objects() but it returns the object 
 * list as a string.
 */

char *ListObjectsAsString()
{
  extern HASH  *object_hash_table;
  char         *name;
  int           cnt = 0;
  int           i, bufsize;
  char        **namelist;
  char         *output_string;
 
  /*
   * Count the objects.
   */

    for ( i = 0; i < object_hash_table->size; i++ )
      {
        if ( name = object_hash_table->entry[i].key )
	  {
            cnt++;
	  }
      }

    if ( cnt < 1 )
      {
	return;  /* No objects? */
      }

    /*
     * Make the list.
     */

    namelist = (char **) malloc( sizeof( char* ) * cnt );
    cnt      = 0;
    bufsize  = 0;

    for ( i = 0; i < object_hash_table->size; i++ )
      {
	if ( name = object_hash_table->entry[i].key )
	  {
            namelist[cnt++] = name;
	    bufsize += strlen( name ) + 1; /* Add an extra space for a space. */
	  }
      }

    /*
     * Make the string containing all list entries.
     */

    output_string = (char *) malloc( bufsize );
    strcpy( output_string, "" );

    for ( i = 0; i < cnt; i++ )
      {
	strcat( output_string, namelist[i] );
	strcat( output_string, " " );
      }

    free ( namelist );
    return ( output_string ); /* CORE LEAK! */
}


/***********************************************************************
 *
 * Main initialization function.  genesis_init() replaces main().
 *
 ***********************************************************************/

void genesis_init()
{
  /*
   * MCV: turn off tty and set batch mode here;
   *      we don't want genesis terminal handling...
   */
  
  SetBatchMode(1);
#ifdef SYSV
  setvbuf(stdout, NULL, _IOLBF, BUFSIZ);
#else
  setlinebuf(stdout);
#endif
  SetTtyMode(0);

  set_float_format("%g");
  sim_set_float_format("%g");
  
  if (!SetupInterp("genesis")) /* FIXME! This is totally BOGUS! */
    {
      if (IsSilent() < 2) 
	{
	  printf("Unable to find the simulator. ");
	  printf("Check your PATH environment variable\n");
	}
      exit(0);
    };
  
  /*
   * initialization for the base simulator
   */

  SimStartup();
  sleep(2);  /* huh? why do we need this? */
  
  /*
   * Load the symbolic information for the rest of the libraries.
   */

  LOAD_LIBRARIES();
}

