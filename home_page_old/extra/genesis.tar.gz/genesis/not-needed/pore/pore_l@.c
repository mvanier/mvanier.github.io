LIBRARY_pore()
{
LibraryHeader("pore","Wed May  5 19:24:38 1999 ");DATA_pore();
STARTUP_pore();
}
