/*
** $Id: pore_ext.h,v 2.1.1.1 1999/03/17 07:53:45 mhucka Exp $
** $Log: pore_ext.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:45  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:03:51  dhb
** Initial revision
**
*/

/*************************************************************************/
/*Adam Franklin Strassberg*/
/*March 15, 1992*/
/*Header file pore_ext.h*/
/*************************************************************************/

#include "sim_ext.h"
#include "pore_struct.h"


/*************************************************************************/
/*Primitive Functions*/
double RAN();
double RATE();
double POWER();
/*************************************************************************/
