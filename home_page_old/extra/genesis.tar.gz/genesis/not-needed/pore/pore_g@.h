#define Napores_VOLTAGE 0
#define Kpores_VOLTAGE 0
