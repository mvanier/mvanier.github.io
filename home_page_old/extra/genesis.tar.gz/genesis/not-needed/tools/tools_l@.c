LIBRARY_tools()
{
LibraryHeader("tools","Wed May  5 19:24:32 1999 ");DATA_tools();
STARTUP_tools();
}
