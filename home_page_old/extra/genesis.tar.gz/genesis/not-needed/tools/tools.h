/*
** $Id: tools.h,v 2.1.1.1 1999/03/17 07:53:54 mhucka Exp $
** $Log: tools.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:54  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:06:19  dhb
** Initial revision
**
*/

#define MAX_EL_SIZE 5000
#define SMALL_EL_SIZE 500
