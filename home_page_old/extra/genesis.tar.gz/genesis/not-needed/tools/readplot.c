static char rcsid[] = "$Id: readplot.c,v 2.1.1.1 1999/03/17 07:53:54 mhucka Exp $";

/*
** $Log: readplot.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:54  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:06:06  dhb
** Initial revision
**
*/

#include "sim_ext.h"

read_plot2(fname,plotno,timestep,y,maxpts,actualpts,startt,endt)
        char    *fname;
        int     plotno;
        float   *timestep;
        float   *y;
        int     maxpts;
        int     *actualpts;
        float   startt,endt;
{
char    label[100];
int     npts = 0;
int     cellnum;
FILE    *fp;
int      header_size;
int     i;
int     xmax, ymax;
int     datatype;
int     j;
float   dt;
float   start_time;
float   time;
float   val;
double  dval;
int     ival;
float   fval;
float   gain;
int     count;
int     datasize;
short   new_format = 1;
short   dnum;

    gain = 1;
    fp = NULL;

        if((fp = fopen (fname,"r")) == NULL) {
                fprintf(stderr,"\nfile not found : %s\n",fname);
                return(0);
            }

    if(new_format){
        fread(label,sizeof(char),80,fp);
        fread(&start_time,sizeof(float),1,fp);
        fread(&dt,sizeof(float),1,fp);
        fread(&cellnum,sizeof(int),1,fp);
        fread(&datatype,sizeof(int),1,fp);
        header_size = 2*sizeof(int) + 2*sizeof (float) + 80 +
        3*cellnum*sizeof(float);
    } else {
        fread(&xmax,sizeof(int),1,fp);
        fread(&ymax,sizeof(int),1,fp);
        cellnum= (xmax+1)*(ymax+1);
        fread(&dt,sizeof(float),1,fp);
        fread(&datatype,sizeof(int),1,fp);
        header_size = 3*sizeof(int) + sizeof (float);
    }
    if(cellnum <= 0) {
        printf("file is empty\n");
        fclose(fp);
        return(0);
    }
    switch(datatype){
        case INT :
        datasize = sizeof(int);
        break;
        case SHORT :
        datasize = sizeof(short);
        break;
        case FLOAT :
        datasize = sizeof(float);
        break;
        case DOUBLE :
        datasize = sizeof(double);
        break;
    }

    count=0;
    fseek (fp, (long) ((plotno * datasize) + header_size),0); 
    time = start_time;
    while (!feof(fp)){
        switch(datatype){
        case FLOAT :
            dnum = fread (&fval, datasize,1,fp);
            val = fval;
            break;
        case DOUBLE :
            dnum = fread (&dval, datasize,1,fp);
            val = dval;
            break;
        case INT :
            dnum = fread (&ival, datasize,1,fp);
            val = ival;
            break;
        }
        if(dnum <=0) break;
        if (feof(fp)) break;
        if (time > endt) break;
        /*
        ** add the points to the array
        */
        if(time >= startt) {
                y[npts] = val;
                npts++;
                if (npts >= maxpts)
                        break;
        }
        time += dt;
        count++;
        fseek (fp, (long)( (cellnum-1)*datasize), 1);
    }
    fclose(fp);
	*timestep = dt;
    *actualpts = npts;

        return(npts);
}
