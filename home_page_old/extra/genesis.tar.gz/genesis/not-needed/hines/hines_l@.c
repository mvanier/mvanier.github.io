LIBRARY_hines()
{
LibraryHeader("hines","Thu Sep 16 15:46:00 1999 ");DATA_hines();
STARTUP_hines();
}
