/*
 * FILE: compt_update.c
 *
 */

#include "hines_ext.h"

/* A simple function for putting data values back into elements */

int
do_compt_update(Hsolve *hsolve)
{
    struct  compartment_type **compts;
    int     i;
    int     ncompts = hsolve->ncompts;
    int    *elmnum;
    double *results;
    double *v;

    compts  = (struct compartment_type **)(hsolve->compts);
    elmnum  = hsolve->elmnum;
    results = hsolve->results;

    if (BaseObject(hsolve)->method == CRANK_INT)
    {
        for (i = 0; i < ncompts; i++)
        {
            v = &(compts[elmnum[i]]->Vm);
            *v = 2.0 * results[i] - (*v);
        }
    }
    else /* BEULER (backwards Euler) by default */
    {
        for (i = 0; i < ncompts; i++)
            compts[elmnum[i]]->Vm = results[i];
    }

	return 0;
}


