/*
 * FILE: hines_ext.h
 *
 */

#ifndef HINES_EXT_H
#define HINES_EXT_H

#include <stdio.h>
#include "sim_ext.h"
#include "conc_struct.h"
#include "dev_struct.h"

typedef struct nernst_type Nernst;

#include "hines_defs.h"
#include "hines_struct.h"
#include "olf_defs.h"
#include "olf_struct.h"
#include "seg_struct.h"
#include "newconn_struct.h"
#include "synaptic_event.h"

typedef struct channelC3_type Schan;
typedef struct Synchan_type S2chan;
typedef struct Spikegen_type Spike;
typedef struct Ca_concen_type Concen;
typedef struct ghk_type Ghk;
typedef struct Mg_block_type Mblock;

/*
 * #include "delta_defs.h"
 * #include "mesh.h"
 * #include "par_struct.h"
 */

#include "hines_decls.h"


#endif  /* HINES_EXT_H */

