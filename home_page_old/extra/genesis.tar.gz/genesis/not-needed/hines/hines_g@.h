#define DUPLICATE 202
#define HPUT 300
#define HGET 301
#define HRESTORE 302
#define HSAVE 303
#define HCHANGE 304
#define HPROCESS 250
#define HSEVENT 251
