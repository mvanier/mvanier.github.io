/*********************************************************************

** This library uses the netcdf - version 2.4.3 which is
** Copyright 1993-1997 University Corporation for Atmospheric Research/Unidata

** The netcdf library is provided as per the terms of the
** UCAR/Unidata license

** See interface/netcdf-2.4.3/COPYRIGHT for the full notice

********************************************************************/

/* $Id: diskio_ext.h,v 2.1.1.1 1999/03/17 07:53:36 mhucka Exp $ */
/* $Log: diskio_ext.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:36  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1997/07/26 00:12:00  venkat
 * Added
 * */

#include "sim_ext.h"
#include "diskio_struct.h"
#include "diskio_func_ext.h"
#include "diskio_defs.h"
