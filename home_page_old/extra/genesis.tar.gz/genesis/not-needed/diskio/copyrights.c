/*********************************************************************

** This library uses the netcdf - version 2.4.3 which is
** Copyright 1993-1997 University Corporation for Atmospheric Research/Unidata

** The netcdf library is provided as per the terms of the
** UCAR/Unidata license

** See interface/netcdf-2.4.3/COPYRIGHT for the full notice

********************************************************************/

/* $Id: copyrights.c,v 2.1.1.1 1999/03/17 07:53:36 mhucka Exp $ */
/* $Log: copyrights.c,v $
/* Revision 2.1.1.1  1999/03/17 07:53:36  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.1  1997/07/26 00:09:25  venkat
 * Included
 * */

#include <stdio.h>

void copyright_fileformats()
{
 	extern void copyright_netcdf();
		
	copyright_netcdf();
}
