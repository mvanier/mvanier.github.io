LIBRARY_diskio()
{
LibraryHeader("diskio","Wed May  5 19:25:03 1999 ");DATA_diskio();
STARTUP_diskio();
}
