/*********************************************************************

** This library uses the netcdf - version 2.4.3 which is
** Copyright 1993-1997 University Corporation for Atmospheric Research/Unidata

** The netcdf library is provided as per the terms of the
** UCAR/Unidata license

** See interface/netcdf-2.4.3/COPYRIGHT for the full notice

********************************************************************/

/* $Id: diskio_func_ext.h,v 2.1.1.1 1999/03/17 07:53:36 mhucka Exp $ */
/* $Log: diskio_func_ext.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:36  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1997/07/26 00:12:00  venkat
 * Added
 * */

#ifndef DISKIO_FUNC_EXT_H
#define DISKIO_FUNC_EXT_H

 extern char * ParentDiskio_Interface(/* Element* */);
 extern char * ParentVariable_Interface(/* Element * */); 
 extern char * SelfVariable_Interface(/* Element * */);
 extern char * SelfMetadat_Interface(/* Element * */);

 extern char * ffCreateName(/* char *genesis_name, int genesis_index */);
 extern char * ffRecreateName(/* char *nameinfile , int *index_val*/);

 extern long ffParseIndexedField(/*char *field */);
 extern long ffParseWhiteSpacedString(/*char *string, char **eachstring*/);

 extern void ffError(/* char *format, va_list */);
 extern void Expand_And_Copy_String(/* char**, char* */);

#endif
