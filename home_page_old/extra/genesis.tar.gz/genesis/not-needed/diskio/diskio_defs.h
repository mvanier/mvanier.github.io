/*********************************************************************

** This library uses the netcdf - version 2.4.3 which is
** Copyright 1993-1997 University Corporation for Atmospheric Research/Unidata

** The netcdf library is provided as per the terms of the
** UCAR/Unidata license

** See interface/netcdf-2.4.3/COPYRIGHT for the full notice

********************************************************************/

/* $Id: diskio_defs.h,v 2.1.1.1 1999/03/17 07:53:36 mhucka Exp $ */
/* $Log: diskio_defs.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:36  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1997/07/26 00:12:00  venkat
 * Added
 * */

#ifndef DISKIO_DEFS_H
#define DISKIO_DEFS_H

#define UPDATE 10010
#define FLUSH  1001

 typedef struct {

	char *typename;
	int type;

 } Name2Type_Table;

 typedef struct {
	
	char *name;
	int number;

 } FormatName2Number_Table;

#define FF_Number(arr) ((int) (sizeof(arr) / sizeof(arr[0])))

#define HOLD_METADATA 1
/* UGLY_SIGNPOST */
/* This constant hard-sets the limit on the string value an attribute or
   variable can hold */
#define MAX_CHARS_IN_STRING 200

#endif
