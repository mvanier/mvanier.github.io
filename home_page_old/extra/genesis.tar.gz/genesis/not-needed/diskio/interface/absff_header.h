/*********************************************************************

** This library uses the netcdf - version 2.4.3 which is
** Copyright 1993-1997 University Corporation for Atmospheric Research/Unidata

** The netcdf library is provided as per the terms of the
** UCAR/Unidata license

** See netcdf-2.4.3/COPYRIGHT for the full notice

********************************************************************/

/* $Id: absff_header.h,v 2.1.1.1 1999/03/17 07:53:36 mhucka Exp $ */
/* $Log: absff_header.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:36  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1997/07/26 00:15:24  venkat
 * Added-Copyright-notice-and-RCS-headers
 * */
#ifndef HEADER_H
#define HEADER_H

#define DYNAMICSIZECOMPONENT -1
#define STATICSIZECOMPONENT 0


#endif
