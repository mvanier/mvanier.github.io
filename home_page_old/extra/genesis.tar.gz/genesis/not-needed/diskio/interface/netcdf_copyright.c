/*********************************************************************

** This library uses the netcdf - version 2.4.3 which is
** Copyright 1993-1997 University Corporation for Atmospheric Research/Unidata

** The netcdf library is provided as per the terms of the
** UCAR/Unidata license

** See netcdf-2.4.3/COPYRIGHT for the full notice

********************************************************************/
/* $Id: netcdf_copyright.c,v 2.1.1.1 1999/03/17 07:53:36 mhucka Exp $ */
/* $Log: netcdf_copyright.c,v $
/* Revision 2.1.1.1  1999/03/17 07:53:36  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1997/07/29 19:03:03  venkat
 * Modified message to refer to correct location of the netcdf COPYRIGHT file
 *
 * Revision 1.1  1997/07/26 00:15:24  venkat
 * Added-Copyright-notice-and-RCS-headers
 * */

#include <stdio.h>

void copyright_netcdf()
{
 fprintf(stderr, "The diskio library uses the netcdf-version 2.4.3 library\nprovided \"as is\" under the terms of distribution\nand usage by UCAR/Unidata.\nPlease see src/diskio/interface/netcdf-2.4.3/src/COPYRIGHT for full notice.\n\n");  
}
