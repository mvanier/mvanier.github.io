/* $Id: SphereP.h,v 2.1.1.1 1999/03/17 07:53:56 mhucka Exp $ */
/* $Log: SphereP.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:56  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.3  1994/12/06 00:17:22  dhb
 * Nov 8 1994 changes from Upi Bhalla
 *
 * Revision 1.2  1994/01/13  19:35:36  bhalla
 * *** empty log message ***
 *
 * Revision 1.2  1994/01/13  19:35:36  bhalla
 * *** empty log message ***
 * */
#ifndef _SphereP_h
#define _SphereP_h

#include "Sphere.h"
#include "PixP.h" /* include superclass private header file */

/*
** Relevant fields :
** The sphere pix only has a radius field R. The rest are inherited
** from the pix class
*/

typedef struct _SphereClassPart {
	int make_compiler_happy;
} SphereClassPart;

typedef struct _SphereClassRec {
  RectObjClassPart	rect_class;
  PixClassPart		pix_class;
  SphereClassPart		sphere_class;
} SphereClassRec;

extern SphereClassRec sphereClassRec;

typedef struct {
	/* resources */
	float r;
	/* private */
	Dimension screenr;
} SpherePart;

typedef struct _SphereRec {
  ObjectPart		object;
  RectObjPart	rectangle;
  PixPart		pix;
  SpherePart		sphere;
} SphereRec;


#endif /* _SphereP_h */
