/* $Id: DumbDrawP.h,v 2.1.1.1 1999/03/17 07:53:56 mhucka Exp $ */
/* $Log: DumbDrawP.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:56  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.4  1995/03/07 01:07:48  venkat
 * Changed widget and class structure to subclass
 * XoComposite
 *
 * Revision 1.3  1994/12/06  00:17:22  dhb
 * Nov 8 1994 changes from Upi Bhalla
 *
 * Revision 1.2  1994/01/13  19:35:36  bhalla
 * *** empty log message ***
 *
 * Revision 1.2  1994/01/13  19:35:36  bhalla
 * *** empty log message ***
 * */
#ifndef _DumbDrawP_h
#define _DumbDrawP_h

#include "DumbDraw.h"
#include "CoreDrawP.h" /* the superclass private header */

#include <X11/Composite.h>

/* define unique representation types not found in <X11/StringDefs.h> */

#define XtRDumbDrawResource "DumbDrawResource"

typedef struct {
    int empty;
} DumbDrawClassPart;

typedef struct _DumbDrawClassRec {
    CoreClassPart	core_class;
    CompositeClassPart  composite_class;
    XoCompositeClassPart xocomposite_class;
	CoreDrawClassPart	coredraw_class;
    DumbDrawClassPart	dumbdraw_class;
} DumbDrawClassRec;

extern DumbDrawClassRec dumbdrawClassRec;

typedef struct {
	char axis;
	float zmin,zmax;
} DumbDrawPart;

typedef struct _DumbDrawRec {
  CorePart		core;
  CompositePart		composite;
  XoCompositePart	xocomposite;
  CoreDrawPart		coredraw;
  DumbDrawPart		dumbdraw;
} DumbDrawRec;

#endif /* _DumbDrawP_h */
