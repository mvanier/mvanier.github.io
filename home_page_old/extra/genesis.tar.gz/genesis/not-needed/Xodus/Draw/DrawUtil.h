/* $Id: DrawUtil.h,v 2.1.1.1 1999/03/17 07:53:55 mhucka Exp $ */
/*
** $Log: DrawUtil.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:55  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1995/07/17 20:40:09  dhb
** Initial revision
**
*/

#ifndef _DrawUtil_h
#define _DrawUtil_h

extern double XoLength();
extern double XoVLength();
extern void XoVNormalize();
extern void XoUnitCross(
#ifdef ARGS_NEEDED
	float,float,float, /* the x coords */
	float,float,float, /* the y coords */
	float*,float*,float*
#endif
	); /* the returned z coords */

#endif
