/* $Id: xcoredraw_struct.h,v 2.1.1.1 1999/03/17 07:53:56 mhucka Exp $ */
/* $Log: xcoredraw_struct.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:56  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1994/02/02 20:04:53  bhalla
 * Eliminated soft actions.
 * */
#ifndef _xcoredraw_struct_h
#define _xcoredraw_struct_h
#include "../widg/widg_defs.h"

struct xcoredraw_type {
  XWIDG_TYPE
  float	xmin,xmax, ymin,ymax;
  int	drawflags;
  char	*script;
};
#endif
