/* $Id: xdraw_struct.h,v 2.1.1.1 1999/03/17 07:53:56 mhucka Exp $ */
/* $Log: xdraw_struct.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:56  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1994/02/02 20:04:53  bhalla
 * eliminated soft actions
 * */
#ifndef _xdraw_struct_h
#define _xdraw_struct_h
#include "../widg/widg_defs.h"

struct xdraw_type {
  XWIDG_TYPE
  char *transform;
  float	xmin,xmax, ymin,ymax, zmin,zmax;
  float wx,wy,cx,cy,cz;
  float vx,vy,vz;
  float	rv,rz;
  int	drawflags;
  char	*script;
};
#endif
