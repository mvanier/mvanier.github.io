/* $Id: xaxis_struct.h,v 2.1.1.1 1999/03/17 07:53:56 mhucka Exp $ */
/* $Log: xaxis_struct.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:56  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.3  1994/06/13 23:03:06  bhalla
 * added update_parent field
 *
 * Revision 1.2  1994/02/02  20:04:53  bhalla
 * Eliminated softactions
 * */
#ifndef _xaxis_struct_h
#define _xaxis_struct_h
#include "../widg/widg_defs.h"

struct xaxis_type {
  XGADGET_TYPE
  int		linewidth;
  char		*linestyle;
  char		*textcolor;
  char		*textmode;
  char		*textfont;
  char		*units;
  char		*title;
  float		unitoffset;
  float		titleoffset;
  float		ticklength;
  int		tickmode;
  float		labeloffset;
  int		rotatelabels;
  float		axx;
  float		axy;
  float		axz;
  float		axmin;
  float		axmax;
  float		axlength;
  float		tickx;
  float		ticky;
  float		tickz;
  float		labmin;
  float		labmax;
  int		update_parent;
};
#endif
