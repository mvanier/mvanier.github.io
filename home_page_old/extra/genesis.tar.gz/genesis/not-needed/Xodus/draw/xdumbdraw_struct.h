/* $Id: xdumbdraw_struct.h,v 2.1.1.1 1999/03/17 07:53:57 mhucka Exp $ */
/* $Log: xdumbdraw_struct.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:57  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1994/02/02 20:04:53  bhalla
 * eliminated soft actions
 * */
#ifndef _xdumbdraw_struct_h
#define _xdumbdraw_struct_h
#include "../widg/widg_defs.h"

struct xdumbdraw_type {
  XWIDG_TYPE
  char *axis;
  float	xmin,xmax, ymin,ymax, zmin,zmax;
  int drawflags;
  char	*script;
};
#endif
