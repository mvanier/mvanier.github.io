/* $Id: xgif_struct.h,v 2.1.1.1 1999/03/17 07:53:57 mhucka Exp $ */
/* $Log: xgif_struct.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:57  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1994/03/22 15:43:28  bhalla
 * Added format field for future use
 *
 * Revision 1.1  1994/02/02  20:04:53  bhalla
 * Initial revision
 * */
#ifndef _xgif_struct_h
#define _xgif_struct_h
#include "../widg/widg_defs.h"

struct xgif_type {
XGADGET_TYPE
char *filename;
char	*format; /* for future use */
int srcx, srcy, dstx, dsty;
};
#endif



