/* $Id: draw_ext.h,v 2.1.1.1 1999/03/17 07:53:56 mhucka Exp $ */
/* $Log: draw_ext.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:56  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1994/02/02 20:04:53  bhalla
 * *** empty log message ***
 * */
#ifndef _widg_ext_h
#define _widg_ext_h

#include "sim_ext.h"

extern void xoCallbackFn();

#include "xo/xo_defs.h"
#include "../widg/widg_defs.h"
#include "draw_defs.h"
#include "draw_struct.h"

#endif



