/* $Id: xpix_struct.h,v 2.1.1.1 1999/03/17 07:53:57 mhucka Exp $ */
/* $Log: xpix_struct.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:57  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1994/02/02 20:04:53  bhalla
 * *** empty log message ***
 * */
#ifndef _xpix_struct_h
#define _xpix_struct_h
#include "../widg/widg_defs.h"

struct xpix_type {
  XGADGET_TYPE
};
#endif
