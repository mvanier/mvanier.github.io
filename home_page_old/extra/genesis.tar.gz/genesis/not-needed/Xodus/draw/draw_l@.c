LIBRARY_draw()
{
LibraryHeader("draw","Wed May  5 19:25:33 1999 ");DATA_draw();
STARTUP_draw();
}
