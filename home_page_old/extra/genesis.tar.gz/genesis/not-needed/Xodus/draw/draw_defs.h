/* $Id: draw_defs.h,v 2.1.1.1 1999/03/17 07:53:56 mhucka Exp $ */
/* $Log: draw_defs.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:56  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1994/02/02 20:04:53  bhalla
 * *** empty log message ***
 * */


