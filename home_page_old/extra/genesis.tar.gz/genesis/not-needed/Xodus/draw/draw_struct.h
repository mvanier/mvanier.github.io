/* $Id: draw_struct.h,v 2.1.1.1 1999/03/17 07:53:56 mhucka Exp $ */
/* $Log: draw_struct.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:56  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1994/02/02 20:04:53  bhalla
 * Added xgifs and xtree
 * */
#ifndef _draw_struct_h
#define _draw_struct_h
#include "../widg/widg_defs.h"
#include "draw_defs.h"

#include  "xcoredraw_struct.h"
#include  "xdumbdraw_struct.h"
#include  "xgraph_struct.h"
#include  "xdraw_struct.h"
#include  "xpix_struct.h"
#include  "xsphere_struct.h"
#include  "xshape_struct.h"
#include  "xplot_struct.h"
#include  "xaxis_struct.h"
#include  "xgif_struct.h"
#include  "xcell_struct.h"
#include  "xvar_struct.h"
#include  "xview_struct.h"
#include  "xtree_struct.h"
#endif
