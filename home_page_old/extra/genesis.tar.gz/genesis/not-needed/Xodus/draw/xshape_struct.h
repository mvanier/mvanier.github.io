/* $Id: xshape_struct.h,v 2.1.1.1 1999/03/17 07:53:57 mhucka Exp $ */
/* $Log: xshape_struct.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:57  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.5  1996/07/02 18:12:02  venkat
 * Added the allocated_pts field to keep track of the allocated
 * interpol divs.
 *
 * Revision 1.4  1994/04/25  17:58:50  bhalla
 * Added the action definitions for XSHAPE_ADDPT and XSHAPE_MOVEPT
 *
 * Revision 1.3  1994/03/22  15:43:46  bhalla
 * removed transfmode field
 *
 * Revision 1.2  1994/02/02  20:04:53  bhalla
 * Eliminated soft actions
 * */
#ifndef _xshape_struct_h
#define _xshape_struct_h
#include "../widg/widg_defs.h"

#define XSHAPE_ADDPT 217
#define XSHAPE_MOVEPT 218

struct xshape_type {
  XGADGET_TYPE
  struct interpol_struct	*xpts,*ypts,*zpts; /* later to be cast into Interpols */
  int		allocated_pts; /* Keeps track of number of interpol elements 
				 allocated and initialized */
  int		npts;
  char		*pts;
  char		*drawmode;
  int		linewidth;
  char		*linestyle;
  char		*capstyle;
  char		*joinstyle;
  char		*text;
  char		*textcolor;
  char		*textmode;
  char		*textfont;
};
#endif
