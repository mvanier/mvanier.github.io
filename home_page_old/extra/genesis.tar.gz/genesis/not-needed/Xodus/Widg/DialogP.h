/* $Id: DialogP.h,v 2.1.1.1 1999/03/17 07:53:57 mhucka Exp $ */
/* $Log: DialogP.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:57  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.2  1995/03/06 19:33:11  venkat
 * Modified to subclass from XoComposite
 *
 * Revision 1.1  1994/03/22  15:35:54  bhalla
 * Initial revision
 * */
#ifndef _DialogP_h
#define _DialogP_h

#include "Dialog.h"
#include "Widg/FrameP.h"


typedef struct {
    int empty;
} DialogClassPart;

typedef struct _DialogClassRec {
    CoreClassPart	core_class;
    CompositeClassPart  composite_class;
    XoCompositeClassPart	xocomposite_class;
    FrameClassPart	frame_class;
    DialogClassPart	dialog_class;
} DialogClassRec;

extern DialogClassRec dialogClassRec;

typedef struct {
	XtCallbackList	callbacks;
	char	*value;
	char	*label;
	XFontStruct	*font;
  /* private state */
  Widget                form;
  Widget                button;
  Widget                text_framed;
} DialogPart;

typedef struct _DialogRec {
    CorePart		core;
    CompositePart	composite;
    XoCompositePart	xocomposite;
    FramePart           frame;
    DialogPart	        dialog;
} DialogRec;

#endif /* _DialogP_h */
