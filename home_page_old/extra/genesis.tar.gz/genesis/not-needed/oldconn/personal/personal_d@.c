#include "per_ext.h"

#define __BZ memset(&info,0,sizeof(Info))
#define __IFI(F) info.field_indirection = F
#define __IFT info.function_type = 1
#define __IND(N) info.dimensions = N
#define __IDS(S,N) info.dimension_size[S] = N
#undef __BZ
#undef __IFI
#undef __IFT
#undef __IND
#undef __IDS
DATA_personal(){
}
