LIBRARY_personal()
{
LibraryHeader("personal","Wed May  5 19:22:50 1999 ");DATA_personal();
STARTUP_personal();
}
