#include <stdio.h>
#include "per_ext.h"
#include "personal_g@.h"

STARTUP_personal() {
  GenesisObject* object;
  GenesisObject  tobject;
  char*          slotnames[50];
  char*          argv[50];
  { extern void ExpWeight(); AddFunc("expweight", ExpWeight, "void");   HashFunc("ExpWeight", ExpWeight, "void"); }
  { extern void RadialDelay(); AddFunc("radialdelay", RadialDelay, "void");   HashFunc("RadialDelay", RadialDelay, "void"); }
  { extern void AffWeight(); AddFunc("affweight", AffWeight, "void");   HashFunc("AffWeight", AffWeight, "void"); }
  { extern void AffDelay(); AddFunc("affdelay", AffDelay, "void");   HashFunc("AffDelay", AffDelay, "void"); }
  { extern void do_random_field(); AddFunc("setrandfield", do_random_field, "void");   HashFunc("do_random_field", do_random_field, "void"); }
  { extern float ExpSum(); AddFunc("expsum", ExpSum, "float");   HashFunc("ExpSum", ExpSum, "float"); }
  { extern void SpatialDistField(); AddFunc("setspatialfield", SpatialDistField, "void");   HashFunc("SpatialDistField", SpatialDistField, "void"); }
  { extern void do_NormalizeSynapses(); AddFunc("normalize_synapses", do_NormalizeSynapses, "void");   HashFunc("do_NormalizeSynapses", do_NormalizeSynapses, "void"); }
  { extern void ScaleWeight(); AddFunc("scaleweight", ScaleWeight, "void");   HashFunc("ScaleWeight", ScaleWeight, "void"); }

/* Script variables */

} /* STARTUP_personal */
