static char rcsid[] = "$Id: lib.c,v 2.1.1.1 1999/03/17 07:53:41 mhucka Exp $";

/*
** $Log: lib.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:41  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:02:26  dhb
** Initial revision
**
*/

LIBRARY_axon()
{
    LibraryHeader("Axon","2-89","M.Wilson Caltech");
    DATA_axon();
    FUNC_axon();
}
