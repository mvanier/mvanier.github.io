/*
** $Id: axon_struct.h,v 2.1.1.1 1999/03/17 07:53:41 mhucka Exp $
** $Log: axon_struct.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:41  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:02:30  dhb
** Initial revision
**
*/

#include "struct_defs.h"

struct delay_projection_type {
    PROJECTION_TYPE
    float	tmax; 
    float	duration; 
    float	latency; 
};

struct modifiability_type {
    PROJECTION_TYPE
    float	plasticity;
    float	sensitivity;
    short	modify;
};

struct axon_type {
    PROJECTION_TYPE
    float	*Ctable;
    float	G_amp;
    float	gamma;
    PFF		conduct_func;
    PFI		connect_func;
    PFI		plastic_weight_func;
    PFI		base_weight_func;
    PFI		modify_func;
};

