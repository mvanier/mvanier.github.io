static char rcsid[] = "$Id: sigmoid_unit.c,v 2.1.1.1 1999/03/17 07:53:42 mhucka Exp $";

/*
** $Log: sigmoid_unit.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:42  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:02:28  dhb
** Initial revision
**
*/

