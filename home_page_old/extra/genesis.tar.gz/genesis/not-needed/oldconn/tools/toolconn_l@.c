LIBRARY_toolconn()
{
LibraryHeader("toolconn","Wed May  5 19:22:57 1999 ");DATA_toolconn();
STARTUP_toolconn();
}
