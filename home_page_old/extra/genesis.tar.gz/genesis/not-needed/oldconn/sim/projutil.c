static char rcsid[] = "$Id: projutil.c,v 2.1.1.1 1999/03/17 07:53:43 mhucka Exp $";

/*
** $Log: projutil.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:43  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1994/09/23 16:12:46  dhb
** Initial revision
**
 * Revision 1.2  1993/07/21  21:32:47  dhb
 * fixed rcsid variable type
 *
 * Revision 1.1  1992/10/27  20:24:17  dhb
 * Initial revision
 *
*/

#include "simconn_ext.h"

CountProjections(projection)
Projection *projection;
{
int i = 0;

    for(;projection;projection=(Projection *)(projection->next)) i++;
    return(i);
}

CountConnections(connection)
Connection *connection;
{
int i = 0;

    for(;connection;connection=connection->next) i++;
    return(i);
}

DeleteProjection(projection)
Projection 	*projection;
{
Connection	*connection;
Connection	*old;

    /*
    ** free connections
    */
    connection=projection->connection;
    while(connection){
	old = connection;
	connection = connection->next;
	free(old);
    }
    /*
    ** free the projection
    */
    free(projection);
}
