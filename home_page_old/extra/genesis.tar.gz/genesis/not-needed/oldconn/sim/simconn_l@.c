LIBRARY_simconn()
{
LibraryHeader("simconn","Wed May  5 19:22:54 1999 ");DATA_simconn();
STARTUP_simconn();
}
