static char rcsid[] = "$Id: lib.c,v 2.1.1.1 1999/03/17 07:53:43 mhucka Exp $";

/*
** $Log: lib.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:43  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:05:16  dhb
** Initial revision
**
*/

LIBRARY_synapse()
{
    LibraryHeader("Synapse","2-89","M.Wilson Caltech");
    DATA_synapse();
    FUNC_synapse();
}
