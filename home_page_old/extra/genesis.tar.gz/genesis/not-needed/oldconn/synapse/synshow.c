static char rcsid[] = "$Id: synshow.c,v 2.1.1.1 1999/03/17 07:53:43 mhucka Exp $";

/*
** $Log: synshow.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:43  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:05:21  dhb
** Initial revision
**
*/

#include "syn_ext.h"

int SynapseField(connection,action)
Connection	*connection;
Action		*action;
{
char	*field;

    if((field = action->data) == NULL){
	action->passback = NULL;
    }
    if(strcmp(field,"target") == 0){
	action->passback = Pathname(connection->target);
	return(1);
    }
    return(0);
}
