LIBRARY_synapse()
{
LibraryHeader("synapse","Wed May  5 19:22:45 1999 ");DATA_synapse();
STARTUP_synapse();
}
