static char rcsid[] = "$Id: synapseB.c,v 2.1.1.1 1999/03/17 07:53:43 mhucka Exp $";

/*
** $Log: synapseB.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:43  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:05:20  dhb
** Initial revision
**
*/

#include "syn_ext.h"

/* M.Wilson Caltech 8/88 */
SynapseB(connection,action,projection,event,offset_time)
register struct synapseB_type	*connection;
Action		*action;
Projection	*projection;
register Event	*event;
float		offset_time;
{
float	old_state;

    /*
    ** update the facilitation weighting
    */
    old_state = connection->state*
	exp(connection->rate*(connection->time - simulation_time));

    connection->target->activation +=
    event->magnitude *(old_state + connection->weight);
    /*
    ** set the new state
    */
    connection->state = old_state + 
	connection->scale*(connection->maxweight -  old_state);
    connection->time = simulation_time;
}

/* M.Wilson Caltech 2/89 */
RESET_SynapseB(connection,action,projection)
register struct synapseB_type	*connection;
Action		*action;
Projection	*projection;
{
    connection->time = 0;
    connection->state =  0;
}
