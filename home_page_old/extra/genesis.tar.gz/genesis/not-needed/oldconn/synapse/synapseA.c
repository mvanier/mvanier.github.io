static char rcsid[] = "$Id: synapseA.c,v 2.1.1.1 1999/03/17 07:53:43 mhucka Exp $";

/*
** $Log: synapseA.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:43  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:05:19  dhb
** Initial revision
**
*/

#include "syn_ext.h"

/* M.Wilson Caltech 8/88 */
SynapseA(connection,action,projection,event,offset_time)
register struct synapseA_type	*connection;
Action		*action;
Projection	*projection;
Event		*event;
float		offset_time;
{
    connection->target->activation += event->magnitude*connection->weight;
    connection->time = simulation_time;
    connection->state = event->magnitude;
}

