#define PF(F,T) HashFunc("F",F,"T")
FUNC_kin(){
extern int ReacFunc();
extern int PoolFunc();
extern int EnzFunc();
extern int ConcchanFunc();
HashFunc("ReacFunc",ReacFunc,"int");
HashFunc("PoolFunc",PoolFunc,"int");
HashFunc("EnzFunc",EnzFunc,"int");
HashFunc("ConcchanFunc",ConcchanFunc,"int");
}
#undef PF
