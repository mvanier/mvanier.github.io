/**********************************************************************
** This program is part of the kinetics library and is
**           copyright (C) 1995 Upinder S. Bhalla.
** It is made available under the terms of the
**           GNU Library General Public License. 
** See the file COPYRIGHT for the full notice.
**********************************************************************/
static char rcsid[] = "$Id: table2d.c,v 2.1.1.1 1999/03/17 07:53:41 mhucka Exp $";
 
/* $Log: table2d.c,v $
/* Revision 2.1.1.1  1999/03/17 07:53:41  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.1  1997/07/24 17:49:40  dhb
 * Initial revision
 *
 * Revision 1.1  1994/06/13  22:55:39  bhalla
 * Initial revision
 * */

#include "kin_ext.h"

/*
** Does a table2d lookup with interpolation. Also permits one to modify
** the table2d with sum and product messages, so as to extend the
** dimensionality of the table2d. Most unlikely to ever use that.
*/

Table2DFunc(table2d,action)
register struct table2d_type *table2d;
Action		*action;
{
MsgIn	*msg;
double	sy,py;
int		xdivs,ydivs;
float	xmin,xmax,ymin,ymax;
Interpol2D *create_interpol2d();
short	fill_mode;

    if(debug > 1){
	ActionHeader("VDepGate",table2d,action);
    }

    SELECT_ACTION(action){
    case PROCESS:
        		/*
        		** check all of the messages to the table2d
        		*/
				sy = 0;
				py = 1;
        		MSGLOOP(table2d,msg) {
            		case 0:				/* index */
	        			table2d->input = MSGVALUE(msg,0);
   		     			table2d->input2 = MSGVALUE(msg,1);
        			break;
					case 1:				/* summed y */
						sy += MSGVALUE(msg,0);
					break;
					case 2:				/* product y */
						py *= MSGVALUE(msg,0);
					break;
					case 3:				/* x input alone */
        				table2d->input = MSGVALUE(msg,0);
					break;
					case 4:				/* y input alone */
        				table2d->input2 = MSGVALUE(msg,0);
					break;
        		}
				if (table2d->alloced) {
        			table2d->output =
						Tab2DInterp(table2d->table,
							table2d->input,table2d->input2) * py + sy;
				} else {
					table2d->output = py + sy;
				}
				table2d->negoutput = -table2d->output;
		break;
    case RESET:
        table2d->output = 0;
        break;
    case SET :
        if (action->argc != 2)
            return(0); /* do the normal set */
        if (strncmp(action->argv[0],"table",5) == 0)
            scale_table2d(table2d->table,action->argv[0] + 7,
				action->argv[1]);
        return(0); /* do the normal set */
		break;


    case TABCREATE:
		if (action->argc < 3) {
			printf("usage: TABCREATE xdivs xmin xmax [ydivs ymin ymax]\n");
			return(0);
		}
		ydivs = xdivs = atoi(action->argv[0]);
		ymin = xmin = Atof(action->argv[1]);
		ymax = xmax = Atof(action->argv[2]);
		if (action->argc == 6) {
			ydivs = atoi(action->argv[3]);
			ymin = Atof(action->argv[4]);
			ymax = Atof(action->argv[5]);
		}
		table2d->table = create_interpol2d(xdivs,xmin,xmax,
			ydivs,ymin,ymax);
		table2d->alloced = 1;
        break;
	}
}
