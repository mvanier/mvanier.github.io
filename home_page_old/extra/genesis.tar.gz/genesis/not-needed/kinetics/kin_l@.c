LIBRARY_kin()
{
LibraryHeader("kin","Wed May  5 19:25:06 1999 ");DATA_kin();
FUNC_kin();
STARTUP_kin();
}
