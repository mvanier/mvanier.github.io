/**********************************************************************
** This program is part of the kinetics library and is
**           copyright (C) 1995 Upinder S. Bhalla.
** It is made available under the terms of the
**           GNU Library General Public License. 
** See the file COPYRIGHT for the full notice.
**********************************************************************/
/* $Id: kin_ext.h,v 2.1.1.1 1999/03/17 07:53:40 mhucka Exp $ */
 
/* $Log: kin_ext.h,v $
/* Revision 2.1.1.1  1999/03/17 07:53:40  mhucka
/* Import of GENESIS 2.1 release from CD-ROM
/*
 * Revision 1.1  1997/07/24 17:49:40  dhb
 * Initial revision
 *
 * Revision 1.1  1994/06/13  22:55:39  bhalla
 * Initial revision
 * */

#include "sim_ext.h"
#include "kin_struct.h"

extern double Tab2DInterp();
extern struct interpol2d_struct *create_interpol2d();
