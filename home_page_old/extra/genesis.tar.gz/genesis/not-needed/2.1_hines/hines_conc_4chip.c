static char rcsid[] = "$Id: hines_conc_4chip.c,v 2.1.1.1 1999/03/17 07:53:40 mhucka Exp $";

/* Version EDS21a 96/04/04, Erik De Schutter, Caltech & BBF-UIA 8/92-4/96 */

/*
** $Log: hines_conc_4chip.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:40  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1997/05/28 23:11:50  dhb
** Initial revision
**
*/

#define CHANMODE4
#include "hines_conc_chip.c"
#undef CHANMODE4

