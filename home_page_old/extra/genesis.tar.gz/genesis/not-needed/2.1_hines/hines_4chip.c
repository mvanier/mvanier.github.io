static char rcsid[] = "$Id: hines_4chip.c,v 2.1.1.1 1999/03/17 07:53:40 mhucka Exp $";

/* Version EDS21e 97/03/29, Erik De Schutter, Caltech & BBF-UIA 4/92-3/97 */

/*
** $Log: hines_4chip.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:40  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1997/05/28 23:11:50  dhb
** Initial revision
**
*/

/* Defines variables to create do_chip_hh4_update(hsolve) function in
**  hines_chip.c
*/

#include "hines_ext.h"
#define CHANMODE4
#define SOLVEINTERPOL /* interpolation for tabchannels */
#include "hines_chip.c"
#undef CHANMODE4
#undef SOLVEINTERPOL
