static char rcsid[] = "$Id: hines_4nichip.c,v 2.1.1.1 1999/03/17 07:53:40 mhucka Exp $";

/* Version EDS21d 97/03/21, Erik De Schutter, Caltech & BBF-UIA 4/92-3/97 */

/*
** $Log: hines_4nichip.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:40  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1997/05/28 23:11:50  dhb
** Initial revision
**
*/

/* Defines variables to create do_chip_hh4ni_update(hsolve) function in
**  hines_chip.c
*/

#include "hines_ext.h"
#define CHANMODE4
#include "hines_chip.c"
#undef CHANMODE4
