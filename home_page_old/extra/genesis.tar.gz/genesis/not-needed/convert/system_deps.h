/*
** $Id: system_deps.h,v 2.1.1.1 1999/03/17 07:53:35 mhucka Exp $
** $Log: system_deps.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:35  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1995/01/13 01:09:48  dhb
** Initial revision
**
 **
 ** This file is from GENESIS 1.4.1
 **
** Revision 1.1  1992/12/11  19:05:12  dhb
** Initial revision
**
*/

/*
** Global include file for system dependent functions
** (c) Michael D. Speight 1991
*/

/* mds3 changes */
#ifdef i860
/* some useful constants */
#define M_E   2.7182818284590452354
#define M_PI  3.14159265358979323846
#endif
#ifdef SYSV
/* Define 'bcopy()' and 'bzero()' */
#define bcmp(s1, s2, length)  memcmp(s1, s2, length)
#define bcopy(s1, s2, length) (int)memcpy(s2, s1, length)
#define bzero(s1, length) (int)memset(s1, 0, length)
#endif
