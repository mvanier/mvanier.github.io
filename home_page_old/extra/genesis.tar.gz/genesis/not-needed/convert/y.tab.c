
/*  A Bison parser, made from script.y
 by  GNU Bison version 1.25
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	LT	258
#define	LE	259
#define	GT	260
#define	GE	261
#define	EQ	262
#define	NE	263
#define	OR	264
#define	AND	265
#define	UMINUS	266
#define	WHILE	267
#define	IF	268
#define	ELSE	269
#define	FOR	270
#define	FOREACH	271
#define	END	272
#define	INCLUDE	273
#define	ENDSCRIPT	274
#define	BREAK	275
#define	INT	276
#define	FLOAT	277
#define	STR	278
#define	RETURN	279
#define	WHITESPACE	280
#define	FUNCTION	281
#define	INTCONST	282
#define	DOLLARARG	283
#define	FLOATCONST	284
#define	STRCONST	285
#define	LITERAL	286
#define	IDENT	287
#define	VARREF	288
#define	FUNCREF	289
#define	EXTERN	290
#define	SL	291
#define	COMMAND	292
#define	ARGUMENT	293
#define	ARGLIST	294
#define	LOCREF	295
#define	ICAST	296
#define	FCAST	297
#define	SCAST	298

#line 1 "script.y"

static char parsercsid[] = "$Id: script.y,v 2.1.1.1 1999/03/17 07:53:35 mhucka Exp $";

/*
** $Log: script.y,v $
** Revision 2.1.1.1  1999/03/17 07:53:35  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.7  1997/06/12 22:50:55  dhb
** Added include of string.h for strlen() declaration needed by
** included lexer code.
**
** Revision 1.6  1996/07/15 23:19:00  venkat
** Added preprocessor macros to deal with the order of the include lex.yy.c
** statement and the definitions of the macros used in it, for the DEC/alpha
**
 * Revision 1.5  1995/06/16  05:57:12  dhb
 * FreeBSD compatibility.
 *
 * Revision 1.4  1995/04/29  01:18:16  dhb
 * Moved include of lex.yy.c back to original location.  Previous
 * problem is fixed by extern void exit() in script.l.
 *
 * Fixed bug in call to SymtabLook() call where a Symtab rather than
 * a Symtab* was passed.
 *
 * Revision 1.3  1995/04/15  02:26:28  dhb
 * Moved include of lex.yy.c after the parse rules to work around SGI
 * yacc misplacement of include statements.
 *
 * Revision 1.2  1995/04/14  01:03:20  dhb
 * Null change to force patch and reprocessing by yacc.
 *
 * Revision 1.1  1995/01/13  01:09:48  dhb
 * Initial revision
 *
 * Revision 1.1  1992/12/11  21:19:07  dhb
 **
 ** This file is from GENESIS 1.4.1
 **
 * Initial revision
 *
*/

#define YYDEBUG	1

#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include "parse.h"
#include "symtab.h"


/*
** Parser routines which return something other than int.
*/

extern vardef();
extern char *TokenStr();

extern char* Combine();
extern char* ArgListToStr();
extern char** AllocateArgList();

/*
** Parser global variables
*/

extern jmp_buf	BreakBuf;	/* Used to break out of a loop */
extern jmp_buf	ReturnBuf;	/* Used to return out of a script */

static int	DefType;	/* Remembers type in a var decl */
static int	DefCast;	/* Remembers cast in a var decl */
static int	BreakAllowed = 0; /* In a loop control structure */
static int	ReturnIdents = 0; /* 1 ==> lexer doesn't classify IDENTs */
static int	Compiling = 0;	/* Make a statement list rather than execute */
static int	InFunctionDefinition = 0;
static int	NextLocal;	/* Next local symbol offset */
static int	ArgMatch;	/* Matches argument number to name in func */
Symtab		GlobalSymbols;	/* Symbols defined outside a function */
static Symtab	*LocalSymbols = NULL;	/* Symbols local to a function */
static ResultValue RV;			/* Dummy ReturnValue for PTNew */

#line 115 "script.y"


#if !defined(decalpha) || defined(bison)
/*
** Start of lexical analyzer.  LEX source is in "script.l".
*/

extern YYSTYPE	yylval;

#ifdef __FreeBSD__
#include "y.tab.h"
#endif

#include "lex.yy.c"

#endif
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		224
#define	YYFLAG		-32768
#define	YYNTBASE	62

#define YYTRANSLATE(x) ((unsigned)(x) <= 298 ? yytranslate[x] : 123)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    54,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     9,     2,     2,     2,    19,    14,     2,    56,
    57,    17,    12,    59,    13,     2,    18,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,    55,     2,
    58,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,    16,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    60,    15,    61,    20,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,    10,    11,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     3,     7,     9,    11,    13,    15,    17,    19,
    21,    23,    25,    27,    29,    31,    33,    35,    37,    39,
    41,    43,    44,    52,    53,    65,    66,    67,    79,    80,
    89,    90,    91,    95,    99,   100,   105,   110,   113,   114,
   116,   117,   121,   122,   127,   134,   136,   143,   144,   149,
   150,   154,   156,   160,   161,   163,   165,   168,   170,   176,
   177,   179,   181,   184,   186,   188,   190,   191,   192,   198,
   201,   204,   207,   210,   211,   212,   219,   220,   221,   226,
   228,   232,   234,   236,   238,   241,   243,   244,   249,   250,
   254,   255,   258,   260,   263,   265,   266,   270,   274,   278,
   281,   285,   289,   293,   297,   301,   304,   308,   312,   315,
   319,   323,   327,   331,   335,   339,   340,   341,   350,   351,
   352,   361,   363,   365,   367,   369,   371,   373,   375,   379
};

static const short yyrhs[] = {    63,
     0,     0,    63,    65,    64,     0,    54,     0,    55,     0,
    67,     0,    69,     0,    71,     0,    74,     0,    78,     0,
    81,     0,    66,     0,    85,     0,    88,     0,   102,     0,
   100,     0,   109,     0,   115,     0,   116,     0,   117,     0,
    29,     0,     0,    22,    56,   118,    57,    68,    63,    27,
     0,     0,    25,    56,    78,    55,   118,    55,    78,    57,
    70,    63,    27,     0,     0,     0,    26,    43,    56,    72,
    95,    91,    95,    73,    57,    63,    27,     0,     0,    23,
    56,   118,    57,    75,    63,    76,    27,     0,     0,     0,
    24,    77,    63,     0,    43,    58,   118,     0,     0,    28,
    80,    95,    41,     0,    79,    35,    91,    95,     0,    79,
    95,     0,     0,    41,     0,     0,    42,    84,    82,     0,
     0,    83,    86,    90,    95,     0,    83,    56,    92,    94,
    92,    57,     0,    44,     0,    87,    56,    92,    94,    92,
    57,     0,     0,    87,    89,    90,    95,     0,     0,    90,
    93,    96,     0,    96,     0,    91,    93,    96,     0,     0,
    93,     0,    35,     0,    93,    35,     0,    96,     0,    94,
    92,    59,    92,    96,     0,     0,    35,     0,    97,     0,
    96,    97,     0,    41,     0,    40,     0,    38,     0,     0,
     0,    60,    98,   118,    99,    61,     0,    45,    42,     0,
    45,    44,     0,    36,    42,     0,    36,    44,     0,     0,
     0,   101,   103,   105,   104,    63,    27,     0,     0,     0,
    56,   106,   107,    57,     0,    42,     0,   107,    59,    42,
     0,    31,     0,    32,     0,    33,     0,   108,   110,     0,
   112,     0,     0,   110,    59,   111,   112,     0,     0,    42,
   113,   114,     0,     0,    58,   118,     0,    30,     0,    34,
   118,     0,    34,     0,     0,   118,    15,   118,     0,   118,
    14,   118,     0,   118,    16,   118,     0,    20,   118,     0,
   118,    12,   118,     0,   118,    13,   118,     0,   118,    17,
   118,     0,   118,    18,   118,     0,   118,    19,   118,     0,
    13,   118,     0,   118,    10,   118,     0,   118,    11,   118,
     0,     9,   118,     0,   118,     3,   118,     0,   118,     4,
   118,     0,   118,     5,   118,     0,   118,     6,   118,     0,
   118,     7,   118,     0,   118,     8,   118,     0,     0,     0,
    42,    56,   119,    92,    94,    92,   120,    57,     0,     0,
     0,    44,    56,   121,    92,    94,    92,   122,    57,     0,
    43,     0,    44,     0,    42,     0,    39,     0,    37,     0,
    40,     0,    38,     0,    60,   118,    61,     0,    56,   118,
    57,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   135,   138,   142,   149,   153,   159,   160,   161,   162,   163,
   168,   169,   170,   175,   180,   181,   182,   183,   184,   185,
   188,   194,   199,   206,   212,   219,   225,   231,   238,   243,
   250,   254,   257,   260,   266,   270,   277,   282,   288,   292,
   298,   303,   313,   317,   346,   377,   384,   395,   399,   412,
   420,   431,   440,   451,   452,   455,   456,   459,   468,   479,
   480,   483,   487,   493,   497,   501,   505,   510,   514,   529,
   544,   551,   577,   601,   608,   611,   622,   624,   629,   635,
   640,   647,   654,   661,   670,   678,   679,   684,   689,   694,
   703,   707,   713,   720,   725,   732,   736,   738,   740,   742,
   745,   758,   760,   762,   764,   766,   769,   771,   773,   776,
   778,   780,   782,   784,   786,   789,   793,   798,   835,   839,
   844,   849,   861,   867,   899,   904,   909,   915,   921,   928
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","LT","LE",
"GT","GE","EQ","NE","'!'","OR","AND","'+'","'-'","'&'","'|'","'^'","'*'","'/'",
"'%'","'~'","UMINUS","WHILE","IF","ELSE","FOR","FOREACH","END","INCLUDE","ENDSCRIPT",
"BREAK","INT","FLOAT","STR","RETURN","WHITESPACE","FUNCTION","INTCONST","DOLLARARG",
"FLOATCONST","STRCONST","LITERAL","IDENT","VARREF","FUNCREF","EXTERN","SL","COMMAND",
"ARGUMENT","ARGLIST","LOCREF","ICAST","FCAST","SCAST","'\\n'","';'","'('","')'",
"'='","','","'{'","'}'","script","statement_list","stmnt_terminator","statement",
"endscript_marker","while_stmnt","@1","for_stmnt","@2","foreach_stmnt","@3",
"@4","if_stmnt","@5","else_clause","@6","assign_stmnt","include_hdr","@7","include_stmnt",
"opt_node","cmd_name","@8","cmd_stmnt","@9","funcref","func_call","@10","opt_arg_list",
"arg_list","optwslist","wslist","func_call_list","ws","arg_component_list","arg_component",
"@11","@12","ext_func","func_hdr","func_def","@13","@14","func_args","@15","func_arg_list",
"decl_type","decl_stmnt","decl_list","@16","decl_ident","@17","init","break_stmnt",
"return_stmnt","null_stmnt","expr","@18","@19","@20","@21", NULL
};
#endif

static const short yyr1[] = {     0,
    62,    63,    63,    64,    64,    65,    65,    65,    65,    65,
    65,    65,    65,    65,    65,    65,    65,    65,    65,    65,
    66,    68,    67,    70,    69,    72,    73,    71,    75,    74,
    76,    77,    76,    78,    80,    79,    81,    81,    82,    82,
    84,    83,    86,    85,    85,    87,    88,    89,    88,    90,
    90,    91,    91,    92,    92,    93,    93,    94,    94,    95,
    95,    96,    96,    97,    97,    97,    98,    99,    97,   100,
   100,   101,   101,   103,   104,   102,   105,   106,   105,   107,
   107,   108,   108,   108,   109,   110,   111,   110,   113,   112,
   114,   114,   115,   116,   116,   117,   118,   118,   118,   118,
   118,   118,   118,   118,   118,   118,   118,   118,   118,   118,
   118,   118,   118,   118,   118,   119,   120,   118,   121,   122,
   118,   118,   118,   118,   118,   118,   118,   118,   118,   118
};

static const short yyr2[] = {     0,
     1,     0,     3,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     0,     7,     0,    11,     0,     0,    11,     0,     8,
     0,     0,     3,     3,     0,     4,     4,     2,     0,     1,
     0,     3,     0,     4,     6,     1,     6,     0,     4,     0,
     3,     1,     3,     0,     1,     1,     2,     1,     5,     0,
     1,     1,     2,     1,     1,     1,     0,     0,     5,     2,
     2,     2,     2,     0,     0,     6,     0,     0,     4,     1,
     3,     1,     1,     1,     2,     1,     0,     4,     0,     3,
     0,     2,     1,     2,     1,     0,     3,     3,     3,     2,
     3,     3,     3,     3,     3,     2,     3,     3,     2,     3,
     3,     3,     3,     3,     3,     0,     0,     8,     0,     0,
     8,     1,     1,     1,     1,     1,     1,     1,     3,     3
};

static const short yydefact[] = {     2,
    96,     0,     0,     0,     0,    35,    21,    93,    82,    83,
    84,    95,     0,    41,     0,    46,     0,     0,    12,     6,
     7,     8,     9,    10,    60,    11,    43,    13,    48,    14,
    16,    74,    15,     0,    17,    18,    19,    20,     0,     0,
     0,     0,    60,     0,     0,     0,   126,   128,   125,   127,
   124,   122,   123,     0,     0,    94,    72,    73,    39,     0,
    70,    71,     4,     5,     3,    61,    38,    54,    50,    54,
    50,    77,    89,    85,    86,     0,     0,     0,    26,    61,
     0,   109,   106,   100,   116,   119,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,    40,    42,    34,    66,    65,    64,
    67,    60,    52,    62,    56,     0,    55,    60,     0,    60,
    78,    75,    91,    87,    22,    29,     0,    60,    36,    54,
    54,   130,   129,   110,   111,   112,   113,   114,   115,   107,
   108,   101,   102,    98,    97,    99,   103,   104,   105,     0,
    56,     0,    37,    63,    54,    58,    57,     0,    44,    54,
    49,     0,     2,     0,    90,     0,     2,     2,     0,     0,
     0,     0,    68,    53,     0,    51,     0,    80,     0,    96,
    92,    88,    96,    96,     0,    60,    54,    54,     0,    45,
    54,    47,    79,     0,    76,    23,    32,     0,     0,    27,
   117,   120,    69,     0,    81,     2,    30,    24,     0,     0,
     0,    59,    96,     2,     2,   118,   121,    96,    96,    25,
    28,     0,     0,     0
};

static const short yydefgoto[] = {   222,
     1,    65,    18,    19,    20,   167,    21,   214,    22,   128,
   209,    23,   168,   198,   206,    24,    25,    43,    26,   106,
    27,    59,    28,    69,    29,    30,    71,   118,   112,   116,
   117,   155,    67,   156,   114,   150,   189,    31,    32,    33,
    72,   163,   122,   162,   179,    34,    35,    74,   166,    75,
   123,   165,    36,    37,    38,    56,   130,   210,   131,   211
};

static const short yypact[] = {-32768,
   248,   -54,   -44,   -38,   -22,-32768,-32768,-32768,-32768,-32768,
-32768,   207,   -27,-32768,   -36,-32768,    35,   -48,-32768,-32768,
-32768,-32768,-32768,-32768,    -9,-32768,   -25,-32768,   -18,-32768,
-32768,-32768,-32768,    10,-32768,-32768,-32768,-32768,   207,   207,
    27,    39,    64,   207,   207,   207,-32768,-32768,-32768,-32768,
    44,-32768,    52,   207,   207,   435,-32768,-32768,    87,   207,
-32768,-32768,-32768,-32768,-32768,    66,-32768,    97,-32768,    97,
-32768,    80,-32768,    78,-32768,   106,   154,    83,-32768,-32768,
   100,   219,-32768,-32768,-32768,-32768,   171,    29,   207,   207,
   207,   207,   207,   207,   207,   207,   207,   207,   207,   207,
   207,   207,   207,   207,-32768,-32768,   435,-32768,-32768,-32768,
-32768,   107,    66,-32768,-32768,    66,   108,   107,    66,   107,
-32768,-32768,    89,-32768,-32768,-32768,   207,    64,-32768,    97,
    97,-32768,-32768,   452,   452,   452,   452,   452,   452,   240,
   240,    67,    67,    67,    67,    67,-32768,-32768,-32768,   207,
    -4,   -11,-32768,-32768,    97,    66,-32768,   -11,-32768,    97,
-32768,   103,-32768,   207,-32768,    10,-32768,-32768,   188,    66,
    66,    66,   435,    66,    24,    66,    37,-32768,    76,   296,
   435,-32768,   320,   272,    27,   107,    97,    97,    90,-32768,
    97,-32768,-32768,   110,-32768,-32768,-32768,   123,    96,-32768,
    95,    95,-32768,    66,-32768,-32768,-32768,-32768,    98,    99,
   140,    66,   344,-32768,-32768,-32768,-32768,   368,   392,-32768,
-32768,   180,   208,-32768
};

static const short yypgoto[] = {-32768,
   -66,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,   -41,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,   138,    40,   -57,
  -104,   -96,   -40,   -65,   -85,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    46,
-32768,-32768,-32768,-32768,-32768,   -35,-32768,-32768,-32768,-32768
};


#define	YYLAST		471


static const short yytable[] = {    78,
   113,    39,    81,    76,    77,    63,    64,   152,    82,    83,
    84,    40,   119,   158,    57,   158,    58,    41,    87,    88,
    42,    60,   160,   157,   107,    66,   108,   154,   109,   110,
    68,    89,    90,    91,    92,    93,    94,    70,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   111,   -61,
   -61,    73,   -61,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,    15,
   154,   153,   171,   172,   187,   188,    61,   159,    62,   161,
   190,   152,   191,   102,   103,   104,   174,   170,   154,   133,
   154,   169,   176,   192,    79,   191,   180,   175,    80,    85,
   183,   184,   177,   108,   113,   109,   110,    86,    89,    90,
    91,    92,    93,    94,   173,    95,    96,    97,    98,    99,
   100,   101,   102,   103,   104,   111,   154,   105,   181,   201,
   202,   115,   193,   204,   194,   121,   124,   127,   212,   213,
   129,   151,   157,   199,   178,   200,   164,   218,   219,   207,
   203,   205,   208,   191,   215,   216,    89,    90,    91,    92,
    93,    94,   125,    95,    96,    97,    98,    99,   100,   101,
   102,   103,   104,    89,    90,    91,    92,    93,    94,   223,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
    89,    90,    91,    92,    93,    94,   217,    95,    96,    97,
    98,    99,   100,   101,   102,   103,   104,   224,   120,   186,
   126,   182,     0,     0,     0,    44,     0,     0,     0,    45,
     0,     0,     0,     0,     0,     0,    46,   132,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,     0,     0,
     0,     0,   185,    47,    48,    49,    50,    -1,    51,    52,
    53,    97,    98,    99,   100,   101,   102,   103,   104,     0,
     0,     0,    54,     0,     0,     0,    55,     0,     0,     2,
     3,     0,     4,     5,     0,     6,     7,     8,     9,    10,
    11,    12,     0,    13,     0,     0,     0,     0,     0,    14,
    15,    16,    17,     2,     3,   197,     4,     5,   -31,     6,
     7,     8,     9,    10,    11,    12,     0,    13,     0,     0,
     0,     0,     0,    14,    15,    16,    17,     2,     3,     0,
     4,     5,   195,     6,     7,     8,     9,    10,    11,    12,
     0,    13,     0,     0,     0,     0,     0,    14,    15,    16,
    17,     2,     3,     0,     4,     5,   196,     6,     7,     8,
     9,    10,    11,    12,     0,    13,     0,     0,     0,     0,
     0,    14,    15,    16,    17,     2,     3,     0,     4,     5,
   -33,     6,     7,     8,     9,    10,    11,    12,     0,    13,
     0,     0,     0,     0,     0,    14,    15,    16,    17,     2,
     3,     0,     4,     5,   220,     6,     7,     8,     9,    10,
    11,    12,     0,    13,     0,     0,     0,     0,     0,    14,
    15,    16,    17,     2,     3,     0,     4,     5,   221,     6,
     7,     8,     9,    10,    11,    12,     0,    13,     0,     0,
     0,     0,     0,    14,    15,    16,    17,    89,    90,    91,
    92,    93,    94,     0,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,-32768,-32768,-32768,-32768,-32768,-32768,
     0,    95,    96,    97,    98,    99,   100,   101,   102,   103,
   104
};

static const short yycheck[] = {    41,
    66,    56,    43,    39,    40,    54,    55,   112,    44,    45,
    46,    56,    70,   118,    42,   120,    44,    56,    54,    55,
    43,    58,   119,    35,    60,    35,    38,   113,    40,    41,
    56,     3,     4,     5,     6,     7,     8,    56,    10,    11,
    12,    13,    14,    15,    16,    17,    18,    19,    60,    54,
    55,    42,    57,    89,    90,    91,    92,    93,    94,    95,
    96,    97,    98,    99,   100,   101,   102,   103,   104,    43,
   156,   112,   130,   131,   171,   172,    42,   118,    44,   120,
    57,   186,    59,    17,    18,    19,   152,   128,   174,    61,
   176,   127,   158,    57,    56,    59,   163,   155,    35,    56,
   167,   168,   160,    38,   170,    40,    41,    56,     3,     4,
     5,     6,     7,     8,   150,    10,    11,    12,    13,    14,
    15,    16,    17,    18,    19,    60,   212,    41,   164,   187,
   188,    35,    57,   191,    59,    56,    59,    55,   204,   206,
    41,    35,    35,   185,    42,   186,    58,   214,   215,    27,
    61,    42,    57,    59,    57,    57,     3,     4,     5,     6,
     7,     8,    57,    10,    11,    12,    13,    14,    15,    16,
    17,    18,    19,     3,     4,     5,     6,     7,     8,     0,
    10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
     3,     4,     5,     6,     7,     8,    57,    10,    11,    12,
    13,    14,    15,    16,    17,    18,    19,     0,    71,   170,
    57,   166,    -1,    -1,    -1,     9,    -1,    -1,    -1,    13,
    -1,    -1,    -1,    -1,    -1,    -1,    20,    57,    10,    11,
    12,    13,    14,    15,    16,    17,    18,    19,    -1,    -1,
    -1,    -1,    55,    37,    38,    39,    40,     0,    42,    43,
    44,    12,    13,    14,    15,    16,    17,    18,    19,    -1,
    -1,    -1,    56,    -1,    -1,    -1,    60,    -1,    -1,    22,
    23,    -1,    25,    26,    -1,    28,    29,    30,    31,    32,
    33,    34,    -1,    36,    -1,    -1,    -1,    -1,    -1,    42,
    43,    44,    45,    22,    23,    24,    25,    26,    27,    28,
    29,    30,    31,    32,    33,    34,    -1,    36,    -1,    -1,
    -1,    -1,    -1,    42,    43,    44,    45,    22,    23,    -1,
    25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
    -1,    36,    -1,    -1,    -1,    -1,    -1,    42,    43,    44,
    45,    22,    23,    -1,    25,    26,    27,    28,    29,    30,
    31,    32,    33,    34,    -1,    36,    -1,    -1,    -1,    -1,
    -1,    42,    43,    44,    45,    22,    23,    -1,    25,    26,
    27,    28,    29,    30,    31,    32,    33,    34,    -1,    36,
    -1,    -1,    -1,    -1,    -1,    42,    43,    44,    45,    22,
    23,    -1,    25,    26,    27,    28,    29,    30,    31,    32,
    33,    34,    -1,    36,    -1,    -1,    -1,    -1,    -1,    42,
    43,    44,    45,    22,    23,    -1,    25,    26,    27,    28,
    29,    30,    31,    32,    33,    34,    -1,    36,    -1,    -1,
    -1,    -1,    -1,    42,    43,    44,    45,     3,     4,     5,
     6,     7,     8,    -1,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,     3,     4,     5,     6,     7,     8,
    -1,    10,    11,    12,    13,    14,    15,    16,    17,    18,
    19
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 196 "/usr/lib/bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 2:
#line 139 "script.y"
{ 
		    yyval.str = NULL;
 		  ;
    break;}
case 3:
#line 144 "script.y"
{
		    Output(yyvsp[0].str, NULL);
		  ;
    break;}
case 4:
#line 150 "script.y"
{
		    yyval.str = "\n";
		  ;
    break;}
case 5:
#line 154 "script.y"
{
		    yyval.str = "; ";
		  ;
    break;}
case 10:
#line 164 "script.y"
{
		    OutputIndentation();
		    Output(yyvsp[0].str, NULL);
		  ;
    break;}
case 13:
#line 171 "script.y"
{
		    OutputIndentation();
		    OutputArgList(yyvsp[0].str);
		  ;
    break;}
case 14:
#line 176 "script.y"
{
		    OutputIndentation();
		    OutputArgList(yyvsp[0].str);
		  ;
    break;}
case 21:
#line 189 "script.y"
{
		    yyaccept();
		  ;
    break;}
case 22:
#line 195 "script.y"
{
		    OutputIndentation();
		    Output("while (", yyvsp[-1].expr.s, ")", NULL);
		  ;
    break;}
case 23:
#line 200 "script.y"
{
		    OutputIndentation();
		    Output("end", NULL);
		  ;
    break;}
case 24:
#line 207 "script.y"
{
		    OutputIndentation();
		    Output("for (", yyvsp[-5].str, "; ", yyvsp[-3].expr.s, "; ", yyvsp[-1].str, ")", NULL);
		  ;
    break;}
case 25:
#line 213 "script.y"
{
		    OutputIndentation();
		    Output("end", NULL);
		  ;
    break;}
case 26:
#line 220 "script.y"
{
			BEGIN FUNCLIT;
			OutputIndentation();
			Output("foreach ", yyvsp[-1].str, " (", NULL);
		    ;
    break;}
case 27:
#line 226 "script.y"
{
			BEGIN 0;
			OutputArgList(yyvsp[-1].str);
			Output(")", NULL);
		    ;
    break;}
case 28:
#line 232 "script.y"
{
		    OutputIndentation();
		    Output("end", NULL);
		  ;
    break;}
case 29:
#line 239 "script.y"
{
		    OutputIndentation();
		    Output("if (", yyvsp[-1].expr.s, ")", NULL);
		  ;
    break;}
case 30:
#line 244 "script.y"
{
		    OutputIndentation();
		    Output("end", NULL);
		  ;
    break;}
case 31:
#line 251 "script.y"
{
 		    yyval.str = NULL;
 		  ;
    break;}
case 32:
#line 255 "script.y"
{ OutputIndentation(); Output("else", NULL); ;
    break;}
case 33:
#line 257 "script.y"
{ yyval.str = NULL; ;
    break;}
case 34:
#line 261 "script.y"
{
		    yyval.str = Combine(yyvsp[-2].str, " = ", yyvsp[0].expr.s, NULL);
		  ;
    break;}
case 35:
#line 267 "script.y"
{
		    Pushyybgin(LIT);
		  ;
    break;}
case 36:
#line 271 "script.y"
{
		    OutputIndentation();
		    Output("include ", yyvsp[0].str, " ", NULL);
		  ;
    break;}
case 37:
#line 278 "script.y"
{
		    Popyybgin();
		    OutputArgList(yyvsp[-1].str);
		  ;
    break;}
case 38:
#line 283 "script.y"
{
		    Popyybgin();
		  ;
    break;}
case 39:
#line 289 "script.y"
{
		    yyval.str = (char*) strsave("");
		  ;
    break;}
case 40:
#line 293 "script.y"
{
		    yyval.str = yyvsp[0].str;
		  ;
    break;}
case 41:
#line 299 "script.y"
{
		    Pushyybgin(FUNCLIT);
		  ;
    break;}
case 42:
#line 303 "script.y"
{
		    char	cmd[200];

		    sprintf(cmd, "%s%s", yyvsp[-2].str, yyvsp[0].str);
		    free(yyvsp[-2].str);
		    free(yyvsp[0].str);
		    yyval.str = (char*) strsave(cmd);
		  ;
    break;}
case 43:
#line 314 "script.y"
{
		    BEGIN LIT;
		  ;
    break;}
case 44:
#line 318 "script.y"
{
		    char*	cmdname;
		    char**	argv;
		    int		i;

		    Popyybgin();
		    cmdname = yyvsp[-3].str;
		    argv = (char**) yyvsp[-1].str;
		    switch (MapCommand(&cmdname, argv, NULL))
		      {
		      case -1:
			fprintf(stderr, "Error mapping command: %s", cmdname);
			for (i = 0; argv[i] != NULL; i++)
			    fprintf(stderr, " %s", argv[i]);
			fprintf(stderr, "\n");
			InsertItemInArgList(argv, 0, "/* Could not map:", 100);
			InsertItemInArgList(argv, 1, cmdname, 100);
			AddItemToArgList(argv, "*/", 100);
			break;
		      case 0:
			argv[0] = NULL; /* don't output anything */
			break;
		      default:
			InsertItemInArgList(argv, 0, cmdname, 100);
			break;
		      }
		    yyval.str = (char*) argv;
		  ;
    break;}
case 45:
#line 347 "script.y"
{
		    char*	cmdname;
		    char**	argv;
		    int		i;

		    Popyybgin();
		    cmdname = yyvsp[-5].str;
		    argv = (char**) yyvsp[-2].str;
		    switch (MapCommand(&cmdname, argv, NULL))
		      {
		      case -1:
			fprintf(stderr, "Error mapping command: %s", cmdname);
			for (i = 0; argv[i] != NULL; i++)
			    fprintf(stderr, " %s", argv[i]);
			fprintf(stderr, "\n");
			InsertItemInArgList(argv, 0, "/* Could not map:", 100);
			InsertItemInArgList(argv, 1, cmdname, 100);
			AddItemToArgList(argv, "*/", 100);
			break;
		      case 0:
			argv[0] = NULL; /* don't output anything */
			break;
		      default:
			InsertItemInArgList(argv, 0, cmdname, 100);
			break;
		      }
		    yyval.str = (char*) argv;
		  ;
    break;}
case 46:
#line 378 "script.y"
{
		    Pushyybgin(FUNCLIT);
		    yyval.str = yyvsp[0].str;
		  ;
    break;}
case 47:
#line 385 "script.y"
{
		    char*	cmdname;
		    char**	argv;

		    Popyybgin();
		    cmdname = yyvsp[-5].str;
		    argv = (char**) yyvsp[-2].str;
		    InsertItemInArgList(argv, 0, cmdname, 100);
		    yyval.str = (char*) argv;
		  ;
    break;}
case 48:
#line 396 "script.y"
{
		    BEGIN LIT;
		  ;
    break;}
case 49:
#line 400 "script.y"
{
		    char*	cmdname;
		    char**	argv;

		    Popyybgin();
		    cmdname = yyvsp[-3].str;
		    argv = (char**) yyvsp[-1].str;
		    InsertItemInArgList(argv, 0, cmdname, 100);
		    yyval.str = (char*) argv;
		  ;
    break;}
case 50:
#line 413 "script.y"
{
		    char**	argv;

		    argv = AllocateArgList(100);
		    argv[0] = NULL;
		    yyval.str = (char*) argv;
		  ;
    break;}
case 51:
#line 421 "script.y"
{
		    char**	argv;

		    argv = (char**) yyvsp[-2].str;
		    AddItemToArgList(argv, yyvsp[0].str, 100);

		    yyval.str = yyvsp[-2].str;
		  ;
    break;}
case 52:
#line 432 "script.y"
{
		    char**	argv;

		    argv = AllocateArgList(100);
		    argv[0] = yyvsp[0].str;
		    argv[1] = NULL;
		    yyval.str = (char*) argv;
		  ;
    break;}
case 53:
#line 441 "script.y"
{
		    char**	argv;

		    argv = (char**) yyvsp[-2].str;
		    AddItemToArgList(argv, yyvsp[0].str, 100);

		    yyval.str = yyvsp[-2].str;
		  ;
    break;}
case 58:
#line 460 "script.y"
{
		    char**	argv;

		    argv = AllocateArgList(100);
		    argv[0] = yyvsp[0].str;
		    argv[1] = NULL;
		    yyval.str = (char*) argv;
		  ;
    break;}
case 59:
#line 469 "script.y"
{
		    char**	argv;

		    argv = (char**) yyvsp[-4].str;
		    AddItemToArgList(argv, yyvsp[0].str, 100);

		    yyval.str = yyvsp[-4].str;
		  ;
    break;}
case 62:
#line 484 "script.y"
{
			    yyval.str = yyvsp[0].str;
			  ;
    break;}
case 63:
#line 488 "script.y"
{
			    yyval.str = Combine(yyvsp[-1].str, yyvsp[0].str, NULL);
			  ;
    break;}
case 64:
#line 494 "script.y"
{
		    yyval.str = yyvsp[0].str;
		  ;
    break;}
case 65:
#line 498 "script.y"
{
		    yyval.str = Combine("\"", yyvsp[0].str, "\"", NULL);
		  ;
    break;}
case 66:
#line 502 "script.y"
{
		    yyval.str = yyvsp[0].str;
		  ;
    break;}
case 67:
#line 506 "script.y"
{
		    Pushyybgin(0);
		  ;
    break;}
case 68:
#line 510 "script.y"
{
		    Popyybgin();
		  ;
    break;}
case 69:
#line 514 "script.y"
{
		    /*
		    ** Often the expression is just a call to a command
		    ** or function, in which case we get the command
		    ** already wrapped in a {} pair.  Avoid the additional
		    ** curley braces.
		    */

		    if (AlreadyBracketed(yyvsp[-2].expr.s))
			yyval.str = yyvsp[-2].expr.s;
		    else
			yyval.str = Combine("{", yyvsp[-2].expr.s, "}", NULL);
		  ;
    break;}
case 70:
#line 530 "script.y"
{
		    ParseNode	*funcpn;
		    ResultValue	v;
		    Result	*rp;

		    rp = SymtabNew(&GlobalSymbols, yyvsp[0].str);
		    if (rp->r_type != 0 && rp->r_type != FUNCTION)
			fprintf(stderr, "WARNING: function name '%s' is redefining a variable!\n", yyvsp[0].str);

		    rp->r_type = FUNCTION;

		    OutputIndentation();
		    Output("extern ", yyvsp[0].str, NULL);
		  ;
    break;}
case 71:
#line 545 "script.y"
{
		    OutputIndentation();
		    Output("extern ", yyvsp[0].str, NULL);
		  ;
    break;}
case 72:
#line 552 "script.y"
{
		    ParseNode	*funcpn;
		    ResultValue	v;
		    Result	*rp;
		    char	*script;

		    if (InFunctionDefinition)
		      {
			fprintf(stderr, "Function definition within another function or\n");
			fprintf(stderr, "within a control structure (FUNCTION %s).\n", yyvsp[0].str);
			fprintf(stderr, "conversion failed\n");
			exit(1);
		      }

		    InFunctionDefinition++;
		    NextLocal = 0;
		    rp = SymtabNew(&GlobalSymbols, yyvsp[0].str);
		    if (rp->r_type != 0 && rp->r_type != FUNCTION)
			fprintf(stderr, "WARNING: function name '%s' is redefining a variable!\n", yyvsp[0].str);

		    rp->r_type = FUNCTION;

		    LocalSymbols = SymtabCreate();
		    yyval.str = yyvsp[0].str;
		  ;
    break;}
case 73:
#line 578 "script.y"
{
		    ParseNode	*funcpn;
		    ResultValue	v;
		    Result	*rp;
		    char	*script;

		    rp = (Result *) yyvsp[0].str;
		    if (InFunctionDefinition)
		      {
			fprintf(stderr, "Function definition within another function or\n");
			fprintf(stderr, "within a control structure (FUNCTION %s).\n", yyvsp[0].str);
			fprintf(stderr, "conversion failed\n");
			exit(1);
		      }

		    InFunctionDefinition++;
		    NextLocal = 0;
		    LocalSymbols = SymtabCreate();

		    yyval.str = yyvsp[0].str;
		  ;
    break;}
case 74:
#line 602 "script.y"
{
		    OutputIndentation();
		    Output("function ", yyvsp[0].str, NULL);
		    ReturnIdents = 1;
		  ;
    break;}
case 75:
#line 608 "script.y"
{
		    ReturnIdents = 0;
		  ;
    break;}
case 76:
#line 612 "script.y"
{
		    OutputIndentation();
		    Output("end", NULL);

		    InFunctionDefinition--;
		    SymtabDestroy(LocalSymbols);
		    LocalSymbols = NULL;
		  ;
    break;}
case 77:
#line 623 "script.y"
{ yyval.str = NULL; ;
    break;}
case 78:
#line 625 "script.y"
{
		    Output("(", NULL);
		  ;
    break;}
case 79:
#line 630 "script.y"
{ 
		    Output(")", NULL);
		  ;
    break;}
case 80:
#line 636 "script.y"
{
		    Output(yyvsp[0].str, NULL);
		    vardef(yyvsp[0].str, STR, SCAST, NULL);
		  ;
    break;}
case 81:
#line 641 "script.y"
{
		    Output(", ", yyvsp[0].str, NULL);
		    vardef(yyvsp[0].str, STR, SCAST, NULL);
		  ;
    break;}
case 82:
#line 648 "script.y"
{
		    ReturnIdents = 1;
		    DefType = INT;
		    DefCast = ICAST;
		    yyval.str = "int";
		  ;
    break;}
case 83:
#line 655 "script.y"
{
		    ReturnIdents = 1;
		    DefType = FLOAT;
		    DefCast = FCAST;
		    yyval.str = "float";
		  ;
    break;}
case 84:
#line 662 "script.y"
{
		    ReturnIdents = 1;
		    DefType = STR;
		    DefCast = SCAST;
		    yyval.str = "str";
		  ;
    break;}
case 85:
#line 671 "script.y"
{
		    OutputIndentation();
		    Output(yyvsp[-1].str, " ", yyvsp[0].str, NULL);
		    yyval.str = yyvsp[0].str;
		  ;
    break;}
case 87:
#line 680 "script.y"
{
		    ReturnIdents = 1;
		  ;
    break;}
case 88:
#line 684 "script.y"
{
		    yyval.str = Combine(yyvsp[-3].str, ", ", yyvsp[0].str, NULL);
		  ;
    break;}
case 89:
#line 690 "script.y"
{
		    ReturnIdents = 0;
		  ;
    break;}
case 90:
#line 694 "script.y"
{
		    vardef(yyvsp[-2].str, DefType, DefCast, NULL);
		    if (yyvsp[0].str != NULL)
			yyval.str = Combine(yyvsp[-2].str, " = ", yyvsp[0].str, NULL);
		    else
			yyval.str = yyvsp[-2].str;
		  ;
    break;}
case 91:
#line 704 "script.y"
{
		    yyval.str = NULL;
		  ;
    break;}
case 92:
#line 708 "script.y"
{
		    yyval.str = yyvsp[0].expr.s;
		  ;
    break;}
case 93:
#line 714 "script.y"
{
		    OutputIndentation();
		    Output("break", NULL);
		  ;
    break;}
case 94:
#line 721 "script.y"
{
		    OutputIndentation();
		    Output("return ", yyvsp[0].expr.s, NULL);
		  ;
    break;}
case 95:
#line 726 "script.y"
{
		    OutputIndentation();
		    Output("return", NULL);
		  ;
    break;}
case 96:
#line 733 "script.y"
{ yyval.str = NULL; ;
    break;}
case 97:
#line 737 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, "|", yyvsp[0].expr.s, NULL); ;
    break;}
case 98:
#line 739 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, "&", yyvsp[0].expr.s, NULL); ;
    break;}
case 99:
#line 741 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, "^", yyvsp[0].expr.s, NULL); ;
    break;}
case 100:
#line 743 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine("~", yyvsp[0].expr.s, NULL); ;
    break;}
case 101:
#line 746 "script.y"
{
		    if (yyvsp[-2].expr.t == STR && yyvsp[0].expr.t == STR)
		      {
			yyval.expr.s = Combine(yyvsp[-2].expr.s, " @ ", yyvsp[0].expr.s, NULL);
			yyval.expr.t = STR;
		      }
		    else
		      {
			yyval.expr.s = Combine(yyvsp[-2].expr.s, " + ", yyvsp[0].expr.s, NULL);
			yyval.expr.t = INT;
		      }
		  ;
    break;}
case 102:
#line 759 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " - ", yyvsp[0].expr.s, NULL); ;
    break;}
case 103:
#line 761 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, "*", yyvsp[0].expr.s, NULL); ;
    break;}
case 104:
#line 763 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, "/", yyvsp[0].expr.s, NULL); ;
    break;}
case 105:
#line 765 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, "%", yyvsp[0].expr.s, NULL); ;
    break;}
case 106:
#line 767 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine("-", yyvsp[0].expr.s, NULL); ;
    break;}
case 107:
#line 770 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " || ", yyvsp[0].expr.s, NULL); ;
    break;}
case 108:
#line 772 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " && ", yyvsp[0].expr.s, NULL); ;
    break;}
case 109:
#line 774 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine("!", yyvsp[0].expr.s, NULL); ;
    break;}
case 110:
#line 777 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " < ", yyvsp[0].expr.s, NULL); ;
    break;}
case 111:
#line 779 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " <= ", yyvsp[0].expr.s, NULL); ;
    break;}
case 112:
#line 781 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " > ", yyvsp[0].expr.s, NULL); ;
    break;}
case 113:
#line 783 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " >= ", yyvsp[0].expr.s, NULL); ;
    break;}
case 114:
#line 785 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " == ", yyvsp[0].expr.s, NULL); ;
    break;}
case 115:
#line 787 "script.y"
{ yyval.expr.t = INT; yyval.expr.s = Combine(yyvsp[-2].expr.s, " != ", yyvsp[0].expr.s, NULL); ;
    break;}
case 116:
#line 790 "script.y"
{
			BEGIN FUNCLIT;
		    ;
    break;}
case 117:
#line 794 "script.y"
{
			BEGIN 0;
		    ;
    break;}
case 118:
#line 798 "script.y"
{
		    char*	cmdname;
		    char**	argv;
		    char*	argstr;
		    int		retstr;
		    int		i;

		    cmdname = yyvsp[-7].str;
		    argv = (char**) yyvsp[-3].str;
		    switch (MapCommand(&cmdname, argv, &retstr))
		      {
		      case -1:
			argstr = ArgListToStr(argv);
			fprintf(stderr, "Error mapping command: %s %s",
			    cmdname, argstr);
			for (i = 0; argv[i] != NULL; i++)
			    fprintf(stderr, " %s", argv[i]);
			fprintf(stderr, "\n");
			yyval.expr.t = INT;
			yyval.expr.s = Combine("/* Could not map: ", cmdname, " ",
							argstr, " */", NULL);
			break;
		      case 0:
			fprintf(stderr, "Possible replacement of a command in an expression\n");
			fprintf(stderr, "with multiple commands.  Look for \"probable error\"\n");
			fprintf(stderr, "in converted script file.\n");
			yyval.expr.t = INT;
			yyval.expr.s = "/* probable error */"; /* don't output anything */
			break;
		      default:
			yyval.expr.t = retstr ? STR : INT;
			yyval.expr.s = Combine("{", cmdname, " ", ArgListToStr(argv),
								    "}", NULL);
			break;
		      }
		  ;
    break;}
case 119:
#line 836 "script.y"
{
			BEGIN FUNCLIT;
		    ;
    break;}
case 120:
#line 840 "script.y"
{
			BEGIN 0;
		    ;
    break;}
case 121:
#line 844 "script.y"
{
		    yyval.expr.t = INT;
		    yyval.expr.s = Combine("{", yyvsp[-7].str, " ", ArgListToStr(yyvsp[-3].str), "}", NULL);
		  ;
    break;}
case 122:
#line 850 "script.y"
{ 
		    Result*	rp;

		    rp = SymtabLook(LocalSymbols, yyvsp[0].str);
		    if (rp == NULL)
			rp = SymtabLook(&GlobalSymbols, yyvsp[0].str);

		    yyval.expr.t = rp->r_type;
		    yyval.expr.s = yyvsp[0].str;
 		  ;
    break;}
case 123:
#line 862 "script.y"
{ 
		    yyval.expr.t = INT;
		    yyval.expr.s = Combine("{", yyvsp[0].str, "}", NULL);
 		  ;
    break;}
case 124:
#line 868 "script.y"
{ 
		    char*	cmdname;
		    char*	argv[1];
		    int		retstr;
		    int		i;

		    cmdname = yyvsp[0].str;
		    argv[0] = NULL;
		    switch (MapCommand(&cmdname, argv, &retstr))
		      {
		      case -1:
			fprintf(stderr, "Error mapping command: %s", cmdname);
			fprintf(stderr, "\n");
			yyval.expr.t = INT;
			yyval.expr.s = Combine("/* Could not map: ", cmdname,
							    " */", NULL);
			break;
		      case 0:
			fprintf(stderr, "Possible replacement of a command in an expression\n");
			fprintf(stderr, "with multiple commands.  Look for \"probable error\"\n");
			fprintf(stderr, "in converted script file.\n");
			yyval.expr.t = INT;
			yyval.expr.s = "/* probable error */"; /* don't output anything */
			break;
		      default:
			yyval.expr.t = retstr ? STR : INT;
			yyval.expr.s = Combine("{", cmdname, "}", NULL);
			break;
		      }
 		  ;
    break;}
case 125:
#line 900 "script.y"
{ 
		    yyval.expr.t = INT;
		    yyval.expr.s = yyvsp[0].str;
 		  ;
    break;}
case 126:
#line 905 "script.y"
{ 
		    yyval.expr.t = INT;
		    yyval.expr.s = yyvsp[0].str;
 		  ;
    break;}
case 127:
#line 910 "script.y"
{ 
		    yyval.expr.t = STR;
		    yyval.expr.s = Combine("\"", yyvsp[0].str, "\"", NULL);
 		  ;
    break;}
case 128:
#line 916 "script.y"
{
		    yyval.expr.t = STR;
		    yyval.expr.s = yyvsp[0].str;
		  ;
    break;}
case 129:
#line 922 "script.y"
{
		    yyval.expr.t = yyvsp[-1].expr.t;
		    yyval.expr.s = Combine("(", yyvsp[-1].expr.s, ")", NULL);
		  ;
    break;}
case 130:
#line 929 "script.y"
{
		    yyval.expr.t = yyvsp[-1].expr.t;
		    yyval.expr.s = Combine("(", yyvsp[-1].expr.s, ")", NULL);
		  ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 498 "/usr/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 935 "script.y"


#if defined(decalpha) && !defined(bison)
extern YYSTYPE	yylval;

#ifdef __FreeBSD__
#include "y.tab.h"
#endif

#include "lex.yy.c"

#endif
/*
** TokenStr
**
**	Return the token string for the given token.
*/

char *TokenStr(token)

int	token;

{	/* TokenStr --- Return token string for token */

	static char	buf[100];

	switch (token)
	  {

	  case LT: return("<");
	  case LE: return("<=");
	  case GT: return(">");
	  case GE: return(">=");
	  case EQ: return("==");
	  case NE: return("!=");

	  case OR: return("||");
	  case AND: return("&&");

#define	RET(tok)	case tok: return("tok")

	  RET(UMINUS);

	  RET(WHILE);
	  RET(IF);
	  RET(ELSE);
	  RET(FOR);
	  RET(FOREACH);
	  RET(END);
	  RET(INCLUDE);
	  RET(BREAK);
	  RET(INT);
	  RET(FLOAT);
	  RET(STR);
	  RET(RETURN);
	  RET(WHITESPACE);
	  RET(FUNCTION);
	  RET(INTCONST);
	  RET(DOLLARARG);
	  RET(FLOATCONST);
	  RET(STRCONST);
	  RET(LITERAL);
	  RET(IDENT);
	  RET(VARREF);
	  RET(FUNCREF);
	  RET(SL);
	  RET(COMMAND);
	  RET(ARGUMENT);
	  RET(ARGLIST);
	  RET(LOCREF);
	  RET(ICAST);
	  RET(FCAST);
	  RET(SCAST);

	  }

	if (token < 128)
	    if (token < ' ')
		sprintf(buf, "^%c", token+'@');
	    else
		sprintf(buf, "%c", token);
	else
	    sprintf(buf, "%d", token);

	return(buf);

}	/* TokenStr */



vardef(ident, type, castop, init)

char		*ident;
int		type;
int		castop;
char	*init;

{	/* vardef --- Define a variable */

	ParseNode	*pn;
	Result		*rp, r;
	ResultValue	v, slv;

	if (InFunctionDefinition && LocalSymbols != NULL)
	  {
	    rp = SymtabNew(LocalSymbols, ident);
	        rp->r_type = type;
		rp->r.r_loc.l_type = type;
		rp->r.r_loc.l_offs = NextLocal++;
	  }
	else
	  {
	    rp = SymtabNew(&GlobalSymbols, ident);

	    rp->r_type = type;
	  }

}	/* vardef */


ParseInit()

{    /* ParseInit --- Initialize parser variables */

        InFunctionDefinition = 0;
	Compiling = 0;
	BreakAllowed = 0;
	LocalSymbols = NULL;
	nextchar(1);	/* Flush lexer input */

}    /* ParseInit */


int NestedLevel()

{    /* NestedLevel --- Return TRUE if in func_def or control structure */

        return(InFunctionDefinition || Compiling);

}    /* NestedLevel */

int AlreadyBracketed(str)

char*	str;

{	/* AlreadyBracketed --- Return TRUE if the string has valid curley
				braces */

	if (*str == '{')
	  {
	    int	braceCount;

	    braceCount = 1;
	    for (str++; braceCount > 0 && *str != '\0'; str++)
	      {
		if (*str == '{')
		    braceCount++;
		else if (*str == '}')
		    braceCount--;
	      }

	    return braceCount == 0 && *str == '\0';
	  }
	else
	    return 0;

}	/* AlreadyBracketed */
