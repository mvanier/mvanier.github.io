/*
** $Id: result.h,v 2.1.1.1 1999/03/17 07:53:34 mhucka Exp $
** $Log: result.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:34  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1995/01/13 01:09:48  dhb
** Initial revision
**
**
** This file is from GENESIS 1.4.1
**
** Revision 1.1  1992/12/11  19:05:10  dhb
** Initial revision
**
*/

/*
** Result structures used in script expression evaluations
*/

typedef struct _localval
  {
    short	l_type;
    short	l_offs;
  } LocalVal;

typedef union _resultvalue
  {
    int		r_int;
    double	r_float;
    char	*r_str;
    LocalVal	r_loc;
  }ResultValue;

typedef struct _result
  {
    int		r_type;
    ResultValue	r;
  } Result;
