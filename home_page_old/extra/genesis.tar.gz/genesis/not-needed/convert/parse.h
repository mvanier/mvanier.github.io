/*
** $Id: parse.h,v 2.1.1.1 1999/03/17 07:53:34 mhucka Exp $
** $Log: parse.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:34  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1995/01/13 01:09:48  dhb
** Initial revision
**
**
** This file is from GENESIS 1.4.1
**
** Revision 1.1  1992/12/11  19:05:08  dhb
** Initial revision
**
*/

/*
** Parsing related type and constant definitions
*/

#include "result.h"

typedef struct _pn
  {
    Result	pn_val;
    struct _pn	*pn_left;
    struct _pn	*pn_right;
  } ParseNode;

typedef struct _expr_t
  {
    int		t;
    char*	s;
  } expr_t;

typedef union _yyvals
  {
    int		iconst;
    double	fconst;
    char	*str;
    ParseNode	*pn;
    expr_t	expr;
  } YYSTYPE;


extern ParseNode *PTNew();
extern Result PTEval();
