static char rcsid[] = "$Id: strsave.c,v 2.1.1.1 1999/03/17 07:53:35 mhucka Exp $";

/*
** $Log: strsave.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:35  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.2  1997/08/08 19:28:43  dhb
** Added include of stdlib.h for malloc() return type
**
** Revision 1.1  1995/01/13 01:09:48  dhb
** Initial revision
**
 **
 ** This file is from GENESIS 1.4.1
 **
** Revision 1.1  1992/12/11  19:05:05  dhb
** Initial revision
**
*/

#include <stdio.h>
#include <stdlib.h>

extern int errno;

char *strsave(cp)

char	*cp;

{	/* strsave --- Allocate mem and save copy of string */

	char	*mem;

	mem = (char *) malloc(strlen(cp)+1);
	if (mem == NULL)
	  {
	    perror("strsave");
	    sig_msg_restore_context(0, errno);
	    /* No Return */
	  }

	strcpy(mem, cp);
	return(mem);

}	/* strsave */

char *CopyString(str)

char* str;

{
	return strsave(str);
}
