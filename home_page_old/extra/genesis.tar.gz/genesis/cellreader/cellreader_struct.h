/*
 *
 * Copyright (c) 1997 Michael Christopher Vanier
 * All rights reserved.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * In no event shall Michael Vanier or the Genesis Developer's Group
 * be liable to any party for direct, indirect, special, incidental, or
 * consequential damages arising out of the use of this software and its
 * documentation, even if Michael Vanier and the Genesis Developer's
 * Group have been advised of the possibility of such damage.
 *
 * Michael Vanier and the Genesis Developer's Group specifically
 * disclaim any warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose.
 * The software provided hereunder is on an "as is" basis, and Michael
 * Vanier and the Genesis Developer's Group have no obligation to
 * provide maintenance, support, updates, enhancements, or modifications.
 *
 */

/*
 * cellreader_struct.h
 */

#ifndef CELLREADER_STRUCT_H
#define CELLREADER STRUCT_H


struct Cellreader_data_type
{
    /* Compartment fields: */

    double   Em;
    double   initVm;
    double   RM;
    double   CM;
    double   RA;

    /* Location/position parameters: */

    double   last_x;  /* *Absolute* x position of last compt defined. */
    double   last_y;
    double   last_z;

    /* These are the fields of the regular line of the .p file: */

    char     name[LABEL_LENGTH];      /* Name argument of regular line of
                                         .p file.  */
    char     real_name[LABEL_LENGTH]; /* name + an optional array index
                                         (for cables).  */
    char     parent[LABEL_LENGTH];    /* Parent argument of regular line of
                                         .p file. */

    double   x;    /* *Relative* x position of current compartment/cable. */
    double   y;
    double   z;
    double   dia;  /* Diameter or starting diameter of compartment/cable. */
    double   end_dia;  /* End diameter (tapered cables only).    */
    int      nseg;     /* Number of segments in a "cable".       */
    double   len;      /* Total length of compartment or cable.  */

    /* These fields are computed for each compartment: */

    double   real_x;    /* Relative x position of actual compartment. */
    double   real_y;
    double   real_z;
    double   real_dia;  /* Diameter of *actual* compartment, not of cable. */
    double   real_begin_dia;  /* Diameter of beginning of compartment,
                                 for tapered cables only.  */
    double   real_end_dia;    /* Diameter of end of compartment,
                                 for tapered cables only.  */
    double   real_len;
    double   real_area;       /* Area of *actual* compartment, not cable. */
    double   cum_len;         /* Cumulative length so far along cable.    */
    double   last_cum_len;    /* Previous value of cum_len.               */
    double   prop_len;        /* cum_len / len; proportion of total length
                                 so far.  */
    double   last_prop_len;   /* last_cum_len / len  */
    int      current_seg;     /* Current segment of a cable. */
    short    is_tapered;      /* Flag: 0 if not a tapered cable;
                               1 if a tapered cable.  */

    /* These fields are computed as needed. */

    double   elength_total;    /* Total electrotonic length of cable.  */
    double   elength_per_seg;  /* Electrotonic length per segment:
                                total_elength/len  */

    /* Other variables: */

    short    shape;            /* CYLINDER or SPHERE; see macros in
                                  cellreader_out.h  */
    short    type;             /* ASYMMETRICAL or SYMMETRICAL; ditto     */
    Element *last_compt;       /* Address of last compartment copied.    */
    Element *new_compt;        /* Address of current compartment copied. */
    short    lambda_warn;      /* Whether to warn if compartment length
                                exceeds some threshold.  */
    double   lambda_warn_threshold;  /* The maximum number of space
                                        constants a compartment can be.  */

    /* Path names: */

    char     cellpath[LABEL_LENGTH];           /* Path name of base element
                                                  of new cell.  */
    char     proto_comptpath[LABEL_LENGTH];    /* Path name of prototype
                                                  compt to be copied.    */
    char     current_comptpath[LABEL_LENGTH];  /* Path name of current
                                                  compartment.  */

    /* Other stuff: */

    int      args_read;  /* Number of arguments read by READCELL action.  */
};

#endif  /* CELLREADER_STRUCT_H */

