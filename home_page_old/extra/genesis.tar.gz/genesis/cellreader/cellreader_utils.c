/*
 *
 * Copyright (c) 1997 Michael Christopher Vanier
 * All rights reserved.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * In no event shall Michael Vanier or the Genesis Developer's Group
 * be liable to any party for direct, indirect, special, incidental, or
 * consequential damages arising out of the use of this software and its
 * documentation, even if Michael Vanier and the Genesis Developer's
 * Group have been advised of the possibility of such damage.
 *
 * Michael Vanier and the Genesis Developer's Group specifically
 * disclaim any warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose.
 * The software provided hereunder is on an "as is" basis, and Michael
 * Vanier and the Genesis Developer's Group have no obligation to
 * provide maintenance, support, updates, enhancements, or modifications.
 *
 */

/*
 * Cellreader_utils.c: utility functions for the cellreader.
 */

#include "cellreader_ext.h"
#include "system_deps.h"     /* for bcopy */
#include "hh_struct.h"       /* for vdep_channel definition */
#include "newconn_struct.h"  /* for synchan definition etc. */
#include "olf_struct.h"      /* for tabchannel definition   */
#include "seg_struct.h"      /* for compartment definition  */


/* From compartment.c: */

#define RAXIAL            1
#define AXIAL             2


/* From spikegen.c, more or less: */

#define spikegen_INPUT 0


/*
 * Message values.  These are standard throughout genesis.  If
 * you design a channel, make sure these message definitions hold
 * if you want to use the read_channel-type functions.
 */

#define CHANNEL 0   /* Received by compartment objects. */
#define VOLTAGE 0   /* Received by channel objects.     */




/*
 * print_arglist
 *
 * FUNCTION
 *     A debugging function which prints all arguments to an arglist.
 *
 * ARGUMENTS
 *     int    argc -- argument count
 *     char **argv -- argument list
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
print_arglist(int argc, char **argv)
{
    int i;

    for (i = 0; i < argc; i++)
        printf("\targv[%d] = %s\n", i, argv[i]);
}




/*
 * remove_args_from_arglist
 *
 * FUNCTION
 *     A trivial little function to remove arguments from an arglist.
 *
 * ARGUMENTS
 *     int     num  -- the number of args to remove
 *     int    *argc -- argument count
 *     char ***argv -- argument list
 *
 * RETURN VALUE
 *     void; argc is decremented by num and argv is incremented by num.
 *           If argc is 0 argv is set to NULL.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
remove_args_from_arglist(int num, int *argc, char ***argv)
{
    if (num <= 0)
    {
        return;
    }

    if (num > *argc)
    {
        Error();
        printf("remove_args_from_arglist: too few args!\n");
        return;
    }

    *argc -= num;
    *argv += num;

    if (*argc == 0) /* No arguments left. */
    {
        *argv = NULL;
    }
}




/*
 * Cellreader_do_copy
 *
 * FUNCTION
 *     This function is an interface to the do_copy function which does
 *     some simple error checking.
 *
 * ARGUMENTS
 *     argc -- number of arguments
 *     argv -- argument list
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_do_copy(int argc, char **argv)
{
#ifdef DEBUG
    printf("Cellreader_do_copy: \n");
    print_arglist(argc, argv);
#endif

    /*
     * argv[1] has to be the name of a real compartment.
     * If not, do_copy will flag the error.  However, if it
     * is a null string, you get an obscure "can't copy an
     * element to itself" error, which is not helpful.  So
     * here I check for the latter case.
     */

    if (strcmp(argv[1], "") == 0)
    {
        Error();
        printf("Cellreader_do_copy: source element not specified! "
               "(Missing prototype?)\n");
        return 0;
    }

    do_copy(argc, argv);

    /*
     * Returning 1 is lame, since errors can still occur, but do_copy never
     * returns anything useful wrt error status.
     */

    return 1;
}




/*
 * init_Cellreader_data
 *
 * FUNCTION
 *     Initializes the Cellreader_data struct to its default values.
 *
 * ARGUMENTS
 *     none
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
init_Cellreader_data()
{
    Cellreader_data.Em                    = 0.0;
    Cellreader_data.initVm                = 0.0;
    Cellreader_data.RM                    = 1.0;
    Cellreader_data.CM                    = 1.0;
    Cellreader_data.RA                    = 1.0;

    Cellreader_data.last_x                = 0.0;
    Cellreader_data.last_y                = 0.0;
    Cellreader_data.last_z                = 0.0;

    strcpy(Cellreader_data.name,      "");
    strcpy(Cellreader_data.real_name, "");
    strcpy(Cellreader_data.parent,    "");

    Cellreader_data.x                     = 0.0;
    Cellreader_data.y                     = 0.0;
    Cellreader_data.z                     = 0.0;
    Cellreader_data.dia                   = 0.0;
    Cellreader_data.end_dia               = 0.0;
    Cellreader_data.nseg                  = 1;

    Cellreader_data.len                   = 0.0;

    Cellreader_data.real_x                = 0.0;
    Cellreader_data.real_y                = 0.0;
    Cellreader_data.real_z                = 0.0;
    Cellreader_data.real_dia              = 0.0;
    Cellreader_data.real_begin_dia        = 0.0;
    Cellreader_data.real_end_dia          = 0.0;
    Cellreader_data.real_len              = 0.0;
    Cellreader_data.real_area             = 0.0;
    Cellreader_data.cum_len               = 0.0;
    Cellreader_data.last_cum_len          = 0.0;
    Cellreader_data.prop_len              = 0.0;
    Cellreader_data.last_prop_len         = 0.0;
    Cellreader_data.is_tapered            = 0;

    Cellreader_data.elength_total         = 0.0;
    Cellreader_data.elength_per_seg       = 0.0;

    Cellreader_data.shape                 = CYLINDER;
    Cellreader_data.type                  = ASYMMETRICAL;

    Cellreader_data.last_compt            = NULL;
    Cellreader_data.new_compt             = NULL;

    /* Default: compartments should be < 0.1 lambda long. */
    Cellreader_data.lambda_warn           = 1;
    Cellreader_data.lambda_warn_threshold = 0.1;

    strcpy(Cellreader_data.cellpath,          "");
    strcpy(Cellreader_data.proto_comptpath,   "");
    strcpy(Cellreader_data.current_comptpath, "");

    Cellreader_data.args_read             = 0;
}




/*
 * display_Cellreader_data
 *
 * FUNCTION
 *     This function prints out the contents of the global
 *     Cellreader_data struct.  It is for debugging only.
 *
 * ARGUMENTS
 *     none
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
display_Cellreader_data()
{
    printf("\n");
    printf("Cellreader data: \n");
    printf("---------------  \n");
    printf("\n");

    printf("Em                    = %g\n", Cellreader_data.Em             );
    printf("initVm                = %g\n", Cellreader_data.initVm         );
    printf("RM                    = %g\n", Cellreader_data.RM             );
    printf("CM                    = %g\n", Cellreader_data.CM             );
    printf("RA                    = %g\n", Cellreader_data.RA             );

    printf("last_x                = %g\n", Cellreader_data.last_x         );
    printf("last_y                = %g\n", Cellreader_data.last_y         );
    printf("last_z                = %g\n", Cellreader_data.last_z         );

    printf("name                  = %s\n", Cellreader_data.name           );
    printf("real_name             = %s\n", Cellreader_data.real_name      );
    printf("parent                = %s\n", Cellreader_data.parent         );

    printf("x                     = %g\n", Cellreader_data.x              );
    printf("y                     = %g\n", Cellreader_data.y              );
    printf("z                     = %g\n", Cellreader_data.z              );
    printf("dia                   = %g\n", Cellreader_data.dia            );
    printf("end_dia               = %g\n", Cellreader_data.end_dia        );
    printf("nseg                  = %d\n", Cellreader_data.nseg           );

    printf("len                   = %g\n", Cellreader_data.len            );

    printf("real_x                = %g\n", Cellreader_data.real_x         );
    printf("real_y                = %g\n", Cellreader_data.real_y         );
    printf("real_z                = %g\n", Cellreader_data.real_z         );
    printf("real_dia              = %g\n", Cellreader_data.real_dia       );
    printf("real_len              = %g\n", Cellreader_data.real_len       );
    printf("real_area             = %g\n", Cellreader_data.real_area      );
    printf("cum_len               = %g\n", Cellreader_data.cum_len        );
    printf("last_cum_len          = %g\n", Cellreader_data.last_cum_len   );
    printf("prop_len              = %g\n", Cellreader_data.prop_len       );
    printf("last_prop_len         = %g\n", Cellreader_data.last_prop_len  );
    printf("is_tapered            = %d\n", Cellreader_data.is_tapered     );

    printf("elength_total         = %g\n", Cellreader_data.elength_total  );
    printf("elength_per_seg       = %g\n", Cellreader_data.elength_per_seg);


    if (Cellreader_data.shape == CYLINDER)
    {
        printf("shape                 = CYLINDER\n");
    }
    else if (Cellreader_data.shape == SPHERE)
    {
        printf("shape                 = SPHERE\n");
    }
    else
    {
        Error();
        printf("readcell: Unknown shape: %d\n", Cellreader_data.shape);
        return;
    }

    if (Cellreader_data.type == ASYMMETRICAL)
    {
        printf("type                  = ASYMMETRICAL\n");
    }
    else if (Cellreader_data.type == SYMMETRICAL)
    {
        printf("type                  = SYMMETRICAL\n");
    }
    else
    {
        Error();
        printf("readcell: Unknown type: %d\n", Cellreader_data.type);
        return;
    }

    printf("last_compt            = 0x%lx\n",
           ((unsigned long) Cellreader_data.last_compt));
    printf("new_compt             = 0x%lx\n",
           ((unsigned long) Cellreader_data.new_compt));

    printf("lambda_warn           = %d\n",
           Cellreader_data.lambda_warn);
    printf("lambda_warn_threshold = %g\n",
           Cellreader_data.lambda_warn_threshold);

    printf("cellpath              = %s\n",
           Cellreader_data.cellpath);
    printf("comptpath             = %s\n",
           Cellreader_data.proto_comptpath);
    printf("current_comptpath     = %s\n",
           Cellreader_data.current_comptpath);

    printf("args_read             = %d\n",
           Cellreader_data.args_read);
    printf("\n");
}




#define IS_WHITE_SPACE(c)      ((c == ' ') || (c == '\t') || (c == '\n'))
#define IS_STRING_END(c)       (c == '\0')

#ifndef ARGV_RESIZE
#define ARGV_RESIZE 10
#endif

extern void ReallocateArgList();

/*
 * string_to_arg_list
 *
 * FUNCTION
 *     This is a simpler version of StringToArgList which doesn't
 *     deal with string delimiters.  The StringToArgList code that
 *     did deal with string delimiters looked flawed to me anyway.
 *
 * ARGUMENTS
 *     string -- the source string
 *     argc   -- the argument count
 *     argv   -- the argument list
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
string_to_arg_list(char *string, int *argc, char ***argv)
{
    char    **new_argv;
    char     *sptr;
    int       cnt;
    int       argv_size;
    int       length;
    char     *begin;

    /*
     * Set up a pointer to the new string copy.
     */

    sptr = string;

    /*
     * Keep track of the number of arguments in the list.
     */

    cnt = 0;

    /*
     * Allocate the list.
     */

    argv_size = ARGV_RESIZE;
    new_argv = (char **)calloc(argv_size, sizeof(char *));

    /*
     * Construct the argument list.
     */

    while (!IS_STRING_END(*sptr))
    {
        /*
         * Skip leading blanks.
         */

        while (IS_WHITE_SPACE(*sptr))
        {
            sptr++;
        }

        if (IS_STRING_END(*sptr))
        {
            break;
        }

        /*
         * Point to the beginning of the argument.
         */

        new_argv[cnt] = sptr;

        /*
         * Find the end of the argument.
         */

        length = 0;
        begin  = sptr;

        while (!IS_STRING_END(*sptr))
        {
            /*
             * Break on white space.
             */

            if (IS_WHITE_SPACE(*sptr))
            {
                break;
            }

            sptr++;
            length++;
        }

        /*
         * Copy the argument.
         */

        new_argv[cnt] = (char *)calloc(length + 1, sizeof(char));
        bcopy(begin, new_argv[cnt], length);

        /*
         * Increment the argument count and check against the current size
         * of the argv list.  If the argv list is too small then reallocate.
         *
         * Note: ReallocateArgList uses the same value for ARGV_RESIZE as
         *       I do here (10).  This is kludgy since the value of
         *       ARGV_RESIZE here has no effect on how much the arglist
         *       size is incremented.
         */

        if (++cnt >= argv_size)
        {
            ReallocateArgList(&new_argv, &argv_size);
        }
    }

    new_argv[cnt] = NULL;
    *argc = cnt;
    *argv = new_argv;
}




/*
 * CallReadcellAction
 *
 * FUNCTION
 *     This function is a nice interface to CallActionFunc which packages
 *     the (argc/argv) pair as well as the readcell case into the READCELL
 *     action and calls the action.  If there is no READCELL action then
 *     CallActionFunc will return -1, which will be passed back to the caller
 *     (and will normally be ignored, i.e. it won't be an error but it won't
 *     do anything).
 *
 * ARGUMENTS
 *     element -- pointer to the element
 *     argc    -- the argument count
 *     argv    -- the argument list
 *     case    -- which readcell case we want to execute.
 *                See cellreader_out.h for valid cases.
 *
 * RETURN VALUE
 *     int  -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
CallReadcellAction(Element *element, int argc, char **argv,
                   int readcell_case)
{
    int     tempcase = readcell_case; /* Temporary variable to store
                                       * the case value. */
    Action *action;
    int     status;

    if (readcell_case >= READCELL_CASE_END)
    {
        Error();
        printf("readcell: CallReadcellAction: unknown case %d\n",
               tempcase);
        return 0;
    }

    action = GetAction("READCELL");

    action->argc = argc;
    action->argv = argv;
    action->data = (char *)(&tempcase); /* Must do this since case
                                         * will usually be a constant. */

    status = CallActionFunc(element, action);

    if (status == -1)
    {
        /*
         * CallActionFunc returns -1 if there is no action for the object
         * of which the element is a type.
         */

        Error();
        printf("readcell: CallReadcellAction: the element \"%s\" "
               "has no READCELL action!\n",
               element->name);
        return 0;
    }

    /*
     * status could be 0 or 1, depending on whether an error occurred while
     * calling the action.  The error messages if any will be printed in the
     * READCELL action code.
     */

    return status;
}




/***********************************************************************
 *                    SCALING UTILITY FUNCTIONS                        *
 ***********************************************************************/

/*
 * calc_elength_total
 *
 * FUNCTION
 *     Calculates the total electrotonic length of a cable.  For a
 *     tapered cable it does this by computing the integral of the
 *     electrotonic length over the cable.  This integral is:
 *
 *     El_total = 2 Sqrt[ RA / RM ] Integrate[ 1/d[x], {x, 0, l}]
 *
 *     where d[x_] := d[0] + ((d[0] - d[l])/l) x   is the diameter
 *     at any point along the cable.  For an untapered cable it just
 *     computes len/lambda, where lambda is the length constant.
 *
 * ARGUMENTS
 *     none -- they're all taken from Cellreader_data, which must have
 *             the correct values for RM, RA, CM, dia, end_dia (for
 *             tapered cables), and len.
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
calc_elength_total()
{
    double c1, len, c2, lambda;

    /* Error checks. */

    if (Cellreader_data.len <= 0.0)
    {
        Error();
        printf("readcell: calc_elength_total: "
               "len must be > 0!\n");
        return;
    }

    if (Cellreader_data.RM <= 0.0)
    {
        Error();
        printf("readcell: calc_elength_total: "
               "RM must be > 0!\n");
        return;
    }

    if (Cellreader_data.RA <= 0.0)
    {
        Error();
        printf("cellreader: calc_elength_total: "
               "RA must be > 0!\n");
        return;
    }

    if (Cellreader_data.is_tapered)
    {
        c1  = Cellreader_data.dia;
        len = Cellreader_data.len;
        c2  = (Cellreader_data.end_dia - c1) / len;

        Cellreader_data.elength_total
            = 4 * sqrt(Cellreader_data.RA / Cellreader_data.RM)
            * (sqrt(c1 + c2 * len) - sqrt(c1)) / c2;
    }
    else
    {
        lambda = sqrt(Cellreader_data.RM
                      / Cellreader_data.RA
                      * Cellreader_data.dia / 4.0);
        Cellreader_data.elength_total = Cellreader_data.len / lambda;
    }
}




/*
 * calc_tapered_area
 *
 * FUNCTION
 *     Calculates the real_area field of a tapered compartment of a
 *     cable by calculating the integral of the area over the
 *     compartment.
 *
 * ARGUMENTS
 *     none -- they're all taken from Cellreader_data, which must have
 *             the correct values for real_begin_dia, real_end_dia
 *             and real_len.
 *
 * RETURN VALUE
 *     double
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

double
calc_tapered_area()
{
    double r1  = Cellreader_data.real_begin_dia / 2.0;
    double r2  = Cellreader_data.real_end_dia / 2.0;
    double len = Cellreader_data.real_len;

    return(PI * (r1 + r2) *
           sqrt(len * len  +  (r1 - r2) * (r1 - r2)));
}




/*
 * Cellreader_calc_volume
 *
 * FUNCTION
 *     Calculates the volume of a compartment.
 *
 * ARGUMENTS
 *     none -- they're all taken from Cellreader_data, which must have
 *             the correct values for real_begin_dia and real_end_dia
 *             (for tapered cables), real_dia (for untapered cables),
 *             and real_len.
 *
 * RETURN VALUE
 *     double
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

double
Cellreader_calc_volume()
{
    double volume;

    if (Cellreader_data.shape == SPHERE)
    {
        double dia = Cellreader_data.real_dia;

        return PI * dia * dia * dia / 6.0;
    }

    /* Cylindrical compartment: */

    if (Cellreader_data.is_tapered)
    {
        double r1  = Cellreader_data.real_begin_dia / 2.0;
        double r2  = Cellreader_data.real_end_dia / 2.0;
        double len = Cellreader_data.real_len;

        volume = PI / 3.0 * len *
            (r1 * r1  +  r1 * r2  +  r2 * r2);
    }
    else
    {
        double r = Cellreader_data.real_dia / 2.0;

        volume = PI * r * r * Cellreader_data.real_len;
    }

    return volume;
}




/*
 * Cellreader_calc_shell_volume
 *
 * FUNCTION
 *     Calculates the volume of a shell of a given thickness in a
 *     compartment.
 *
 * ARGUMENTS
 *     thick -- thickness of shell.
 *           -- all the rest of the arguments are taken from Cellreader_data,
 *              which must have the correct values for real_begin_dia and *
 *              real_end_dia (for tapered cables), real_dia (for untapered *
 *              cables), and real_len.
 *
 * RETURN VALUE
 *     double
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

double
Cellreader_calc_shell_volume(double thick)
{
    double dia_outer = Cellreader_data.real_dia;
    double dia_inner = dia_outer - thick;
    double vol_outer, vol_inner;

    if (dia_inner < 0.0)
    {
        Error();
        printf("readcell: Cellreader_calc_shell_volume: "
               "shell thickness is larger than diameter!\n");
        return 0.0;  /* I can't think of a better error value... */
    }


    if (Cellreader_data.shape == SPHERE)
    {
        vol_outer = PI * dia_outer * dia_outer * dia_outer / 6.0;
        vol_inner = PI * dia_inner * dia_inner * dia_inner / 6.0;
    }
    else if (Cellreader_data.is_tapered)
    {
        /* Tapered cylindrical compartment. */

        double len = Cellreader_data.real_len;

        double r1_outer  = Cellreader_data.real_begin_dia / 2.0;
        double r1_inner  = (Cellreader_data.real_begin_dia - thick) / 2.0;

        double r2_outer  = Cellreader_data.real_end_dia / 2.0;
        double r2_inner  = (Cellreader_data.real_end_dia - thick) / 2.0;

        vol_outer = PI / 3.0 * len
            * (r1_outer * r1_outer
               + r1_outer * r2_outer
               + r2_outer * r2_outer);

        vol_inner = PI / 3.0 * len
            * (r1_inner * r1_inner
               + r1_inner * r2_inner
               + r2_inner * r2_inner);
    }
    else
    {
        /* Untapered cylindrical compartment. */

        double len = Cellreader_data.real_len;

        vol_outer = PI * len * dia_outer * dia_outer / 4.0;
        vol_inner = PI * len * dia_inner * dia_inner / 4.0;
    }

    return vol_outer - vol_inner;
}




/*
 * calc_tapered_cable_dimensions
 *
 * FUNCTION
 *     This function calculates the length and end diameter of a tapered
 *     cable segment given the end diameter of the previous segment, the end
 *     diameter of the cable, the desired electrotonic length of the segment,
 *     and the length from the current position to the end of the cable.  The
 *     first three are stored in Cellreader_data; the last is computed here.
 *     These equations are pretty gnarly.
 *
 * ARGUMENTS
 *     none -- all fields needed are located in Cellreader_data and the
 *             outputs go there too.
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
calc_tapered_cable_dimensions()
{
    double ds, de, el, lr;
    double K, K2, b, c, d, p, q, D, temp;
    double term1, term2;

    ds = Cellreader_data.real_end_dia;     /* Starting diameter;
                                              end dia of last segment.  */
    de = Cellreader_data.end_dia;          /* End diameter of cable
                                              as a whole.  */
    el = Cellreader_data.elength_per_seg;  /* Electrotonic length of
                                              segment. */

    /*
     * Cellreader_data.cum_len is the cumulative length up to the beginning
     * of this compartment.  lr is the length from the beginning of this
     * segment to the end of the cable.
     */

    lr = Cellreader_data.len - Cellreader_data.cum_len;

    /*
     * K is one relation between len and dia: dia = len^2 * K to give the
     * compartment the correct electrotonic length.
     */

    if (el <= 0.0)
    {
        Error();
        printf("readcell: calc_tapered_cable_dimensions: "
               "electrotonic length must be > 0!\n");
        return;
    }

    K = (4.0 * Cellreader_data.RM / Cellreader_data.RA)  /  (el * el);

    /*
     * The following is just solving a cubic equation.
     */

    /* FIXME: add better error checks! */
    assert(lr > 0.0);
    assert(K > 0.0);

    temp = de - ds;

    K2 = sqrt(1.0  +  temp * temp / (4.0 * lr));

    b = ((4.0 * temp / lr) * (-temp / lr - 2.0 * K2)) / K;
    c = (-16.0 * ds * K2  -  8.0 * temp * ds / lr) / K;
    d = (-8.0 * ds * ds) / K;

    p = (3.0 * c  -  b * b) / 3.0;
    q = (2.0 * b * b * b  -  9 * b * c  +  27.0 * d) / 27.0;

    D = p * p * p / 27.0  +  q * q / 4.0;

    /*
     * We have to take some precautions here since pow() can't handle
     * negative first arguments for cube roots.  We take the real root in all
     * cases.  D should be positive regardless.
     */

    term1 = sqrt(D) - q / 2.0;

    if (term1 > 0.0)
    {
        term1 = pow(term1, 1.0 / 3.0);
    }
    else
    {
        term1 = -pow((-term1), 1.0 / 3.0);
    }

    term2 = sqrt(D) + q / 2.0;

    if (term2 > 0.0)
    {
        term2 = pow(term2, 1.0 / 3.0);
    }
    else
    {
        term2 = -pow((-term2), 1.0 / 3.0);
    }

    Cellreader_data.real_len = term1 + term2 - b / 3.0;

    /* Adjust the diameter fields. */

    Cellreader_data.real_begin_dia = Cellreader_data.real_end_dia;
    Cellreader_data.real_end_dia   = ds  +  (de - ds) / lr *
        Cellreader_data.real_len ;

    /*
     * real_dia has no significance for tapered cables; it's just a
     * nominal value for display purposes, so we average the values
     * at the endpoints.
     */

    Cellreader_data.real_dia = (Cellreader_data.real_begin_dia +
                                Cellreader_data.real_end_dia) / 2.0;
}




/*
 * calc_compt_dimensions
 *
 * FUNCTION
 *     This function calculates what the compartment x, y, z,
 *     dia, and len fields should be.  It handles regular compartments,
 *     compartments which are part of untapered cables, and
 *     compartments which are part of tapered cables.
 *
 * ARGUMENTS
 *     seg -- index of segment.  Other than this this routine
 *            uses the global values in the Cellreader_data
 *            struct exclusively for both input and output.
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
calc_compt_dimensions(int seg)
{
    /*
     * This routine takes as inputs from Cellreader_data:
     *
     * x
     * y
     * z
     * dia
     * end_dia
     * nseg
     * len
     *
     * and calculates:
     *
     * real_x
     * real_y
     * real_z
     * real_dia
     * real_begin_dia  (tapered cables only)
     * real_end_dia    (tapered cables only)
     * real_len
     * real_area
     * cum_len  (cumulative length so far in this cable)
     * last_cum_len
     * prop_len
     * last_prop_len
     * current_seg
     *
     * which it puts into Cellreader_data as well.
     *
     */

    double x, y, z, dia, len;
    int    nseg = Cellreader_data.nseg;
    double seg_prop_len;  /* For tapered cables only. */

    x = y = z = dia = len = 0.0;

    /*
     * First, dispense with $^#*$#@(*$^ spherical compartments,
     * the source of all readcell evil.
     */

    if (Cellreader_data.shape == SPHERE)
    {
        Cellreader_data.real_x         = Cellreader_data.x;
        Cellreader_data.real_y         = Cellreader_data.y;
        Cellreader_data.real_z         = Cellreader_data.z;
        dia = Cellreader_data.real_dia = Cellreader_data.dia;
        Cellreader_data.real_len       = 0.0;
        Cellreader_data.real_area      = PI * dia * dia;

        /*
         * We don't need cum_len or prop_len for spherical compartments,
         * since they can't be cables.  We set prop_len to 1.0 by default
         * in case anyone is stupid enough to use point process syntax
         * with spherical compartments.
         */

        Cellreader_data.cum_len        = 0.0;
        Cellreader_data.last_cum_len   = 0.0;
        Cellreader_data.prop_len       = 1.0;
        Cellreader_data.last_prop_len  = 0.0;
        Cellreader_data.current_seg    = 0;

        return;
    }

    /*
     * From here on in we're dealing with good old cylindrical
     * compartments.
     */

    Cellreader_data.last_cum_len  = Cellreader_data.cum_len;
    Cellreader_data.last_prop_len = Cellreader_data.prop_len;

    if (!(Cellreader_data.is_tapered)) /* Not a tapered cable. */
    {
        /*
         * Calculate the length and area of the compartment.
         */

        if (nseg == 1)  /* Not a cable. */
        {
            x   = Cellreader_data.real_x   = Cellreader_data.x;
            y   = Cellreader_data.real_y   = Cellreader_data.y;
            z   = Cellreader_data.real_z   = Cellreader_data.z;
            dia = Cellreader_data.real_dia = Cellreader_data.dia;
            len = Cellreader_data.real_len = Cellreader_data.len;
            Cellreader_data.real_area      = PI * dia * len;

            Cellreader_data.cum_len        = len;
            Cellreader_data.prop_len       = 1.0; /* In case someone uses
                                                     point process syntax. */
            Cellreader_data.current_seg    = 0;
        }
        else  /* A non-tapered cable. */
        {
            /*
             * We only have to calculate real_[xyz] etc. for the first
             * compartment of the cable.  All the other compartments in the
             * cable have the same values.
             */

            if (seg == 0)
            {
                assert(nseg > 0);  /* FIXME: make into an error check. */

                x   = Cellreader_data.real_x   = Cellreader_data.x / nseg;
                y   = Cellreader_data.real_y   = Cellreader_data.y / nseg;
                z   = Cellreader_data.real_z   = Cellreader_data.z / nseg;
                dia = Cellreader_data.real_dia = Cellreader_data.dia;
                len = Cellreader_data.real_len = Cellreader_data.len / nseg;
                Cellreader_data.real_area      = PI * dia * len;
            }

            if (Cellreader_data.len <= 0.0)
            {
                Error();
                printf("readcell: calc_compt_dimensions: "
                       "len must be > 0.0!\n");
                return;
            }

            Cellreader_data.cum_len  += Cellreader_data.real_len;
            Cellreader_data.prop_len
                = Cellreader_data.cum_len / Cellreader_data.len;
            Cellreader_data.current_seg = seg;
        }
    }
    else /* A tapered cable/compartment. */
    {
        if (nseg == 1)  /* Not a cable. */
        {
            Cellreader_data.real_x = Cellreader_data.x;
            Cellreader_data.real_y = Cellreader_data.y;
            Cellreader_data.real_z = Cellreader_data.z;

            len = Cellreader_data.real_len = Cellreader_data.len;
            dia = Cellreader_data.real_dia
                = (Cellreader_data.dia + Cellreader_data.end_dia) / 2.0;

            Cellreader_data.real_begin_dia = dia;
            Cellreader_data.real_end_dia   = Cellreader_data.end_dia;
            Cellreader_data.real_area      = calc_tapered_area();

            Cellreader_data.cum_len    = len;
            Cellreader_data.prop_len   = 1.0;  /* In case someone uses
                                                  point process syntax. */
            Cellreader_data.current_seg = 0;
        }
        else /* A tapered cable. */
        {
            /*
             * We split tapered cables NOT on the basis of length but on the
             * basis of *electrotonic* length.  Thus each compartment in the
             * cable must have the same electrotonic length (this is also
             * true, trivially, for untapered cables).  We call a function to
             * calculate the length and end diameter for tapered cables.
             *
             * FIXME: I believe this code is broken...
             */

            /*
             * This calculates real_len, real_begin_dia, real_end_dia
             * and real_dia.
             */

            calc_tapered_cable_dimensions();

            if (Cellreader_data.len <= 0.0)
            {
                Error();
                printf("readcell: calc_compt_dimensions: "
                       "len must be > 0.0!\n");
                return;
            }

            seg_prop_len = Cellreader_data.real_len / Cellreader_data.len;

            Cellreader_data.real_x    = Cellreader_data.x * seg_prop_len;
            Cellreader_data.real_y    = Cellreader_data.y * seg_prop_len;
            Cellreader_data.real_z    = Cellreader_data.z * seg_prop_len;

            Cellreader_data.real_area = calc_tapered_area();

            Cellreader_data.cum_len  += len;
            Cellreader_data.prop_len  = Cellreader_data.cum_len
                / Cellreader_data.len;
            Cellreader_data.current_seg = seg;
        }
    }
}




/*
 * Cellreader_GetCableIndex
 *
 * FUNCTION
 *     Gets the correct index value for a point on a cable which
 *     uses relative coordinates e.g. a number in [0,1].
 *
 * ARGUMENTS
 *     root      -- the root name of the cable.
 *     index_val -- the index value, which should be in [0,1]
 *
 * RETURN VALUE
 *     int  -- The cable index, or -1 if an error occurred.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_GetCableIndex(char *root, double index_val)
{
    Element *element;
    char    *value;
    int      nseg;
    double   temp, diff;


    /*
     * Check that the index is valid i.e. in the range [0, 1].
     */

    if ((index_val < 0.0) || (index_val > 1.0))
    {
        Error();
        printf("readcell: Cellreader_GetCableIndex: "
               "index value %g is out of range!\n",
               index_val);
        return -1;
    }


    /*
     * Locate the element.
     */

    element = GetElement(root);

    if (element == NULL)
    {
        Error();
        printf("readcell: Cellreader_GetCableIndex: "
               "could not find '%s'\n", root);
        return -1;
    }


    /*
     * Get the nseg value from the element.
     *
     * FIXME!  This will have to be extended considerably for tapered cables.
     */

    value = ElmFieldValue(element, "nseg");

    if (value == NULL)
    {
        Error();
        printf("readcell: Cellreader_GetCableIndex: "
               "could not get the value for field '%s'\n", "nseg");
        return -1;
    }

    nseg = atoi(value);

    /*
     * Calculate the index from index_val and the value of the
     * nseg field of the root element.
     *
     * FIXME!  This will have to be extended considerably for tapered cables.
     */

    /*
     * The index is easily calculated, but we have to be careful at the
     * boundaries.
     */

    temp = nseg * index_val;
    diff = temp - ((int) temp);

    if (diff < FTINY)
    {
        /*
         * We are very close to the boundary between regions.  Assign
         * such points to the slot below the boundary.
         */

        return (((int) temp) - 1);
    }
    else
    {
        return ((int) temp);
    }

    /*NOTREACHED*/
}




/*
 * Cellreader_is_a_point_process
 *
 * FUNCTION
 *     Checks whether a given element can be considered a point process.
 *
 * ARGUMENTS
 *     char *element_path -- the full pathname of the element.
 *
 * RETURN VALUE
 *     int  -- 0 if the element is not a point process, 1 if it is.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_is_a_point_process(char *element_path)
{
    /*
     * If the object is in the class "point_process", it's a
     * point process.
     */

    if (CheckClass(GetElement(element_path), ClassID("point_process")))
       return 1;


   /*
    * All synchans or derived elements are considered acceptable
    * point processes.
    */

    if (CheckClass(GetElement(element_path), ClassID("synchannel")))
        return 1;


    /* Spikegen objects are also point processes. */

    if (strcmp((GetElement(element_path))->object->name, "spikegen") == 0)
        return 1;

    /* Anything else is not (currently) a point process. */

    return 0;
}



/***********************************************************************
 *      UTILITY FUNCTIONS FOR COMPUTING INDEX VALUES FROM STRINGS      *
 ***********************************************************************/


/*
 * get_index_from_string
 *
 * FUNCTION
 *     To split a string up into a "root" part (containing an element
 *     name) and an optional "index" part (containing a string representing
 *     a proportional or absolute index value).
 *
 * ARGUMENTS
 *     const char *s -- The original string.
 *     char ldelim   -- The left index delimiter character,
 *                      either '[' or '('.
 *     char *root    -- The element name in the original string.
 *     char *index   -- The part of the string holding the index.
 *
 * RETURN VALUE
 *     int -- 1 if there is an index, 0 if not, and -1 if an error occurs.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */


static int
get_index_from_string(const char *s, char ldelim, char *root, char *index)
{
    char  rdelim;
    char *index_start, *index_end;
    int   len;

    /*
     * Copy the given string into the root string, which must be at least as
     * big.
     */

    strcpy(root, s);

    /*
     * Get the right index delimiter corresponding to the left delimiter
     * supplied.
     */

    if (ldelim == '[')
    {
        rdelim = ']';
    }
    else if (ldelim == '(')
    {
        rdelim = ')';
    }
    else
    {
        Error();
        printf("get_index_from_string: invalid left index delimiter `%c'.\n",
               ldelim);

        return -1;
    }

    /*
     * Find the last occurrences of the left and right delimiters.
     */

    len = strlen(s);
    index_start = strrchr(s, ldelim);
    index_end   = strrchr(s, rdelim);


    /* Miscellaneous error cases. */

    if ((index_start == NULL) && (index_end == NULL))
    {
        /* There is no index. */
        return 0;
    }
    else if ((index_start == NULL) || (index_end == NULL))
    {
        /* There is only an opening or a closing delimiter; invalid. */
        Error();
        printf("get_index_from_string: invalid string `%s' "
               "for delimiter `%c'.\n", s, ldelim);

        return -1;
    }
    else if (index_end <= index_start)
    {
        /* Delimiters are reversed; invalid. */
        Error();
        printf("get_index_from_string: invalid string `%s' "
               "for delimiter `%c'.\n", s, ldelim);

        return -1;
    }
    else if (index_end != &s[len - 1])
    {
        /* Index is not at the end of the string; invalid. */
        Error();
        printf("get_index_from_string: invalid string `%s' "
               "for delimiter `%c'.\n", s, ldelim);

        return -1;
    }

    /*
     * We have an index.  Create the root string and the index string.
     */

    root[index_start - s] = '\0';  /* Overwrite the left delimiter. */
    strcpy(index, index_start + 1);
    index[index_end - index_start - 1] = '\0';

    return 1;
}




/*
 * strip_leading_and_trailing_whitespace
 *
 * FUNCTION
 *     To strip leading and trailing whitespace from a string.
 *
 * ARGUMENTS
 *     const char *s -- The original string.
 *     char *t       -- The string without the leading and trailing
 *                      whitespace.
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

static void
strip_leading_and_trailing_whitespace(const char *s, char **t)
{
    int i, len;

    while ((**t == ' ') || (**t == '\t'))
        (*t)++;

    len = strlen(*t);

    for (i = len - 1; i >= 0; i--)
    {
        if (((*t)[i] == ' ') || ((*t)[i] == '\t'))
            (*t)[i] = '\0';
        else
            break;
    }
}




/*
 * get_absolute_index
 *
 * FUNCTION
 *     This function computes the absolute index value from
 *     a string containing an element name and an index in
 *     square brackets e.g. syn[10].
 *
 * ARGUMENTS
 *     const char *s -- the original string.
 *     char *t       -- temporary scratch space; as big as s.
 *     int  *n       -- the returned index value.
 *     int   max     -- the maximum allowable index value + 1.
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

static int
get_absolute_index(const char *s, char *t, int *n, int max)
{
    int m, r;
    int nmatched;
    int len;

    /*
     * Strip leading and trailing whitespace.
     */

    strip_leading_and_trailing_whitespace(s, &t);
    len = strlen(t);

    /* Make sure there's a number left to convert! */

    if (len < 1)
    {
        Error();
        printf("get_absolute_index: invalid index string `%s'.\n", s);

        return 0;
    }

    nmatched = sscanf(t, "%d%n", &m, &r);

    if ((nmatched != 1) || (r != strlen(t)))
    {
        Error();
        printf("get_absolute_index: invalid index string `%s'.\n", s);

        return 0;
    }

    if ((m < 0) || (m >= max))
    {
        Error();
        printf("get_absolute_index: invalid index value `%d'.\n", m);

        return 0;
    }

    *n = m;
    return 1;
}




/*
 * get_proportional_index
 *
 * FUNCTION
 *     This function computes the proportional index value from
 *     a string containing an element name and an index in
 *     parentheses e.g. syn(0.1).
 *
 * ARGUMENTS
 *     const char *s -- the original string.
 *     char   *t     -- temporary scratch space; as big as s.
 *     double *x     -- the returned index value.
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

static int
get_proportional_index(const char *s, char *t, double *x)
{
    double m;
    int r;
    int nmatched;
    int len;

    /*
     * Strip leading and trailing whitespace.
     */

    strip_leading_and_trailing_whitespace(s, &t);
    len = strlen(t);

    /* Make sure there's a number left to convert! */

    if (len < 1)
    {
        Error();
        printf("get_proportional_index: invalid index string `%s'.\n", s);

        return 0;
    }

    nmatched = sscanf(t, "%lg%n", &m, &r);

    if ((nmatched != 1) || (r != strlen(t)))
    {
        Error();
        printf("get_proportional_index: invalid index string `%s'.\n", s);

        return 0;
    }

    if ((m < 0.0) || (m > 1.0))
    {
        Error();
        printf("get_proportional_index: invalid index value `%.10g'.\n", m);

        return 0;
    }

    *x = m;

    return 1;
}




/*
 * Cellreader_get_absolute_index
 *
 * FUNCTION
 *     This function computes the absolute index value from
 *     a string containing an element name and an index in
 *     square brackets e.g. syn[10].  It also returns the root
 *     element name.
 *
 * ARGUMENTS
 *     const char *s -- the original string.
 *     char *root    -- the root element name.
 *     int  *n       -- the returned index value.
 *     int   max     -- the maximum allowable index value + 1.
 *
 *
 * RETURN VALUE
 *     int -- 1 if there is an index, 0 if not, and -1 if an error occurs.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_get_absolute_index(const char *s, char *root, int *n, int max)
{
    int   result;
    int   index;
    char  index_str[32];
    char *temp;

    /*
     * Calculate the root string and the index string.
     */

    result = get_index_from_string(s, '[', root, index_str);

    if (result <= 0)  /* No index or error. */
        return result;

    /*
     * Get the index number.
     */

    temp = (char *)calloc(strlen(index_str) + 1, sizeof(char));
    strcpy(temp, index_str);
    result = get_absolute_index(index_str, temp, &index, max);
    free(temp);

    if (result == 0)  /* Error. */
        return -1;

    *n = index;
    return 1;
}




/*
 * Cellreader_get_proportional_index
 *
 * FUNCTION
 *     This function computes the proportional index value from
 *     a string containing an element name and an index in
 *     square brackets e.g. syn(0.1).  It also returns the root
 *     element name.
 *
 * ARGUMENTS
 *     const char *s -- the original string.
 *     char   *root  -- the root element name.
 *     double *x     -- the returned index value.
 *
 *
 * RETURN VALUE
 *     int -- 1 if there is an index, 0 if not, and -1 if an error occurs.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_get_proportional_index(const char *s, char *root, double *x)
{
    int     result;
    double  index_val;
    char    index_str[32];
    char   *temp;

    /*
     * Calculate the root string and the index string.
     */

    result = get_index_from_string(s, '(', root, index_str);

    if (result <= 0)  /* No index or error. */
        return result;

    /*
     * Get the index value.
     */

    temp = (char *)calloc(strlen(index_str) + 1, sizeof(char));
    strcpy(temp, index_str);
    result = get_proportional_index(index_str, temp, &index_val);
    free(temp);

    if (result == 0)  /* Error. */
        return -1;

    *x = index_val;
    return 1;
}


/***********************************************************************
 *                 USER INTERFACE UTILITY FUNCTIONS                    *
 ***********************************************************************/

/*
 * Cellreader_read_channel
 *
 * FUNCTION
 *     Does a canonical scaling for a channel-type object which has
 *     a maximal conductance field which has to be scaled in proportion
 *     to the total membrane area of the compartment.  Messages may
 *     also have to be set up.
 *
 *     NOTE:  This function needs to know the type of the Gbar field,
 *            which can be either float or double.  It does this with
 *            an integer type field.  Macros corresponding to the various
 *            types are defined in sys/header.h, which should always be
 *            included automatically in all genesis code (since it's included
 *            from sim_ext.h which should be included in all <lib>_ext.h
 *            files).
 *
 *     NOTE2: The default scaling for point processes is absolute; i.e. use
 *            the density field directly as the Gbar value.
 *
 * >>>>>>>>>>> FIXME! Put in scaling which can be interpreted as either
 *                    relative or absolute!
 *
 * ARGUMENTS
 *     argc          -- count of arguments passed to the channel
 *                      in the READCELL action
 *     argv          -- arguments passed to the channel in the READCELL
 *                      action
 *     Gbar          -- (address of) the maximal conductance field
 *                      of the channel
 *     type          -- integer corresponding to FLOAT or DOUBLE macro
 *     pathname      -- element pathname
 *     point_process -- flag: 1 means it's a point process; 0 means it's not
 *                      (it's an int, not a short because otherwise we get
 *                      annoying compiler errors with gcc)
 *
 * RETURN VALUE
 *     int  -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */


int
Cellreader_read_channel(Action *action, void *Gbar, int type,
                        char *pathname, int point_process)
{
    int       argc;
    char    **argv;
    double    density, end_density;
    char     *temp;
    double   *dval;
    float    *fval;
    Element  *current, *parent;
    char      density_string[LABEL_LENGTH];
    short     absolute_scaling = 0;   /* Flag for absolute scaling,
                                         off by default. */

    /*
     * We don't need slot_type, but it has to be here to make
     * GetFieldAdr happy.
     */

    short slot_type;
    Slot  slot[2];


    argc = action->argc;
    argv = action->argv;

    /*
     * IMPROVEME!  Make it possible to scale anything any way we like i.e.
     * add support for relative and absolute scaling with the "r" and "a"
     * identifiers before the density number.
     */

    if (point_process)
    {
        absolute_scaling = 1;
    }


    switch (READCELL_CASE)
    {
    case DITCH_ARGUMENTS:
        /*
         * The object is a point process and all we want now is the number of
         * arguments that should be ditched from the argv list in
         * process_regular_command.  This corresponds to the case of a
         * location where the channel is not supposed to be.  The way
         * readcell handles cables is that a copy of the whole argv list
         * (except for the compartment dimensions etc.) is processed for each
         * compartment in the cable.  This is fine for range processes like
         * tabchannels which are copied into each compartment but is a little
         * awkward for point processes.  The way I've done it is very
         * flexible, but rather inefficient and somewhat confusing.
         */

        Cellreader_data.args_read = 2;

        break;


    case RESCALE_ONLY:

        /*
         * This case corresponds to a channel which was copied
         * along with its parent compartment by the cellreader.
         * In this case the messages have already been set up so
         * all we have to do is to scale the Gbar.  The convention
         * here is that the Gbar in the tabchannel to begin with is
         * the density, so we just have to multiply it by the
         * compartment area (except when the scaling is absolute).
         * Note also that you can't make tapering conductances this way;
         * sorry!
         */

        if (absolute_scaling)
        {
            break;  /* There's nothing to do. */
        }

        if (type == FLOAT)
        {
            fval     = (float *) Gbar;
            (*fval) *=  Cellreader_data.real_area;
        }
        else if (type == DOUBLE)
        {
            dval     = (double *) Gbar;
            (*dval) *=  Cellreader_data.real_area;
        }
        else
        {
            Error();
            printf("readcell: Cellreader_read_channel: "
                   "invalid type field: %d\n", type);
            return 0;
        }

        break;


    case ADD_MESSAGES_AND_RESCALE:

        if (argc < 2)
        {
            /* Not enough arguments, so return with an error. */

            Error();
            printf("readcell: Cellreader_read_channel: "
                   "need a density argument for %s!\n", pathname);
            return 0;
        }

        /*
         * argv[1] contains the density.  We have to scale it by
         * the area and set Gbar (if we're using relative scaling).
         * We also have to set up the messages between the compartment
         * and the channel.
         *
         * Note that argv[1] could also be a density *range*, i.e.
         * it could have the form d1:d2, where d1 is the initial
         * density and d2 is the final density.  This is parsed out
         * here and the appropriate density for this channel is
         * calculated.
         */

        strcpy(density_string, argv[1]);  /* So strtok doesn't
                                             mangle argv[1]. */

        density = Atod(strtok(density_string, ":"));
        temp    = strtok(NULL, ":");  /* Look for another number. */

        if (temp != NULL)  /* Found another number. */
        {
            double start, end;

            end_density = Atod(temp);

            start       = Cellreader_data.last_prop_len;
            end         = Cellreader_data.prop_len;

            /*
             * Now we calculate what the density should be given the range
             * and the current position of the compartment (which is
             * determined using the prop_len and last_prop_len fields of
             * Cellreader_data).  We do this by integrating the density over
             * the range (start, end).
             */

            /* FIXME!  This will be considerably more involved for tapered
               compartments. */

            density = density + 0.5 * (end + start)
                * (end_density - density);
        }


        if (!absolute_scaling)
        {
            if (type == FLOAT)
            {
                fval    = (float *) Gbar;
                (*fval) = Cellreader_data.real_area * density;
            }
            else if (type == DOUBLE)
            {
                dval    = (double *) Gbar;
                (*dval) = Cellreader_data.real_area * density;
            }
            else
            {
                Error();
                printf("readcell: Cellreader_read_channel: "
                       "invalid type field: %d\n", type);
                return 0;
            }
        }
        else
        {
            if (type == FLOAT)
            {
                fval    = (float *) Gbar;
                (*fval) = density;
            }
            else if (type == DOUBLE)
            {
                dval    = (double *) Gbar;
                (*dval) = density;
            }
            else
            {
                Error();
                printf("readcell: Cellreader_read_channel: "
                       "invalid type field: %d\n", type);
                return 0;
            }
        }

        /*
         * Set up messages.
         *
         * Note that Vm and Gk must be a double, while Ek must be a float.
         * This is the convention in genesis anyway (CHAN_TYPE and
         * COMPARTMENT_TYPE macros).
         */

        /* The channel or whatever: */
        current = RecentElement();
        /* The compartment:         */
        parent  = (Element *) Cellreader_data.last_compt;

        slot[0].data = GetFieldAdr(parent, "Vm", &slot_type);
        slot[0].func = DoubleMessageData;

        AddMsg(parent, current, VOLTAGE,  1, slot);


        slot[0].data = GetFieldAdr(current, "Gk", &slot_type);
        slot[0].func = DoubleMessageData;

        slot[1].data = GetFieldAdr(current, "Ek", &slot_type);
        slot[1].func = FloatMessageData;

        AddMsg(current, parent, CHANNEL, 2, slot);


        /* Let the cellreader know how many arguments of argv you've used. */

        Cellreader_data.args_read = 2;

        break;


    case MAKE_COMPT_PROTO:
        /*
         * This is the same as the ADD_MESSAGES_AND_RESCALE case except that
         * (a) we don't multiply the density by the area and (b) we don't
         * handle tapering conductances.  Here we store the density directly
         * in the Gbar field; it'll get rescaled later when the compartment
         * is linked in to the cell.
         */

        if (argc < 2)
        {
            /* Not enough arguments, so return with an error. */

            Error();
            printf("readcell: Cellreader_read_channel: "
                   "need a density argument for %s!\n", pathname);
            return 0;
        }

        density = Atod(argv[1]);

        /*
         * FIXME!  We need some way of indicating that this is absolute
         *         scaling in a prototype.  Here I'm not doing anything
         *         because I haven't decided what to do.  I may use Upi's
         *         convention of negative numbers for absolute scaling or
         *         else add a field for scaling.
         */

        if (!absolute_scaling)
        {
            if (type == FLOAT)
            {
                fval    = (float *) Gbar;
                (*fval) = density;
            }
            else if (type == DOUBLE)
            {
                dval    = (double *) Gbar;
                (*dval) = density;
            }
            else
            {
                Error();
                printf("readcell: Cellreader_read_channel: "
                       "invalid type field: %d\n", type);
                return 0;
            }
        }
        else
        {
            if (type == FLOAT)
            {
                fval    = (float *) Gbar;
                (*fval) = density;
            }
            else if (type == DOUBLE)
            {
                dval    = (double *) Gbar;
                (*dval) = density;
            }
            else
            {
                Error();
                printf("readcell: Cellreader_read_channel: "
                       "invalid type field: %d\n", type);
                return 0;
            }
        }


        /*
         * Set up messages.
         *
         * Note that Vm and Gk must be a double, while Ek must be a float.
         * This is the convention in genesis anyway (CHAN_TYPE and
         * COMPARTMENT_TYPE macros).
         */

        /* The channel or whatever: */
        current = RecentElement();
        /* The compartment: */
        parent  = (Element *)Cellreader_data.last_compt;

        slot[0].data = GetFieldAdr(parent, "Vm", &slot_type);
        slot[0].func = DoubleMessageData;

        AddMsg(parent, current, VOLTAGE,  1, slot);


        slot[0].data = GetFieldAdr(current, "Gk", &slot_type);
        slot[0].func = DoubleMessageData;

        slot[1].data = GetFieldAdr(current, "Ek", &slot_type);
        slot[1].func = FloatMessageData;

        AddMsg(current, parent, CHANNEL, 2, slot);


        /* Let the cellreader know how many arguments of argv you've used. */

        Cellreader_data.args_read = 2;

        break;


    default:

        Error();
        printf("readcell: Cellreader_read_channel: unknown case %d\n",
               READCELL_CASE);
        return 0;
    }

    return 1; /* success */
}



/*
 * Cellreader_compartment_READCELL
 *
 * FUNCTION
 *     This is the READCELL action for an asymmetric compartment.
 *
 * ARGUMENTS
 *     compartment -- address of compartment
 *
 * RETURN VALUE
 *     int  -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_compartment_READCELL(struct compartment_type *compartment)
{
    double   x, y, z, dia, len, area;
    double   parent_x, parent_y, parent_z;
    double   lambda, elength, xsarea;
    char     path[LABEL_LENGTH];
    char     parent_path[LABEL_LENGTH];
    char    *new_argv[6];
    short    no_parent, last_is_parent;
    Element *parent, *current, *child;


    /*
     * Set compartment parameters.
     */

    x    = Cellreader_data.real_x;
    y    = Cellreader_data.real_y;
    z    = Cellreader_data.real_z;
    dia  = Cellreader_data.real_dia;
    len  = Cellreader_data.real_len;
    area = Cellreader_data.real_area;

    if (dia <= 0.0)
    {
        Error();
        printf("compartment: %s: dia must be > 0.0!\n",
               Pathname((Element *) compartment));
        return 0;
    }

    compartment->initVm = Cellreader_data.initVm;
    compartment->Em     = Cellreader_data.Em;
    compartment->dia    = dia;
    compartment->len    = len;

    /*
     * Check whether the compartment is too long given a particular threshold
     * if lambda_warn is on.  This is only meaningful for cylindrical
     * compartments.
     */

    if (Cellreader_data.lambda_warn && (Cellreader_data.shape == CYLINDER))
    {
        lambda  = sqrt(Cellreader_data.RM
                              / Cellreader_data.RA * dia / 4.0);

        if (lambda <= 0.0)
        {
            Error();
            printf("readcell: lambda must be > 0.0!\n");
            return 0;
        }

        elength = len / lambda; /* electrotonic length */

        if (elength > Cellreader_data.lambda_warn_threshold)
        {
            Warning();
            printf("Compartment %s has an electrotonic length of %g,"
                   "\nwhich is over %g lambdas in length!\n",
                   Pathname((Element *) compartment),
                   elength,
                   Cellreader_data.lambda_warn_threshold);
        }
    }

    /*
     * Calculate values for passive parameters.
     */

    if (area <= 0.0)
    {
        Error();
        printf("readcell: area must be > 0.0!\n");
        return 0;
    }

    compartment->Rm = Cellreader_data.RM / area;
    compartment->Cm = Cellreader_data.CM * area;

    if (Cellreader_data.shape == CYLINDER)
    {
        xsarea   = PI * dia * dia / 4.0; /* cross-sectional area */

        if (xsarea <= 0.0)
        {
            Error();
            printf("readcell: xsarea must be > 0.0!\n");
            return 0;
        }

        compartment->Ra = Cellreader_data.RA * len / xsarea;
    }
    else /* SPHERE */
    {
        /* LAMENESS!  BOGOSITY ALERT!
         *
         * This is what the standard cellreader does, but I can't figure
         * out where it comes from.  Yet another reason not to use
         * "spherical" compartments...
         */

        if (dia <= 0.0)
        {
            Error();
            printf("readcell: dia must be > 0.0!\n");
            return 0;
        }

        compartment->Ra = 8.0 * Cellreader_data.RA / (dia * PI);
    }

    /*
     * For efficiency, set some flags which determine what the parent field
     * means.  Cellreader_data.parent contains the name of the parent, or
     * ".", which means "connect to the last defined compartment", or "none"
     * which means that the compartment is at the base of the tree.
     */

    no_parent = last_is_parent = 0;

    if (strcmp(Cellreader_data.parent, "none") == 0)
    {
        no_parent = 1;
    }
    else if (strcmp(Cellreader_data.parent, ".") == 0)
    {
        last_is_parent = 1;
    }

    /*
     * Set position of compartment.  May want to support *absolute
     * option here eventually.
     *
     * Note that, by convention, the root of the cell tree has position
     * (0,0,0).  This is the same as the standard cellreader convention.
     */

    /*
     * First determine what the parent compartment xyz coordinates are.
     */

    if (no_parent)
    {
        parent_x = parent_y = parent_z = 0.0;
    }
    else if (last_is_parent)
    {
        parent_x = Cellreader_data.last_x;
        parent_y = Cellreader_data.last_y;
        parent_z = Cellreader_data.last_z;
    }
    else /* We need to look up the parent's coordinates. */
    {
        char    real_parent_path[LABEL_LENGTH];
        char    parent_root[LABEL_LENGTH];
        char   *numstr, *tempstr;
        double  index_val;
        int     cable_index;

        /*
         * Since the parent could be an interior point of
         * a cable, we have to check for that here.  It will
         * only be such a point if the position along the
         * cable is indexed in parentheses i.e. dend(0.3).
         */

        strcpy(real_parent_path, Cellreader_data.cellpath);
        strcat(real_parent_path, "/");
        strcat(real_parent_path, Cellreader_data.parent);

        if ((strchr(real_parent_path, (int) '(')) != NULL)
        {
            /*
             * There's an open paren here.  Extract the name
             * of the element.
             */

            if (strchr(real_parent_path, (int) ')') == NULL)
            {
                /* Need a closing paren too. */

                Error();
                printf("compartment: READCELL: "
                       "%s is not a valid parent field!\n",
                       real_parent_path);
                return 0;
            }

            /*
             * Extract the index number, which should be in the range [0,1].
             */

            tempstr = strtok(real_parent_path, "(");
            strcpy(parent_root, tempstr);
            numstr = strtok(NULL, ")");
            index_val = Atod(numstr);

            cable_index = Cellreader_GetCableIndex(parent_root, index_val);

            if (cable_index < 0)
            {
                /* Something went wrong. */

                return 0;
            }

            numstr = itoa(cable_index);

            strcpy(real_parent_path, parent_root);
            strcat(real_parent_path, "[");
            strcat(real_parent_path, numstr);
            strcat(real_parent_path, "]");

            FreeString(numstr); /* itoa calls CopyString
                                   which mallocs a string. */
        }
        else /* No open paren. */
        {
            if (strchr(real_parent_path, (int) ')') != NULL)
            {
                /* We can't have a closing paren without an opening one. */

                Error();
                printf("compartment: READCELL: "
                       "%s is not a valid parent field!\n",
                       real_parent_path);
                return 0;
            }
        }

        strcpy(parent_path, real_parent_path);

        if ((parent = GetElement(parent_path)) == NULL)
        {
            Error();
            printf("compartment: READCELL: "
                   "could not find '%s'\n", parent_path);
            return 0;
        }

        parent_x = parent->x;
        parent_y = parent->y;
        parent_z = parent->z;
    }

    /*
     * Then adjust the coordinates relative to the parent coordinates.
     */

    if (no_parent)
    {
        compartment->x = compartment->y = compartment->z = 0.0;
    }
    else if (Cellreader_data.shape == CYLINDER)
    {
        compartment->x = x + parent_x;
        compartment->y = y + parent_y;
        compartment->z = z + parent_z;

        Cellreader_data.last_x = compartment->x;
        Cellreader_data.last_y = compartment->y;
        Cellreader_data.last_z = compartment->z;
    }
    else /* SPHERE */
    {
        /*
         * LAMENESS: this is not the best choice but it'll do for now.
         * Eventually I'd like to have the position extended from the
         * location of the parent (which will have to be cylindrical).
         * The standard cellreader is even lamer in this regard.
         */

        compartment->x = parent_x;
        compartment->y = parent_y;
        compartment->z = parent_z;

        /*
         * Cellreader_data.last_x, last_y, and last_z don't change in this
         * case.
         */

        compartment->len = 0.0;
    }

    /*
     * Set up messages.
     */

    if (last_is_parent)
    {
        /*
         * We don't need slot_type, but it has to be here to make
         * GetFieldAdr happy.
         */

        short slot_type;
        Slot  slot[2];

        current = (Element *)compartment;
        parent  = (Element *)Cellreader_data.last_compt;

        slot[0].data = GetFieldAdr(parent, "previous_state", &slot_type);
        slot[0].func = DoubleMessageData;

        AddMsg(parent, current, AXIAL,  1, slot);


        slot[0].data = GetFieldAdr(current, "Ra", &slot_type);
        slot[0].func = FloatMessageData;

        slot[1].data = GetFieldAdr(current, "previous_state", &slot_type);
        slot[1].func = DoubleMessageData;

        AddMsg(current, parent, RAXIAL, 2, slot);
    }
    else if (!no_parent)
    {
        strcpy(path, Cellreader_data.cellpath);
        strcat(path, "/");
        strcat(path, Cellreader_data.real_name);

        /*
         * We already calculated parent_path above, while looking
         * for coordinates.
         */

        new_argv[0] = "cellreader_do_add_msg";

        new_argv[1] = parent_path;
        new_argv[2] = path;
        new_argv[3] = "AXIAL";
        new_argv[4] = "previous_state";

        do_add_msg(5, new_argv);


        new_argv[1] = path;
        new_argv[2] = parent_path;
        new_argv[3] = "RAXIAL";
        new_argv[4] = "Ra";
        new_argv[5] = "previous_state";

        do_add_msg(6, new_argv);
    }

    /*
     * Set the last_compt and current_comptpath fields of the cellreader.
     */

    Cellreader_data.last_compt = Cellreader_data.new_compt;
    strcpy(Cellreader_data.current_comptpath, Cellreader_data.cellpath);
    strcat(Cellreader_data.current_comptpath, "/");
    strcat(Cellreader_data.current_comptpath, Cellreader_data.real_name);

    /*
     * Rescale the children of the current compartment.  Do this by
     * calling the READCELL actions of each of the children if any.
     * In this case the READCELL action has no arguments, so the
     * children must know how to rescale themselves.  Typically they
     * will do this by putting a density value in their Gbar field
     * when created and then rescaling for the area when the READCELL
     * action is called (for channels, anyway).
     */

    child = compartment->child;

    for (; child; child = child->next)
    {
        /*
         * If there is no READCELL action for the child element,
         * CallReadcellAction will return a value of -1, which is
         * ignored.  That would mean that the child element
         * doesn't need to be rescaled (or else we would have
         * defined a READCELL action for it).
         */

        if (CallReadcellAction(child, 0, NULL, RESCALE_ONLY) == 0)
        {
            /*
             * The READCELL action returned a 0, meaning that
             * something went wrong and we should abort.
             */

            return 0;
        }
    }

    return 1;  /* Success. */
}




/*
 * Cellreader_tabchannel_READCELL
 *
 * FUNCTION
 *     This is the READCELL action for a tabchannel.
 *
 * ARGUMENTS
 *     tabchannel -- address of tabchannel
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_tabchannel_READCELL(struct tab_channel_type *tabchannel)
{
    Action *action;

    action = GetAction("READCELL");

    return (Cellreader_read_channel(action,
                                    &(tabchannel->Gbar),
                                    FLOAT,
                                    Pathname(tabchannel),
                                    0));
}




/*
 * Cellreader_synchan_READCELL
 *
 * FUNCTION
 *     This is the READCELL action for a synchan.
 *
 * ARGUMENTS
 *     channel -- address of synchan
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_synchan_READCELL(struct Synchan_type *channel)
{
    Action *action;

    action = GetAction("READCELL");

    return (Cellreader_read_channel(action,
                                    &(channel->gmax),
                                    FLOAT,
                                    Pathname(channel),
                                    1));
}




/*
 * Cellreader_hebbsynchan_READCELL
 *
 * FUNCTION
 *     This is the READCELL action for a hebbsynchan.
 *
 * ARGUMENTS
 *     channel -- address of hebbsynchan
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_hebbsynchan_READCELL(struct HebbSynchan_type *channel)
{
    Action *action;

    action = GetAction("READCELL");

    return (Cellreader_read_channel(action,
                                    &(channel->gmax),
                                    FLOAT,
                                    Pathname(channel),
                                    1));
}




/*
 * Cellreader_vdep_channel_READCELL
 *
 * FUNCTION
 *     This is the READCELL action for a vdep_channel.
 *
 * ARGUMENTS
 *     channel -- address of channel
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_vdep_channel_READCELL(struct vdep_channel_type *channel)
{
    Action *action;

    action = GetAction("READCELL");

    return (Cellreader_read_channel(action,
                                    &(channel->gbar),
                                    FLOAT,
                                    Pathname(channel),
                                    0));
}




/*
 * Cellreader_generic_spikegen_READCELL
 *
 * FUNCTION
 *     This is the READCELL action for a generic spikegen object.
 *
 * ARGUMENTS
 *     spikegen     -- the address of the spikegen
 *     object_name  -- the name of the object (duh!)
 *     input_msgnum -- the number corresponding to the INPUT message
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_generic_spikegen_READCELL(struct Spikegen_type *spikegen,
                                     char *object_name,
                                     int input_msgnum)
{
    Action  *action;  /* Needed for the READCELL_CASE macro. */
    Element *current, *parent;

    /*
     * We don't need slot_type, but it has to be here to make
     * GetFieldAdr happy.
     */

    short slot_type;
    Slot  slot[2];

    action = GetAction("READCELL");

    /*
     * This allows the spike threshold to be set by
     * the cellreader.
     */

    switch (READCELL_CASE)
    {
    case DITCH_ARGUMENTS:

        /*
         * This corresponds to a case where the READCELL action was
         * called but nothing has to be done but ditch the arguments
         * corresponding to this element.  This is because spikegen is
         * a point process and this position doesn't correspond to where
         * the element should be.
         */

        Cellreader_data.args_read = 2;

        break;


    case RESCALE_ONLY:

        /*
         * This case corresponds to a spikegen which was copied along with
         * its parent compartment by the cellreader.  In this case the
         * messages have already been set up so we're done.
         */

        break;


    case ADD_MESSAGES_AND_RESCALE:
        /*FALLTHROUGH*/

    case MAKE_COMPT_PROTO:
        /*
         * This is the usual case, where the spikegen and the threshold have
         * been set on the command line in the .p file.  The action is the
         * same whether setting up a prototype compartment or adding a
         * spikegen to a compartment in the cell as it's being set up.
         */

        if (action->argc < 2)
        {
            /* Not enough arguments, so return with an error. */

            Error();
            printf("%s: READCELL: need a threshold argument!\n",
                   object_name);
            return 0;
        }

        /*
         * action->argv[1] contains the spike threshold.
         */

        spikegen->thresh = Atod(action->argv[1]);


        /*
         * Set up the INPUT message from the compartment to the spikegen.
         *
         * Note that Vm must be a double.  This is the convention in genesis
         * anyway (COMPARTMENT_TYPE macro).
         */

        /* The spikegen element:    */
        current = RecentElement();
        /* The parent compartment:  */
        parent  = (Element *) Cellreader_data.last_compt;

        slot[0].data = GetFieldAdr(parent, "Vm", &slot_type);
        slot[0].func = DoubleMessageData;

        AddMsg(parent, current, input_msgnum, 1, slot);


        /* Let the cellreader know how many arguments of argv you've used. */

        Cellreader_data.args_read = 2;

        break;

    default:
        Error();
        printf("%s: READCELL: unknown readcell case!\n",
               object_name);
        return 0;
    }

    return 1;  /* success */
}




/*
 * Cellreader_spikegen_READCELL
 *
 * FUNCTION
 *     This is the READCELL action for a standard spikegen object.
 *
 * ARGUMENTS
 *     spikegen -- the address of the spikegen
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_spikegen_READCELL(struct Spikegen_type *spikegen)
{
    return Cellreader_generic_spikegen_READCELL(spikegen,
                                                "spikegen",
                                                spikegen_INPUT);
}




/*
 * Cellreader_Ca_concen_READCELL
 *
 * FUNCTION
 *     This is the READCELL action for a Ca_concen object.
 *
 * ARGUMENTS
 *     concen -- address of Ca_concen.
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Cellreader_Ca_concen_READCELL(struct Ca_concen_type *concen)
{
    double density, volume;

    Action *action = GetAction("READCELL");

    /*
     * FIXME: BOGOSITY ALERT!
     *
     * The "B" density parameter should actually be DIVIDED by the 
     * volume, not multiplied by it.  When you double the volume of
     * a cell and keep the density of calcium buffers constant,
     * you halve the rate at which [Ca] increases in response to a
     * unit calcium current.  You would have to double the current
     * to get the same rate of [Ca] change.  I'm not changing this
     * now because it would break all my simulations.  It doesn't
     * really matter if you just view the B parameter as an absolute
     * value, and the density parameter as just a way to set it.
     * In other words, the B density parameter is bogus, but it's
     * used to set the correct value for the absolute B parameter
     * of the Ca_concen object.
     *
     */


    /*
     * This function allows the Ca_concen B field to be set by
     * the cellreader.
     */

    /*
     * Calculate the volume.  This will be the volume of the entire
     * compartment if thick = 0; otherwise it will be the volume
     * of a shell of size thick.
     */

    if (concen->thick > FTINY)
    {
        volume = Cellreader_calc_shell_volume(concen->thick);
    }
    else /* thick = 0 */
    {
        volume = Cellreader_calc_volume();
    }


    switch (READCELL_CASE)
    {
    case RESCALE_ONLY:

        /*
         * This case corresponds to an element which was copied
         * along with its parent compartment by the cellreader.
         * In this case the messages have already been set up so
         * all we have to do is to scale the B field.  The convention
         * here is that the B field in the element to begin with is
         * the density, so we just have to multiply it by the
         * compartment volume (or shell volume, if thick != 0).
         */

        concen->B *= volume;

        break;


    case ADD_MESSAGES_AND_RESCALE:

        if (action->argc < 2)
        {
            /* Not enough arguments, so return with an error. */

            Error();
            printf("Ca_concen: READCELL: need a density argument!\n");
            return 0;
        }

        /*
         * action->argv[1] contains the "density".  We have to scale
         * it by the volume and set B.  We also have to set up the
         * messages between the compartment and the element.
         */

        /* Scale B by compartment *volume*, not area as in usual case. */

        density = Atod(action->argv[1]);
        concen->B = density * volume;

        /*
         * No messages need to be set up between the compartment and the
         * Ca_concen object.  The messages that *do* need to be set up
         * (described in the addmsgN fields) are handled in the cellreader
         * code.
         */

        /* Let the cellreader know how many arguments of argv you've used. */

        Cellreader_data.args_read = 2;

        break;


    case MAKE_COMPT_PROTO:

        /*
         * This is for setting up a prototype compartment.  It's the
         * same as above except that the B field is just the density
         * value.
         */

        if (action->argc < 2)
        {
            /* Not enough arguments, so return with an error. */

            Error();
            printf("Ca_concen: READCELL: need a density argument!\n");
            return 0;
        }

        concen->B = Atod(action->argv[1]);

        /*
         * No messages need to be set up between the compartment and the
         * Ca_concen object.  The messages that *do* need to be set up
         * (described in the addmsgN fields) are handled in the cellreader
         * code.
         */

        /* Let the cellreader know how many arguments of argv you've used. */

        Cellreader_data.args_read = 2;

        break;


    default:

        Error();
        printf("Ca_concen: READCELL: unknown readcell case!\n");
        return 0;
    }

    return 1; /* success */
}




/*
 * Cellreader_initialize_actions
 *
 * FUNCTION
 *     Adds READCELL actions to standard genesis objects.  I used to
 *     do this in the object code, but this allows me to keep all
 *     cellreader-related stuff in one place and makes it unnecessary
 *     for me to hack the base code.  However, users can (and should)
 *     add READCELL actions to their own object code.
 *
 * ARGUMENTS
 *     none
 *
 * RETURN VALUE
 *     void
 *
 * NOTES
 *     I don't do any error checking since all AddActionToObject checks
 *     for is whether the action exists, and I know it does :-)
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Cellreader_initialize_actions()
{
    AddActionToObject(GetObject("synchan"), "READCELL",
                      Cellreader_synchan_READCELL, NULL);

    AddActionToObject(GetObject("hebbsynchan"), "READCELL",
                      Cellreader_hebbsynchan_READCELL, NULL);

    AddActionToObject(GetObject("spikegen"), "READCELL",
                      Cellreader_spikegen_READCELL, NULL);

    AddActionToObject(GetObject("vdep_channel"), "READCELL",
                      Cellreader_vdep_channel_READCELL, NULL);

    AddActionToObject(GetObject("tabchannel"), "READCELL",
                      Cellreader_tabchannel_READCELL, NULL);

    AddActionToObject(GetObject("compartment"), "READCELL",
                      Cellreader_compartment_READCELL, NULL);

    AddActionToObject(GetObject("Ca_concen"), "READCELL",
                      Cellreader_Ca_concen_READCELL, NULL);
}

