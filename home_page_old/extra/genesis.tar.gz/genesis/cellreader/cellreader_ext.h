/*
 *
 * Copyright (c) 1997 Michael Christopher Vanier
 * All rights reserved.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * In no event shall Michael Vanier or the Genesis Developer's Group
 * be liable to any party for direct, indirect, special, incidental, or
 * consequential damages arising out of the use of this software and its
 * documentation, even if Michael Vanier and the Genesis Developer's
 * Group have been advised of the possibility of such damage.
 *
 * Michael Vanier and the Genesis Developer's Group specifically
 * disclaim any warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose.
 * The software provided hereunder is on an "as is" basis, and Michael
 * Vanier and the Genesis Developer's Group have no obligation to
 * provide maintenance, support, updates, enhancements, or modifications.
 *
 */

/*
 * cellreader_ext.h: includes for the cell reader.
 */

#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "sim_ext.h"
#include "shell_func_ext.h"

#include "cellreader_defs.h"
#include "cellreader_out.h"


/* My functions. */

extern int    Cellreader_do_copy();
extern void   Cellreader_initialize_actions();
extern void   calc_compt_dimensions();
extern void   calc_elength_total();
extern int    do_addfield();
extern void   init_Cellreader_data();
extern int    process_regular_command();
extern void   process_star_command();
extern void   remove_args_from_arglist();
extern void   string_to_arg_list();
extern void   print_arglist(int argc, char **argv);
extern int    Cellreader_is_a_point_process(char *element_path);
extern int
Cellreader_get_absolute_index(const char *s, char *root, int *n, int max);
extern int
Cellreader_get_proportional_index(const char *s, char *root, double *x);


/* flex declarations */

extern FILE *cellreaderin;
extern int   cellreaderlex();

/*
 * Functions from standard genesis.  These should really be in a
 * separate header file, like sys_func_ext.h.
 */

extern int            G_getopt();
extern int            AddMsg();
extern int            AddActionToObject();
extern int            CallActionFunc();
extern int            CheckClass();
extern int            ClassID();
extern int            Error();
extern void           FreeArgv();
extern void           FreeString();
extern GenesisObject *GetObject();
extern int            SetWorkingElement();
extern int            Warning();
extern int            do_add_msg();
extern int            do_copy();
extern void           do_create();
extern int            do_deletefield();
extern int            initopt();
extern Element       *pop_element();
extern int            printoptusage();
extern int            push_element();

