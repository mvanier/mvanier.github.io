/*
 *
 * Copyright (c) 1997 Michael Christopher Vanier
 * All rights reserved.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * In no event shall Michael Vanier or the Genesis Developer's Group
 * be liable to any party for direct, indirect, special, incidental, or
 * consequential damages arising out of the use of this software and its
 * documentation, even if Michael Vanier and the Genesis Developer's
 * Group have been advised of the possibility of such damage.
 *
 * Michael Vanier and the Genesis Developer's Group specifically
 * disclaim any warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose.
 * The software provided hereunder is on an "as is" basis, and Michael
 * Vanier and the Genesis Developer's Group have no obligation to
 * provide maintenance, support, updates, enhancements, or modifications.
 *
 */

/*
 * cellreader_out.h
 *
 * This file is to be #included by anything that needs to use the
 * cellreader.
 */

#define LABEL_LENGTH  100

#include "cellreader_defs.h"
#include "cellreader_struct.h"

#define LENGTH_SCALE 1.0e-6  /* lengths are in microns */

/*
 * The main cell reader data structure, which is global:
 */

extern struct Cellreader_data_type Cellreader_data;

/*
 * Cellreader "cases".  These represent different kinds of
 * setups the READCELL action can be called upon to perform.
 * A different approach would be to have separate actions,
 * i.e. READCELL2, READCELL3.
 */

/*
 * FIXME: add LAMBDA_WARN here eventually.
 */

enum readcell_case
{
    ADD_MESSAGES_AND_RESCALE,
    RESCALE_ONLY,
    DITCH_ARGUMENTS,
    MAKE_COMPT_PROTO,
    READCELL_CASE_END
};


/*
 * Functions used by the rest of genesis.
 * By convention these should always have the
 * "Cellreader_" prefix.
 */

extern int    Cellreader_read_channel();
extern double Cellreader_calc_volume();
extern double Cellreader_calc_shell_volume();
extern int    Cellreader_GetCableIndex();

/*
 * ...except for this one, which is pretty self-explanatory.
 */

extern int CallReadcellAction();


/* shape of compartment: */

#define CYLINDER 0
#define SPHERE   1


/* type of compartment: */

#define ASYMMETRICAL 10
#define SYMMETRICAL  11


/* For assigning message values: */

extern double FloatMessageData();
extern double DoubleMessageData();


/* Other stuff: */

#ifndef FTINY
#define FTINY 1e-8
#endif


#define READCELL_CASE (*((int *)(action->data)))


