/*
 *
 * Copyright (c) 1997 Michael Christopher Vanier
 * All rights reserved.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * In no event shall Michael Vanier or the Genesis Developer's Group
 * be liable to any party for direct, indirect, special, incidental, or
 * consequential damages arising out of the use of this software and its
 * documentation, even if Michael Vanier and the Genesis Developer's
 * Group have been advised of the possibility of such damage.
 *
 * Michael Vanier and the Genesis Developer's Group specifically
 * disclaim any warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose.
 * The software provided hereunder is on an "as is" basis, and Michael
 * Vanier and the Genesis Developer's Group have no obligation to
 * provide maintenance, support, updates, enhancements, or modifications.
 *
 */

/*
 * cellreader.c: cellreader implementation
 *
 * AUTHOR: Mike Vanier
 *
 * The readcell parser (lexer) code is in cellreader.l
 *
 * Numerous utility functions are in cellreader_utils.c
 *
 */

#include "cellreader_ext.h"
#include <ctype.h>


/*
 * Define a global struct so all objects can have access to the cellreader.
 * This could be made nonglobal, but I don't think there's a good reason to
 * do so.
 */

struct Cellreader_data_type Cellreader_data;


/* Forward declarations: */

int process_element(int *argc, char ***argv, int readcell_case);
int process_element_messages(Element *compt);


/*********************************************************/
/*               Main cell reader routines.              */
/*********************************************************/



/*
 * process_star_set_compt_param
 *
 * FUNCTION
 *     This function reads and interprets command lines in .p files
 *     beginning with "*set_compt_param", which set compartment parameters
 *     in Cellreader_data (and later in the compartments).  This command is
 *     more flexible in this cellreader than in the old cellreader in that
 *     it can contain any number of (field, value) pairs after the
 *     *set_compt_param, which makes the .p file a little cleaner (IMHO).
 *
 * ARGUMENTS
 *     int    argc -- argument count on line obtained from cellreader.
 *     char **argv -- argument list passed to cellreader.
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 */

void
process_star_set_compt_param(int argc, char **argv)
{
    int i, j;

    /*
     * We ignore argv[0] since it must be *set_compt_param.
     */

    if (argc < 3)
    {
        Error();
        printf("readcell: *set_compt_param: command usage: \n"
               "\t*set_compt_param <param> <value> [<param> <value>...]\n");
        return;
    }

    for (i = 1, j = 2; j < argc; i += 2, j += 2)
    {
        if (strcmp(argv[i], "Em") == 0)
        {
            Cellreader_data.Em = Atod(argv[j]);
        }
        else if (strcmp(argv[i], "ELEAK") == 0)
        {
            /* For backwards compatibility: */

            Cellreader_data.Em = Atod(argv[j]);
        }
        else if (strcmp(argv[i], "EREST_ACT") == 0)
        {
            /* For backwards compatibility: */

            Cellreader_data.Em     = Atod(argv[j]);
            Cellreader_data.initVm = Cellreader_data.Em;
        }
        else if (strcmp(argv[i], "initVm") == 0)
        {
            Cellreader_data.initVm = Atod(argv[j]);
        }
        else if (strcmp(argv[i], "RM") == 0)
        {
            Cellreader_data.RM = Atod(argv[j]);
        }
        else if (strcmp(argv[i], "CM") == 0)
        {
            Cellreader_data.CM = Atod(argv[j]);
        }
        else if (strcmp(argv[i], "RA") == 0)
        {
            Cellreader_data.RA = Atod(argv[j]);
        }
        else
        {
            Error();
            printf("readcell: unknown compt_param: %s\n", argv[i]);
            return;
        }
    }
}




/*
 * process_star_compt
 *
 * FUNCTION
 *     This function interprets command lines beginning with "*compt",
 *     which sets the path of the currently selected prototype compartment
 *     for the cellreader.  It also checks for the existence of the
 *     prototype in question, and strips out all addmsgN fields from the
 *     prototype's children.
 *
 * ARGUMENTS
 *     int    argc -- argument count on line obtained from cellreader.
 *     char **argv -- argument list passed to cellreader.
 *
 * RETURN VALUE
 *     void
 *
 * NOTE
 *     The process of stripping out the addmsgN fields is here to allow
 *     people to make compartment prototypes with child elements pre-loaded
 *     using element prototypes which may have addmsgN fields in them
 *     (since they may be used elsewhere).  This is necessary to keep
 *     messages from being added twice, and is needed in particular to make
 *     *make_proto work.  However, this may result in a loss of flexibility
 *     in some situations.  For example, if you have a preloaded element
 *     which may have to add a message between itself and another element
 *     which is not preloaded you may want to keep some addmsgN fields (but
 *     not others!).  If this becomes a problem we could have different
 *     types of addmsgN fields, some of which get stripped and others which
 *     don't get stripped.  Hopefully this won't be necessary :-)
 *
 * AUTHOR
 *     Mike Vanier
 */

void
process_star_compt(int argc, char **argv)
{
    Element *prototype, *child;
    int      msgnum;
    char     field[LABEL_LENGTH];
    char     command[COMMAND_LENGTH];
    int      new_argc;
    char   **new_argv;

    if (argc != 2)
    {
        Error();
        printf("readcell: *compt usage: *compt <compartment path>\n");
        return;
    }

    /*
     * FIXME! Is GetElement guaranteed to return NULL if it fails to find
     * the element?
     */

    prototype = GetElement(argv[1]);

    if (prototype == NULL)
    {
        /* Element does not exist. */

        Error();
        printf("readcell: *compt: compartment %s does not exist!\n",
               argv[1]);
        return;
    }
    else
    {
        /*
         * Element does exist.  Go through the children of the element and
         * remove all addmsgN fields.
         */

        child = prototype->child;

        for (; child; child = child->next)
        {
            msgnum = 1;

            for (;;)
            {
                sprintf(field, "addmsg%d", msgnum);

                /* Get addmsgN field if it exists. */

                if (GetExtField(child, field) == NULL)
                {
                    /*
                     * No such field found.  We assume that if addmsg(N)
                     * isn't found then addmsg(N+1) doesn't exist either so
                     * we can break.
                     */

                    break;
                }

                /*
                 * Make the deletefield command, and parse it into an
                 * (argc,argv) pair.  Put a "cellreader_do_deletefield"
                 * string in front to make do_deletefield happy.
                 */

                strcpy(command, "cellreader_do_delete_field ");
                strcat(command, Pathname(child));
                strcat(command, " ");
                strcat(command, field);

                string_to_arg_list(command, &new_argc, &new_argv);

                if (!do_deletefield(new_argc, new_argv))
                {
                    /* Something went wrong. */

                    /*
                     * NOTE: new_argv was malloc'ed in
                     * string_to_arg_list().
                     */

                    FreeArgv(new_argc, new_argv);

                    return;
                }

                FreeArgv(new_argc, new_argv);

                msgnum++;
            }
        }
    }

    strcpy(Cellreader_data.proto_comptpath, argv[1]);
}




/*
 * process_star_make_compt_proto
 *
 * FUNCTION
 *     This function interprets command lines beginning with
 *     "*make_compt_proto".  Its job is to take a compartment or
 *     compartment description and load it into the library as a
 *     prototype.  The syntax is (for instance):
 *
 *     *make_proto compt1 Na 1200 Kdr 360 spike -0.020
 *
 *     which makes a compartment (using the previous default compartment as a
 *     template) and adds the channels etc., giving them the appropriate
 *     parameter values (usually densities).  In this case the densities are
 *     not generally scaled in the child elements since they will be scaled
 *     later.
 *
 * ARGUMENTS
 *     int   argc -- argument count on line obtained from cellreader.
 *     char *argv -- argument list passed to cellreader.
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 */

void
process_star_make_compt_proto(int argc, char **argv)
{
    char     *new_argv[3];
    char      comptpath[LABEL_LENGTH];
    Element  *new_compt;
    int       element_argc;
    char    **element_argv; /* place to store argc/argv for channels etc. */

#ifdef DEBUG
    printf("Cellreader: process_star_make_compt_proto: \n");
    print_arglist(argc, argv);
#endif

    if (argc < 2)
    {
        Error();
        printf("readcell: *make_compt_proto usage: "
               "*make_compt_proto <compartment> "
               "[[prototype density]...]\n");
        return;
    }

    /*
     * This command creates the prototype compartment by copying the
     * default compartment (specified by the *compt command) into the
     * library, copying the child elements into the new compartment,
     * calling their READCELL actions to handle the scaling, and setting up
     * the messages between the prototype and its children.
     */

    strcpy(comptpath, Cellreader_data.proto_comptpath);

    /*
     * Copy the compartment prototype.
     */

    strcpy(comptpath, "/library/");
    strcat(comptpath, argv[1]);

    new_argv[0] = "cellreader_do_copy";
    new_argv[1] = Cellreader_data.proto_comptpath;
    new_argv[2] = comptpath;

#ifdef DEBUG
    printf("Cellreader: process_star_make_compt_proto: 2 \n");
    print_arglist(3, new_argv);
#endif

    if (!Cellreader_do_copy(3, new_argv))
    {
        /* Copy failed, so abort. */

        return;
    }

    /*
     * Get address of copied compartment.  Also set
     * Cellreader_data.current_comptpath, which is used in
     * process_element().
     */

    new_compt = Cellreader_data.new_compt
        = Cellreader_data.last_compt = RecentElement();
    strcpy(Cellreader_data.current_comptpath, comptpath);

    remove_args_from_arglist(2, &argc, &argv);

    /*
     * Go through the list of child elements specified on the line and:
     *
     * a) Copy them from the prototype to the destination;
     *
     * b) Call their READCELL actions with the appropriate arguments.
     *
     * This is all done in process_element.  Also, argc and argv are
     * incremented/decremented from within process_element.
     */

    element_argc = argc;
    element_argv = argv;

    while (element_argc > 0)
    {
        if (!process_element(&element_argc,
                             &element_argv, MAKE_COMPT_PROTO))
        {
            /* There was an error. */
            return;
        }
    }

    /*
     * Set up the messages between child elements.
     */

    if (!process_element_messages(new_compt))
    {
        /* There was an error. */
        return;
    }
}




/*
 * process_star_command
 *
 * FUNCTION
 *     This routine gets called by process_line() in cellreader.l, which is
 *     called (indirectly) by cellreaderlex().  It interprets a line which
 *     begins with an asterisk in a .p file (i.e. a command line).
 *
 * ARGUMENTS
 *     int    argc -- argument count on line obtained from cellreader.
 *     char **argv -- argument list passed to cellreader.
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 */

void
process_star_command(int argc, char **argv)
{
    /*
     * Here we go...
     */

    if (strcmp(argv[0], "*set_compt_param") == 0)
    {
        process_star_set_compt_param(argc, argv);
    }
    else if (strcmp(argv[0], "*compt") == 0)
    {
        process_star_compt(argc, argv);
    }
    else if (strcmp(argv[0], "*make_compt_proto") == 0)
    {
        process_star_make_compt_proto(argc, argv);
    }
    else if (strcmp(argv[0], "*cylindrical") == 0)
    {
        Cellreader_data.shape = CYLINDER;
    }
    else if (strcmp(argv[0], "*spherical") == 0)
    {
        Cellreader_data.shape = SPHERE;
    }
    else if (strcmp(argv[0], "*asymmetric") == 0)
    {
        Cellreader_data.type = ASYMMETRICAL;
    }
    else if (strcmp(argv[0], "*symmetric") == 0)
    {
        Cellreader_data.type = SYMMETRICAL;
    }
    else if (strcmp(argv[0], "*cartesian") == 0)
    {
        /* Do nothing.  This is for backwards-compatibility only. */
    }
    else if (strcmp(argv[0], "*absolute") == 0)
    {
        /* Do nothing.  This is for backwards-compatibility only. */
    }
    else if (strcmp(argv[0], "*relative") == 0)
    {
        /* Do nothing.  This is for backwards-compatibility only. */
    }
    else if (strcmp(argv[0], "*lambda_warn") == 0)
    {
        Cellreader_data.lambda_warn = 1;

        /*
         * If there's another argument, use it to set
         * lambda_warn_threshold.
         */

        if (argc > 1)
        {
            double thresh = Atod(argv[1]);

            Cellreader_data.lambda_warn_threshold = thresh;
        }
    }
    else if (strcmp(argv[0], "*lambda_unwarn") == 0)
    {
        /* Do not warn if lengths are too large. */
        Cellreader_data.lambda_warn = 0;
    }
    else
    {
        Error();
        printf("readcell: command %s not recognized.\n", argv[0]);
        return;
    }
}




/*
 * process_element
 *
 * FUNCTION
 *     This functions handles the channels and other objects that
 *     come in the same line after the compartment dimensions.  It also
 *     decrements argc by 1 for each argument used up.
 *
 * ARGUMENTS
 *     int    argc -- arg count of rest of line obtained from cellreader.
 *     char **argv -- arg list of rest of line obtained from cellreader.
 *     int    readcell_case -- which kind of READCELL action we want to do.
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 */

int
process_element(int *argc, char ***argv, int readcell_case)
{
    char     element_name[LABEL_LENGTH];
    char     element_path[LABEL_LENGTH];
    char    *new_argv[10];
    Element *prototype_element;
    Element *new_element;
    short    point_process = 0;       /* Flag for point processes.      */
    short    point_process_type = 0;  /* 0 = proportional, 1 = absolute */
    double   proportional_index;      /* For point processes only.      */
    int      absolute_index;          /* For point processes only.      */
    int      result;
    char    *root;

#ifdef DEBUG
    printf("Cellreader: process_element: \n");
    print_arglist(*argc, *argv);
#endif

    if ((*argc) <= 0)
        return 0;  /* We need some arguments :-) */

    strcpy(element_name, (*argv)[0]);

    /*
     * The following code makes the cellreader usable with point process
     * syntax e.g. exc_syn(0.4) (for proportional indexing) or exc_syn[10]
     * (for absolute indexing).  This applies to anything in the
     * "point_process" class, plus some other objects like synchans and
     * spikegens.
     */

    /* First look for a proportional index. */

    root   = (char *)calloc(strlen(element_name) + 1, sizeof(char));
    result = Cellreader_get_proportional_index(element_name, root,
                                               &proportional_index);

    if (result < 0)
        return 0;  /* Failure; an error occurred. */

    if (result == 1) /* A valid proportional index was found. */
    {
        point_process = 1;
        point_process_type = 0;
        strcpy(element_path, "/library/");
        strcat(element_path, root);
        free(root);

        if (!Cellreader_is_a_point_process(element_path))
        {
            Error();
            printf("readcell: element %s is not a valid point process!\n",
                   element_path);
            return 0;
        }
    }
    else  /* No proportional index found; look for absolute index. */
    {
        root   = (char *)calloc(strlen(element_name) + 1, sizeof(char));
        result = Cellreader_get_absolute_index(element_name, root,
                                               &absolute_index,
                                               Cellreader_data.nseg);

        if (result < 0)
            return 0;  /* Failure; an error occurred. */

        if (result == 1) /* A valid absolute index was found. */
        {
            point_process = 1;
            point_process_type = 1;
            strcpy(element_path, "/library/");
            strcat(element_path, root);
            free(root);

            if (!Cellreader_is_a_point_process(element_path))
            {
                Error();
                printf("readcell: element %s is not a valid point process!\n",
                       element_path);
                return 0;
            }
        }
        else  /* No absolute index was found either; the usual case. */
        {
            point_process = 0;
            strcpy(element_path, "/library/");
            strcat(element_path, root);
            free(root);
        }
    }


    /*
     * Copy element to compartment.  If point process syntax is being
     * used, copy only if we are in the appropriate range of locations.
     *
     * FIXME! do_copy checks for the existence of the object, but if
     * the element isn't found it just returns.  Maybe I should fix
     * do_copy to return 1 on success or 0 on failure...  Once
     * this is fixed I should abort if the compartment is not found.
     */

    if (point_process)
    {
        /*
         * Check to see if the point process is in the appropriate range.  For
         * each compartment in a "cable", the values
         * Cellreader_data.last_prop_len and Cellreader_data.prop_len bracket
         * the position of the compartment.  If the (proportional) position of
         * the element is in this range then add this element to the cell.  If
         * it's not then ditch the arguments and move on.  The problem is: how
         * do we know how many arguments to ditch?  We solve this by calling
         * the READCELL action of the object with a readcell_case value of
         * DITCH_ARGUMENTS.  This is the signal for the object to return the
         * number of arguments to get rid of.  This is quite inefficient but
         * very flexible.  A more efficient but less flexible solution would
         * be to scan the arglist until you reach something that looks like an
         * element name.  I doubt that the efficiency hit will be that severe
         * anyway.
         *
         * One weirdness is that you have to call the action of an element
         * which hasn't been created yet.  We get around that by calling
         * the READCELL action of the prototype element.  It's ugly but it
         * works :-)
         *
         * Note that if this approach is too inefficient, we could execute
         * the READCELL action only the first time through for the
         * channels, store the args_read in a hash table and then do a hash
         * lookup the rest of the time.  It's unclear to me if this will
         * actually be any faster, though (two function calls or so vs. a
         * hash table lookup).
         *
         * Note also that the *only* purpose of the index value (proportional
         * or absolute) is to determine whether or not to add the element to
         * the current compartment.
         *
         */

        if (point_process_type == 0)  /* Proportional indexing. */
        {
            if ((proportional_index <= Cellreader_data.last_prop_len) ||
                (proportional_index >  Cellreader_data.prop_len))
            {
                /* The element is not located in this compartment. */

                prototype_element = GetElement(element_path);

                if (!CallReadcellAction(prototype_element, 0, NULL,
                                        DITCH_ARGUMENTS))
                {
                    return 0; /* something went wrong */
                }

                remove_args_from_arglist(Cellreader_data.args_read,
                                         argc, argv);

                return 1;
            }
        }
        else  /* Absolute indexing. */
        {
            assert(point_process_type == 1);

            if (absolute_index != Cellreader_data.current_seg)
            {
                /* The element is not located in this compartment. */

                prototype_element = GetElement(element_path);

                if (!CallReadcellAction(prototype_element, 0, NULL,
                                        DITCH_ARGUMENTS))
                {
                    return 0; /* something went wrong */
                }

                remove_args_from_arglist(Cellreader_data.args_read,
                                         argc, argv);

                return 1;
            }
        }

        /* If we got here, we have to add the element to the compartment. */
    }

    new_argv[0] = "cellreader_do_copy";
    new_argv[1] = element_path;
    new_argv[2] = Cellreader_data.current_comptpath;

#ifdef DEBUG
    printf("Cellreader: process_element: 2 \n");
    print_arglist(3, new_argv);
#endif

    if (!Cellreader_do_copy(3, new_argv))
    {
        /* Copy failed, so abort. */

        return 0;
    }

    new_element = RecentElement();


    /*
     * Adjust the position of the newly created element to be the same as
     * that of the last compartment created (which this element is
     * presumably linked to.  This could have been done in the READCELL
     * actions of the individual elements but this prevents needlessly
     * duplicated code ; if you want to override this behavior then you can
     * do so in the READCELL action.
     */

    new_element->x = Cellreader_data.last_x;
    new_element->y = Cellreader_data.last_y;
    new_element->z = Cellreader_data.last_z;


    /*
     * Call the READCELL action of the element.  The action will set
     * Cellreader_data.args_read, which will tell us how many arguments to
     * strip off of argv.  The whole of argv is passed to the object, and
     * it has to know how many to pay attention to.  argc is also passed,
     * so the object knows how many arguments there are in argv.
     *
     * Here readcell_case can be ADD_MESSAGES_AND_RESCALE (usually) or
     * MAKE_COMPT_PROTO (which is the case when making a prototype
     * compartment).
     */

    if (!CallReadcellAction(new_element, *argc, *argv, readcell_case))
        return 0; /* something went wrong */

    remove_args_from_arglist(Cellreader_data.args_read, argc, argv);

    return 1;
}




/*
 * process_element_messages
 *
 * FUNCTION
 *     This function creates the messages between newly-created elements
 *     (not between the elements and the compartment that was just created;
 *     the elements' READCELL actions do that).  The elements are assumed
 *     to exist and to have their fields properly scaled already (the
 *     scaling is also done in the READCELL action).
 *
 * ARGUMENTS
 *     Element *compt -- address of newly-created element.
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 */

int
process_element_messages(Element *compt)
{
    Element *child, *original_working_element;
    char     field[LABEL_LENGTH];
    char     command[COMMAND_LENGTH];
    int      msgnum;
    char    *fieldvalue;
    int      argc;
    char   **argv;

    /*
     * Look for addmsgN fields, where N is an integer equal to 1 or more.
     * If addmsgN is not found, do not look for any more addmsg(N+M)'s; in
     * other words, addmsg fields must be in order.  Use the addmsgN fields
     * to set up messages between newly-created elements.
     */

    /*
     * IMPROVEME!
     *
     *    One way to speed things up is to use AddMsg since:
     *    a) we already know the address of the child element
     *    b) 99% of the time the other element is another child
     *       element so we can do a very quick search for it
     *       given the pathname
     *    c) if this doesn't work we can use do_add_msg
     *
     * NOTE: it turns out that the speed hit for using do_add_msg
     *       is very slight, since the relative path lookup is
     *       pretty fast, so this is probably not worth working on.
     *
     */

    child = compt->child;

    for (; child; child = child->next)
    {
        msgnum = 1;

        for (;;)
        {
            sprintf(field, "addmsg%d", msgnum);

            /* Get addmsgN field if it exists. */

            if ((fieldvalue = GetExtField(child, field)) == NULL)
            {
                /*
                 * No such field found.  We assume that if addmsg(N)
                 * isn't found then addmsg(N+1) doesn't exist either
                 * so we can break.
                 */

                break;
            }

            /*
             * Make the addmsg command and parse it into an (argc,argv)
             * pair.  Put a "cellreader_do_add_msg" string in front to make
             * do_add_msg happy.
             */

            strcpy(command, "cellreader_do_add_msg ");
            strcat(command, fieldvalue);
            string_to_arg_list(command, &argc, &argv);

            /* Make child element the working element. */

            push_element(WorkingElement());
            SetWorkingElement(child);

            /* Add the message. */

            if (!do_add_msg(argc, argv))
            {
                /* NOTE: argv was malloc'ed in string_to_arg_list(). */
                FreeArgv(argc, argv);

                return 0;  /* Something went wrong. */
            }

            /*
             * IMPROVEME!  Should we strip the addmsgN field in the
             * destination object here?  It would take longer but save
             * space...
             */

            /* Restore original working element. */

            if ((original_working_element = pop_element()) != NULL)
                SetWorkingElement(original_working_element);

            FreeArgv(argc, argv);
            msgnum++;
        }
    }

    return 1;
}




/*
 * process_regular_command
 *
 * FUNCTION
 *     This routine gets called by process_line() in cellreader.l, which is
 *     called (indirectly) by cellreaderlex().  It interprets a line which
 *     *doesn't* begin with an asterisk in a .p file (i.e. a line
 *     specifying a compartment or cable plus the associated elements).
 *
 * ARGUMENTS
 *     int    argc -- argument count on line obtained from cellreader.
 *     char **argv -- argument list passed to cellreader.
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 */

int
process_regular_command(int argc, char **argv)
{
    /*
     * Create a compartment/cable, store the positional arguments in
     * the Cellreader_data struct and call the READCELL actions of the
     * compartment(s).
     *
     * The first few arguments are:
     * <name> <parent> <x> <y> <z> <dia> [<end-dia>] (lengths in microns).
     *
     * where <end-dia> is only used for tapered cables.
     *
     * NOTE: Each compartment MUST calculate the area, set the last_[xyz]
     *       parameters, and set last_compt so that the elements connected
     *       to the compartment know how to set their position fields,
     *       scale their densities, and add their messages.
     */

    int       i, nseg;
    char     *new_argv[10]; /* argv for genesis system calls. */
    char     *temp;
    int       element_argc;
    char    **element_argv; /* place to store argc/argv for channels etc. */
    char      destname[LABEL_LENGTH];
    Element  *new_compt;
    char     *numstr;


#ifdef DEBUG
    printf("Cellreader: process_regular_command: \n");
    print_arglist(argc, argv);
#endif

    if (argc < 6)
    {
        Error();
        printf("readcell: compartment line must be in the form:\n"
               "\t<name> <parent> <x> <y> <z> {<dia> or "
               "<start-dia>:<end-dia>} (lengths in microns)\n");
        return 0;
    }

    /*
     * Initialize some fields.
     */

    Cellreader_data.cum_len  = 0.0;
    Cellreader_data.prop_len = 0.0;

    /*
     * Parse the line.
     */

    strcpy(Cellreader_data.name,   argv[0]);
    strcpy(Cellreader_data.parent, argv[1]);

    Cellreader_data.x   = Atod(argv[2]) * LENGTH_SCALE;
    Cellreader_data.y   = Atod(argv[3]) * LENGTH_SCALE;
    Cellreader_data.z   = Atod(argv[4]) * LENGTH_SCALE;

    remove_args_from_arglist(5, &argc, &argv);

    /*
     * Get dia (and end-dia if it's there).  end_dia is separated from dia
     * by a colon and NO INTERVENING SPACES.  Set the is_tapered flag
     * of Cellreader_data to indicate whether or not the cable is tapered.
     */

    Cellreader_data.dia = Atod(strtok(argv[0], ":")) * LENGTH_SCALE;

    temp = strtok(NULL, ":");  /* Look for another number. */

    if (temp != NULL)  /* Found another number. */
    {
        Cellreader_data.end_dia  = Atod(temp) * LENGTH_SCALE;
        Cellreader_data.is_tapered = 1;
    }
    else
    {
        /*
         * There is no other number, so the compartment/cable
         * isn't tapered.
         */

        Cellreader_data.is_tapered = 0;
    }

    remove_args_from_arglist(1, &argc, &argv);

    /* Check for nseg argument. */

    nseg = Cellreader_data.nseg = 1;   /* Default value. */

    if (argc > 1) /* We need at least two arguments for nseg. */
    {
        /*
         * Is there an nseg argument?
         */

        if (strcmp(argv[0], "nseg") == 0)
        {
            nseg = Cellreader_data.nseg = atoi(argv[1]);
            remove_args_from_arglist(2, &argc, &argv);
        }
    }

    /*
     * Compute the total length.
     */

    if (Cellreader_data.shape == CYLINDER)
    {
        double x = Cellreader_data.x;
        double y = Cellreader_data.y;
        double z = Cellreader_data.z;

        Cellreader_data.len = sqrt(x * x  +  y * y  +  z * z);

        if (Cellreader_data.is_tapered)
        {
            /*
             * Compute total electrotonic length and length per segment.
             * We assume here that RM, RA, CM, dia, end_dia and len are
             * loaded up.
             */

            calc_elength_total();
            Cellreader_data.elength_per_seg
                = Cellreader_data.elength_total / ((double) nseg);
        }
    }
    else /* SPHERE */
    {
        Cellreader_data.len = 0.0;
    }

    /*
     * IMPROVEME!  Once we have the *set_elength_max option we will have to
     *             figure out nseg from the total length, dia, RA, and RM.
     *             This may be tricky for tapered cables...
     */

    /*
     * At this point we know how many segments we need.  argc/argv contains
     * the remaining arguments on the line, which are usually channel
     * specifications.  We save argc/argv to element_argc/element_argv
     * since we need to use it over and over for each element on the line.
     */

    if ((nseg > 1) && (Cellreader_data.type == SPHERE))
    {
        Error();
        printf("readcell: spherical compartments cannot have an nseg > 1!");
        return 0;
    }

    for (i = 0; i < nseg; i++)
    {
        /*
         * Copy the prototype compartment(s) to its (their) destination(s).
         */

        strcpy(destname, Cellreader_data.cellpath);
        strcat(destname, "/");
        strcat(destname, Cellreader_data.name);

        /*
         * We have to add an array index if i > 0.  Note that real_name is
         * the same as name except it also has the array index and the
         * square brackets if the compartment is part of a cable.  It's the
         * "real name" of the compartment :-)  Therefore, "name" is really
         * the root name for cables, not the compartment name.  If we're
         * dealing with just regular compartments, this is wasteful.
         */

        strcpy(Cellreader_data.real_name, Cellreader_data.name);

        if (i > 0)
        {
            numstr = itoa(i);

            strcat(destname, "[");
            strcat(destname, numstr);
            strcat(destname, "]");

            /* NOTE: itoa() calls CopyString which mallocs a string. */
            FreeString(numstr);

            strcat(Cellreader_data.real_name, "[");
            strcat(Cellreader_data.real_name, numstr);
            strcat(Cellreader_data.real_name, "]");
        }

        new_argv[0] = "cellreader_do_copy";
        new_argv[1] = Cellreader_data.proto_comptpath;
        new_argv[2] = destname;

#ifdef DEBUG
    printf("Cellreader: process_regular_command: 2 \n");
    print_arglist(3, new_argv);
#endif

        if (!Cellreader_do_copy(3, new_argv))
        {
            /* Copy failed, so abort. */
            return 0;
        }

        /* Get address of copied compartment. */

        new_compt = Cellreader_data.new_compt = RecentElement();

        /*
         * For the first compartment in a cable, add a field or fields
         * which will enable other compartments to hook up to arbitrary
         * points in the cable.  If the cable is untapered this is just one
         * field to hold the nseg value; if it's taperd you also need
         * fields for the total length, beginning diameter and end
         * diameter.
         *
         * Also, do not add the field(s) if nseg == 1.  This will be
         * faster, and the compartment lookup code will automatically
         * return the correct compartment if there is no nseg field.
         */

        if ((nseg > 1) && (i == 0))
        {
            if (Cellreader_data.is_tapered)
            {
                Warning();
                printf("readcell: process_regular_line: "
                       "We don't yet support tapered cables fully.\n");
            }

            numstr = itoa(nseg);

            new_argv[0] = "cellreader_do_addfield";
            new_argv[1] = destname;
            new_argv[2] = "nseg";

            do_addfield(3, new_argv);

            SetExtField((Element *) new_compt, "nseg", numstr);

            /* NOTE: itoa() calls CopyString which mallocs a string. */
            FreeString(numstr);
        }

        /*
         * Calculate the real_[xyz] etc. data fields for the compartment.
         */

        calc_compt_dimensions(i);

        /*
         * Call the compartment's READCELL action.  If i == 1 change the
         * parent field to "." since you're hooking the compartment up to
         * the previously copied compartment.  This isn't necessary with
         * the rest of the cable since nothing will disturb this field
         * until the next line is read in to the cellreader.
         */

        if (i == 1)
            strcpy(Cellreader_data.parent, ".");

        /*
         * The `readcell_case' value (the last argument in
         * CallReadcellAction()) is irrelevant here, since the compartment
         * object doesn't care about the case.
         */

        if (CallReadcellAction(new_compt, 0, NULL,
                               ADD_MESSAGES_AND_RESCALE) == 0)
        {
            return 0; /* something went wrong */
        }

        /*
         * Go through the list of child elements specified on the line and:
         *
         * a) Copy them from the prototype to the destination;
         *
         * b) Call their READCELL actions with the appropriate arguments.
         *
         * This is all done in process_element.  Also, argc and argv are
         * incremented/decremented from within process_element.  We also
         * specify that we want to set up messages and rescale the child
         * element's parameter(s) based on the density argument(s).
         */

        element_argc = argc;
        element_argv = argv;

        while (element_argc > 0)
        {
            if (!process_element(&element_argc, &element_argv,
                                 ADD_MESSAGES_AND_RESCALE))
            {
                /* There was an error. */
                return 0;
            }
        }

        /*
         * Set up the messages between child elements.
         */

        if (!process_element_messages(new_compt))
        {
            /* There was an error. */
            return 0;
        }
    }

    return 1;
}




/*
 * do_readcell
 *
 * FUNCTION
 *     Reads in and processes a .p file and sets up the cell(s) and
 *     elements specified in that file.
 *
 * ARGUMENTS
 *     int    argc -- argument count from genesis interpreter
 *     char **argv -- argument list from genesis interpreter
 *
 * RETURN VALUE
 *     int -- 0 = failure; 1 = success
 *
 * NOTES
 *     The function Cellreader_initialize_actions (or the
 *     script function initcellreader) must be called
 *     before using this function.  initcellreader should
 *     be placed in the .simrc file.
 *
 * AUTHOR
 *     Mike Vanier
 */

int
do_readcell(int argc, char **argv)
{
    char *new_argv[3]; /* argv for genesis system calls */

    initopt(argc, argv, "filename cell-name");

    if (G_getopt(argc, argv) != 0)
    {
        printoptusage(argc, argv);
        return 0;
    }

    if (!(cellreaderin = fopen(optargv[1], "r")))
    {
        Error();
        printf("readcell: can't open file: '%s'\n", optargv[1]);
        return 0;
    }

    init_Cellreader_data();

    /*
     * The second argument is the path name of the cell.
     */

    strcpy(Cellreader_data.cellpath, optargv[2]);

    /* Create a neutral element with the same name as the cell. */

    new_argv[0] = "cellreader_do_create";
    new_argv[1] = "neutral";
    new_argv[2] = optargv[2];
    do_create(3, new_argv);

    /*
     * Read in the contents of the .p file and interpret it line-by-line.
     * See cellreader.l for more details.
     */

    /*
     * FIXME!!!!!! Need to set things up so that a *single* error
     * will exit the cellreader lexer!  This is VERY ANNOYING!!!!!
     */

    cellreaderlex();

    fclose(cellreaderin);

    return 1;
}
