/*
** $Id: newconn_ext.h,v 2.1.1.1 1999/03/17 07:53:41 mhucka Exp $
** $Log: newconn_ext.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:41  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.3  1996/07/22 23:52:54  dhb
** Changes from Mike Vanier:
**   Generic handling of synchan types
**
 * Revision 1.2  1995/03/28  20:41:20  mvanier
 * Added extern declarations for GetSynapseType and GetSynapseAddress
 *
 * Revision 1.1  1995/01/11  23:09:02  dhb
 * Initial revision
 *
*/

#include "sim_ext.h"
#include "newconn_defs.h"
#include "newconn_struct.h"
#include "synaptic_event.h"
#include "seg_struct.h"  /* for compartment definition */

extern float    rangauss();
extern void     randomize_value();
extern Synapse *GetSynapseAddress();



