/*
** $Id: hh_struct.h,v 2.1.1.1 1999/03/17 07:53:39 mhucka Exp $
** $Log: hh_struct.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:39  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:03:03  dhb
** Initial revision
**
*/

#include "struct_defs.h"

struct vdep_gate_type {
    SEGMENT_TYPE
    double	m;
    float   	alpha_A;
    float   	alpha_B;
    float   	alpha_C;
    float   	alpha_D;
    float   	alpha_F;
    float   	beta_A;
    float   	beta_B;
    float   	beta_C;
    float   	beta_D;
    float   	beta_F;
    short	instantaneous;
};

struct vdep_channel_type {
    CHAN_TYPE
	/*
    double	Gk;
    float	Ik; Note that this is changed to a double and repositioned
    float	Ek;
	*/
    float	gbar;
};

struct hh_channel_type {
    CHAN_TYPE
	/*
    double 	Gk;
    float 	Ik; Note that this is changed to a double and repositioned
    float 	Ek;
	*/
    float   	Gbar;
    double	X;
    double 	Y;
    float   	Xpower;
    float	Ypower;
    short   	X_alpha_FORM;
    float   	X_alpha_A;
    float   	X_alpha_B;
    float   	X_alpha_V0;
    short   	X_beta_FORM;
    float   	X_beta_A;
    float   	X_beta_B;
    float   	X_beta_V0;
    short   	Y_alpha_FORM;
    float   	Y_alpha_A;
    float   	Y_alpha_B;
    float   	Y_alpha_V0;
    short   	Y_beta_FORM;
    float   	Y_beta_A;
    float   	Y_beta_B;
    float   	Y_beta_V0;
};

