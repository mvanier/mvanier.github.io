static char rcsid[] = "$Id: sigmoid.c,v 2.1.1.1 1999/03/17 07:53:34 mhucka Exp $";

/*
** $Log: sigmoid.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:34  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/10/28 22:29:39  dhb
** Initial revision
**
*/

#include "buf_ext.h"

int	DEBUG_SigmoidEvent = 0;

/* 
** SigmoidEvent intended for unit types
*/
/* M.Wilson Caltech 6/88 */
SigmoidEvent(sigmoid,action)
register struct sigmoid_type 	*sigmoid;
Action				*action;
{
MsgIn	*msg;

    if(Debug(DEBUG_SigmoidEvent) > 1){
	ActionHeader("SigmoidEvent",sigmoid,action);
    }
    SELECT_ACTION(action){
    case PROCESS:
	MSGLOOP(sigmoid,msg){
	case 0:				/* input */
	    sigmoid->input = MSGVALUE(msg,0);
	    break;
	case 1:				/* threshold */
	    sigmoid->thresh = MSGVALUE(msg,0);
	    break;
	case 2:				/* gain */
	    sigmoid->gain = MSGVALUE(msg,0);
	    break;
	case 3:				/* peak amplitude */
	    sigmoid->amplitude = MSGVALUE(msg,0);
	    break;
	}
	/*
	** the buffer state is the value of the sigmoid
	*/
	sigmoid->state = sigmoid->amplitude* 
	(tanh(sigmoid->gain*(sigmoid->input - sigmoid->thresh)) + 1)/2.0;
	PutEvent(sigmoid, sigmoid->state, NULL, WRAP);
	break;
    case RESET:
	ClearBuffer(sigmoid);
	break;
    default:
	InvalidAction("SigmoidEvent",sigmoid,action);
	break;
    }
}
