static char rcsid[] = "$Id: randombuf.c,v 2.1.1.1 1999/03/17 07:53:34 mhucka Exp $";

/*
** $Log: randombuf.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:34  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/10/28 22:29:38  dhb
** Initial revision
**
*/

#include "buf_ext.h"

int	DEBUG_RandomEvent = 0;

#define TIME_RV		0x01
#define AMP_RV		0x02
#define AMP_RESET	0x04

/* 
** RandomEvent
** 
** place a random event into the buffer
*/

#define Field(F)	(buffer->F)

/* 9/88 Matt Wilson */
RandomEvent(buffer,action)
register struct random_type 	*buffer;
Action 			*action;
{
MsgIn	*msg;
float	p;

    if(Debug(DEBUG_RandomEvent) > 1){
	ActionHeader("RandomEvent",buffer,action);
    }
    switch(action->type){
    case INIT:
	if(buffer->reset){
	    buffer->state = buffer->reset_value;
	}
	break;
    case RESET:
	ClearBuffer(buffer);
	buffer->state = buffer->reset_value;
	break;
    case PROCESS:
	MSGLOOP(buffer,msg){
	    case 0:	/* RATE */
		buffer->rate = MSGVALUE(msg,0);
		break;
	    case 1:	/* MIN/MAX*/
		buffer->min_amp = MSGVALUE(msg,0);
		buffer->max_amp = MSGVALUE(msg,1);
		break;
	}
	/*
	** add an event to the potential buffer
	*/
	p = buffer->rate*Clockrate(buffer);
	if( (p >= 1) || (p >= urandom())){
	    if(buffer->min_amp != buffer->max_amp){
		buffer->state = frandom(Field(min_amp),Field(max_amp));
	    } else {
		buffer->state = buffer->min_amp;
	    }
	    PutEvent(buffer, buffer->state, NULL, WRAP);
	}
	break;
    default:
	InvalidAction("RandomEvent",buffer,action);
	break;
    }
}
#undef Field
