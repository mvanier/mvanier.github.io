static char rcsid[] = "$Id: linear.c,v 2.1.1.1 1999/03/17 07:53:33 mhucka Exp $";

/*
** $Log: linear.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:33  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.3  1993/01/21 20:31:35  dhb
** Syntax error
**
 * Revision 1.2  1992/10/28  22:35:08  dhb
 * Updated to use MSGLOOP
 *
 * Revision 1.1  1992/10/28  22:29:35  dhb
 * Initial revision
 *
*/

#include "buf_ext.h"

int	DEBUG_LinearEvent = 0;

/* 
** LinearEvent intended for unit types
*/
/* 6/88 Matt Wilson */
LinearEvent(buffer,action)
register struct linear_type	*buffer;
Action 	*action;
{
MsgIn	*msg;
double 	fval;
double 	state;
double 	thresh;
int	stat;

    if(Debug(DEBUG_LinearEvent) > 1){
	ActionHeader("LinearEvent",buffer,action);
    }
    switch(action->type){
    case PROCESS:
	thresh = buffer->thresh;
	/*
	** read the msgs
	*/
	MSGLOOP(buffer, msg) {
	    /*
	    ** type 0 : x value used to calculate y=G*(x - thresh)
	    */
	    case 0:
		buffer->state = MsgValue(msg,double,0);
		break;
	    /*
	    ** type 1 : x-intercept threshold
	    */
	    case 1:
		thresh = MsgValue(msg,double,0);
		break;
	}
	/*
	** add an event to the potential buffer
	*/
	fval = buffer->gain* (buffer->state - thresh);

	PutEvent(buffer, fval, NULL, WRAP);
	break;
    case RESET:
	ClearBuffer(buffer);
	break;
    case CHECK:
	stat = 0;
	MSGLOOP(buffer, msg) {
	    case 0:
		stat = 1;
		break;
	}
	if(!stat){
	    ErrorMessage("LinearEvent","No input state",buffer);
	}
	break;
    }
}

