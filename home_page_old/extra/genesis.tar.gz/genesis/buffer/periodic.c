static char rcsid[] = "$Id: periodic.c,v 2.1.1.1 1999/03/17 07:53:34 mhucka Exp $";

/*
** $Log: periodic.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:34  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/10/28 22:29:36  dhb
** Initial revision
**
*/

#include "buf_ext.h"

int	DEBUG_PeriodicEvent = 0;

/*
** update a pre-filled buffer with periodic wraparound
*/
/* 9/88 Matt Wilson */
PeriodicEvent (periodic,action)
register struct periodic_type 	*periodic;
Action		*action;
{
int current;
float event_time;

    if(Debug(DEBUG_PeriodicEvent) > 1){
	ActionHeader("PeriodicEvent",periodic,action);
    }
    switch(action->type){
    case PROCESS:
	/*
	** update the buffer pointer to bring it up to date with the
	** current simulation time
	*/
	if(periodic->current != periodic->end && 
	periodic->current == periodic->start){
	    periodic->current = (periodic->current +1)%periodic->size;
	}
	/*
	** this can only occur if the buffer is empty
	*/
	if(periodic->current == periodic->start) return;
	/*
	** get the relative time of the current event, 
	** apply the expansion factor
	** and add the time of the beginning of the cycle
	*/
	event_time = periodic->scale*CurrentEvent(periodic).time 
	+ periodic->stime;

	/*
	** increment the pointers until reaching a time which
	** has not yet been reached
	*/
	while(SimulationTime() >= event_time - CORRECTION){ 
	    if((event_time >= SimulationTime() - Clockrate(periodic)/2) &&
	    (event_time <= SimulationTime() + Clockrate(periodic)/2)){
		periodic->state = CurrentEvent(periodic).magnitude;
	    } else {
		if(periodic->mode == 1){
		    /*
		    ** impulse mode
		    */
		    periodic->state = 0;
		}
	    }
	    if (periodic->current != periodic->end){ 
		periodic->current = (periodic->current + 1) % periodic->size;
	    } else {
		/*
		** if this is the end of the cycle then reset the new 
		** cycle indicators
		*/
		periodic->current = (periodic->start + 1) % periodic->size;
		periodic->stime = SimulationTime();
	    }
	    event_time = periodic->scale*CurrentEvent(periodic).time 
	    + periodic->stime;
	}
	break;
    case RESET:
	ResetBuffer(periodic);
	periodic->state = 0;
	periodic->stime = 0;
	break;
    default:
	InvalidAction("PeriodicEvent",periodic,action);
	break;
    }
}
