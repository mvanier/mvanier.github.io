/*
** $Id: buf_defs.h,v 2.1.1.1 1999/03/17 07:53:33 mhucka Exp $
** $Log: buf_defs.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:33  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.1  1992/12/11 19:02:34  dhb
** Initial revision
**
*/

#define		E_SPIKE				80

