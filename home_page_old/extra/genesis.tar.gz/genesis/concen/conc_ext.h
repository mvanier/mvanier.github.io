/*
** $Id: conc_ext.h,v 2.1.1.1 1999/03/17 07:53:34 mhucka Exp $
** $Log: conc_ext.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:34  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.2  1997/05/28 21:02:16  dhb
** Added include for conc_defs.h
**
** Revision 1.1  1992/12/11 19:02:43  dhb
** Initial revision
**
*/

/* Version EDS20i 95/06/02 */

#include "sim_ext.h"
#include "conc_defs.h"
#include "conc_struct.h"
