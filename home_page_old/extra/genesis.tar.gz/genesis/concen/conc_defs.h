/*
** $Id: conc_defs.h,v 2.1.1.1 1999/03/17 07:53:34 mhucka Exp $
**
** $Log: conc_defs.h,v $
** Revision 2.1.1.1  1999/03/17 07:53:34  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.2  1997/05/28 21:07:29  dhb
** Added RCS id and log headers
**
*/

/* Version EDS21c 96/10/10, Erik De Schutter, BBF-UIA 8/94-10/96 */

#define FARADAY 9.6487e4            /* C / mol */
#define UTINY 1.0e-30

/* shape_mode types */
#define SHELL 0
#define SLAB 1
#define USERDEF 3

/* msg types */
#define INFLUX 0
#define OUTFLUX 1
#define FINFLUX 2
#define FOUTFLUX 3
#define STOREINFLUX 4
#define STOREOUTFLUX 5
#define DIFF_DOWN 6
#define DIFF_UP 7
#define BUFFER 10
#define TAUPUMP 11
#define EQTAUPUMP 12
#define MMPUMP 13
#define CONCEN 0
#define BDIFF_DOWN 1
#define BDIFF_UP 2
#define MMKD 1


