static char rcsid[] = "$Id: mmpump.c,v 2.1.1.1 1999/03/17 07:53:34 mhucka Exp $";

/*
** $Log: mmpump.c,v $
** Revision 2.1.1.1  1999/03/17 07:53:34  mhucka
** Import of GENESIS 2.1 release from CD-ROM
**
** Revision 1.2  1997/05/28 21:23:50  dhb
** Added RCS id and log headers
**
*/

/* Version EDS21d 97/03/18, Erik De Schutter, BBF-UIA 9/94-3/97 */
/* Implementation of a simple pump with Michaelis Menten kinetics. 
** Should be coupled to a difshell, where the changes in concentration 
**  is computed.  Note that this object does not compute anything by
**  itself, if the electrogenic action is simulated.  By making it a 
**  separate object, multiple pumps are possible */

#include "conc_ext.h"

MMPump(pump,action)
register Mpump *pump;
Action		*action;
{
double	concen;
int	n;
MsgIn 	*msg;

    if(debug > 1){
		ActionHeader("mmpump",pump,action);
    }

    SELECT_ACTION(action){
    case INIT:
		break;
    case PROCESS: 
	
	/* Read the msgs  */
	MSGLOOP(pump,msg){
		case CONCEN:	/* concentration, compute electrogenic effect */
			concen = MSGVALUE(msg,0);
			break;
		case MMKD:	/* Kd */
			pump->Kd = MSGVALUE(msg,0);
			break;
	}

	if (pump->val) {
	    pump->Ik=pump->mmconst * concen / (pump->Kd + concen);
	}
	break;

    case RESET:
	if (pump->val) {
	    n=0;
	    /* Read the msgs  */
	    MSGLOOP(pump,msg){
		case CONCEN:	/* concentration, compute electrogenic effect */
			concen = MSGVALUE(msg,0);
			n++;
			break;
		case MMKD:	/* Kd */
			pump->Kd = MSGVALUE(msg,0);
			break;
	    }
	    pump->mmconst=pump->vmax * pump->val * FARADAY;
	    pump->Ik=pump->mmconst * concen / (pump->Kd + concen);
	}
	break;

    case CHECK:
	if(pump->vmax <= 0.0)
		ErrorMessage("mmpump", "Invalid vmax.", pump);
	if(pump->Kd <= 0.0)
		ErrorMessage("mmpump", "Invalid Kd.", pump);
	if (pump->val) {
	    n=0;
	    /* Read the msgs  */
	    MSGLOOP(pump,msg){
		case CONCEN:	/* concentration, compute electrogenic effect */
			n++;
			break;
	    }
	    if(!n)
		ErrorMessage("mmpump", "CONCEN msg needed to compute electrogenic effect.", pump);
	}
	break;
    }
}

