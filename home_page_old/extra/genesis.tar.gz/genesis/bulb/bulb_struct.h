/*
 *
 * FILE: bulb_struct.h
 *
 *      Struct definitions for the bulb library.
 *
 *
 * AUTHOR: Mike Vanier
 *
 */

#ifndef BULB_STRUCT_H
#define BULB_STRUCT_H

#include "struct_defs.h"
#include "array_utils.h"

/*
 * The `spikeprob_type' struct.
 *
 *     This type encapsulates all the data needed to hold ISI
 *     histograms, ISI distributions, and anything else needed
 *     to calculate spike probabilities based on ISI distributions.
 *     Note that the first entry in the ISI distribution (isid[0])
 *     represents the probability that the ISI will be between 0 and
 *     dx, and so forth.
 */

struct spikeprob_type
{
    char    *filename;   /* Name of ISI histogram file.                */
    int      nbins;      /* Number of bins in ISI histogram.           */
    double   dx;         /* Size of x steps in ISI histogram.          */
    double   xmax;       /* Maximum x value for ISI histogram.         */
    double  *isih;       /* ISI histogram.                             */
    double  *isid;       /* ISI probability density.                   */
    double  *ncisid;     /* 1.0 - cumulative ISI distribution.         */
    int      nscalef;    /* Scale factor for # of points in isid.      */
    double   ratescale;  /* Static scaling factor for spiking rate.    */
};



/*
 * The `Mitral' struct.
 *
 *     This type encapsulates almost all the state variables that are
 *     specific to a particular olfactory bulb mitral cell spike generator.
 *     The exception is the response of a given cell to a given odor,
 *     which is kept in the odor_info struct.
 */

struct Mitral
{
    short   spiking;         /* Flag: am I spiking this time step?         */
    double  last_spike_time; /* Time of last spike.                        */
    Msg*    msgout;          /* Output message; only one allowed per cell. */
};



/*
 * The `ob_output_data' struct.
 *
 *     This struct packages all the output-related data of the
 *     olfactory_bulb object.
 *
 */

struct ob_output_data
{
    short      enabled;    /* Flag: whether to record cell output.   */
    short      flush;      /* Flag: whether to flush every write.    */
    char      *filename;   /* File name to record into.              */
    FILE      *file;       /* File to record into.                   */
};



/*
 * The `rate_coding_data' struct.
 *
 *     This struct packages data relating to the rate coding implementation.
 *     There can an arbitrary number of possible types of responses to odors.
 *     These responses are in the form of modulations of the baseline firing
 *     rate as a function of time after the odor.  They are loaded in from a
 *     file.  Linear interpolation is used to get the appropriate modulation
 *     values for a given time step.
 *
 *     NOTE: The fact that all responses have a common time duration does not
 *     limit flexibility, for two reasons: 1) the end of some responses can
 *     be just a series of 1.0's (i.e. back to background response), and 2)
 *     the odor may go off before the response is over.  Thus, `tresp' is
 *     actually the maximum duration of the odor responses.
 *
 *     NOTE: resp means "response to an odor", NOT "respiration".
 *
 */

struct rate_coding_data
{
    char    *filename;    /* Name of file with rate coding information. */
    int      nresp;       /* Number of distinct odor responses.         */
    int      nrespt;      /* Number of time points in odor responses.   */
    double   tresp;       /* Time duration of odor responses.           */
    double   dt;          /* Time base of resp array.                   */
    int      curr_index;  /* Current time index.                        */
    double **resp;        /* 2-D array of responses(type, time).        */
};




/*
 * The `sync_coding_data' struct.
 *
 *     This struct implements an array of spike generators that synchronize
 *     their outputs to spike events from a set of hypothetical reference
 *     cells.  Spike event sequences "from" the reference cell are either
 *     read in from a file or generated randomly.  A separate file is read
 *     in to determine how each cell responds to each odor (i.e. with which
 *     reference cell spike event sequence or with the background spiking
 *     response).  After each spike event, each active cell (i.e. those not
 *     exhibiting the background spiking response) probabilistically
 *     chooses if it will respond to the event.  If so, it uses a Poisson
 *     spiking probability (i.e. a fixed probability per time step) to
 *     choose whether or not it spikes at any given time step.  Once it
 *     spikes, it does not spike again until the next reference cell spike
 *     event occurs.  If it does not respond to the spike event it will
 *     spike in accordance with the background spiking pattern.  The
 *     reference cell spike event sequences last a certain time and then
 *     stop; they can't go beyond the duration of the odor but may end
 *     sooner.  If they do end before the odor goes off, the
 *     previously-synchronized cells then spike in accordance with the
 *     background spiking pattern.
 *
 * Note on sync_modes:
 * ------------------
 *
 *     In sync_mode 0:
 *         Each cell can respond to a given odor with a given sequence of
 *         events.  The particular event sequences are read in from a file.
 *         Another file is read in containing the responses of each cell
 *         to each odor.  The responses have to be short integers; 0 means
 *         "background response" i.e. no change.  Each number represents a
 *         given spike sequence.
 *
 *     In sync_mode 1:
 *         The events are generated randomly according to a particular
 *         probability distribution (the ISI distribution of the cell).
 *         The cell responses are read in from a file as in sync_mode 0.
 *         In sync_mode 1 all nonzero numbers are equivalent; the only
 *         distinction is between 0 and nonzero (all nonzero numbers are
 *         equivalent).  Once the odor goes off the response reverts to
 *         the background spiking response for all previously-synchronized
 *         cells.
 *
 */

struct sync_coding_data
{
    char    *sync_events_filename;
    char    *sync_activities_filename;

    int      sync_mode;       /* 0 = read events from file;                */
                              /* else generate events probabilistically.   */
    double   event_prob;      /* Probability of responding to an event.    */
    double   width;           /* Parameter to use to calculate spikeprob.  */
    double   spikeprob;       /* Poisson spike prob. for each time step.   */
    int      nevent_seqs;     /* Number of distinct event sequences.       */
    double   sync_duration;   /* Duration of synchrony;                    */
                              /* (sync_duration < 0) => as long as the     */
                              /* odor is on.                               */
    short_2array *spiked;     /* Flags: have the cells which respond to    */
                              /* a given sequence spiked? (nseqs * ncells) */
    int_2array   *active;     /* With which event sequence do the cells    */
                              /* respond to the odors? (nodors * ncells)   */
    short    nrsb;            /* Flag: if 1, Non-Responding cells (cells
                               * in the pattern which don't respond to the
                               * particular event) Spike at Baseline rate. */

    /* For sync_mode 0 only (read sync events from file): */

    int      event_probs_index;   /* Index into event_probs array.         */
    double_array  *event_probs;   /* Array of event probabilities.         */
    int_array *next_event_index;  /* Next event index for each sequence.   */
    double_array  *current_event; /* Current event of each sequence.       */
    double_array  *next_event;    /* Next event of each sequence.          */
    double_2array *events;      /* Time (relative to odor onset) of spike  */
                                /* events in a sequence (nseqs * nevents). */

    /* For sync_mode 1 only (generate events probabilistically): */

    double  init_last_spike_time; /* Randomly-chosen last spike time to
                                   * start the sequence off.               */
};




/*
 * The `olfactory_bulb' object.
 *
 * This object is a mega-object which is essentially an array of spike
 * generators which generate spikes randomly with the same ISI distribution
 * as actual olfactory bulb mitral cells.  However, you can also select
 * cells as belonging or not belonging to certain "patterns" in the neural
 * network sense; cells in a pattern can have their firing behavior altered
 * when an odor which triggers that pattern is encountered.  This object
 * supports either of two alternative coding strategies: rate coding or
 * synchrony coding.  It also has enough options to fill the kitchen sink.
 *
 * The coding modes are:
 *
 * 0 (default) -- no coding; just background responses
 * 1           -- rate coding: rate of firing is modulated
 * 2           -- synchrony coding: degree of synchrony is modulated
 *
 * There are up to ten possible responses for any given (cell/odor) pair.
 * Response 0 means the cell continues firing as in the background mode.
 * The other responses depend on the coding strategy.  This data is stored
 * in the odor_effect array.
 *
 */


struct olfactory_bulb_type
{
    ELEMENT_TYPE

    /* Fields relating to the ISI histogram. */
    struct  spikeprob_type *isi;    /* Miscellaneous ISI-related data.     */

    /* Cell array. */
    int     ncells;                 /* Number of mitral cells.             */
    struct  Mitral *cell;           /* Array of mitral cells.              */

    /* Output data. */
    struct  ob_output_data *output; /* Miscellaneous output-related data.  */

    /*
     * Odor effect pattern information.
     * FIXME: `patterns_filename' and `odor_effect' are currently only
     * used for the rate coding model, so they should probably be in
     * the rate_code struct unless a way can be found to use them for
     * the synchrony coding model as well.  For the synchrony model the
     * corresponding field is `sync_activities_filename'.  It's probably
     * best to keep them separate because this makes switching between
     * them somewhat easier, although the point is moot.
     */

    int     max_odors;
    char   *patterns_filename;      /* Name of odor effect patterns file.  */
    short  *odor_effect;            /* Effect of odors on cells.           */

    /* Coding information. */
    int     coding_mode;       /* How cell response is modulated by odors. */
    struct  rate_coding_data *rate_code;  /* Rate coding information.      */
    struct  sync_coding_data *sync_code;  /* Synchrony coding information. */

    /* Odor information. */
    int     bg_odor;               /* Number of background odor (0 or -1). */
    int     odor;                  /* Number of applied odor.              */
    short   new_odor;              /* Flag: 1 when an odor comes on.       */
    double  odor_start;            /* When last non-background odor began. */
    double  odor_time;             /* Time since odor onset.               */

    /* Neuromodulation. */
    short   mod_index;             /* Index of neuromodulation to use.     */
};



/*
 * The `spikebuffer' object.
 *
 *     This object is a helper object which acts as an interface between the
 *     olfactory_bulb object and the rest of the simulation.  It receives
 *     SPIKE messages from the olfactory_bulb object and passes them on
 *     unchanged to other objects in the same time step.  This is useful
 *     because we can connect each "mitral cell" in the olfactory_bulb to its
 *     own individual spikebuffer object, which can then be connected to
 *     e.g. pyramidal cell dendrites using the planar/volumeconnect commands,
 *     which wouldn't work correctly for direct connections from the
 *     olfactory_bulb object.
 *
 *     Since this object is just an interface thingy, it has no fields.
 *     Cool, huh? :-)
 *
 */

struct spikebuffer_type
{
    ELEMENT_TYPE
};



/*
 * The `odor_in' object.
 *
 *     This object reads a list of odor identity/onset/duration triples
 *     from a file one by one and puts the odor data into its fields so
 *     it can be sent via ODOR messages to an olfactory_bulb object.  This
 *     object essentially is like an RC object; it starts the odor at the
 *     onset time, the odor reaches its full "concentration" within five
 *     time constants, it lasts until the duration is up, and then decays
 *     to zero within five time constants.  At that time, the next odor is
 *     read in from the file.  If the next odor was scheduled to start
 *     before the last odor was totally finished, a warning is issued an
 *     the odor is ignored.  Thus, this object only can handle one odor
 *     at a time!
 *
 *     Odors have a "concentration" value in arbitrary units in the
 *     range (0,1).  The interpretation of this is left up to the
 *     olfactory_bulb object.  The odors are numbered as follows:
 *
 *      0 = baseline odor; the default
 *     -1 = "blocked nostrils"
 *      1, 2, 3, etc. = different applied odors
 *
 *     The "blocked nostril" odor is considered to be the same as any other
 *     applied odor, with a "concentration" of its own, indicating the
 *     degree of blocking.
 *
 */

/*
 * A struct to package the data read from the odor event file.
 */

struct odor_event
{
    int     odor;      /* Number of odor.       */
    double  onset;     /* Onset time of odor.   */
    double  offset;    /* Offset time of odor.  */
};


struct odor_in_type
{
    ELEMENT_TYPE
    int     odor;      /* Odor number.                                 */
    double  conc;      /* "Concentration" of odor in arbitrary units.  */
    double  tau;       /* Time constant of odor onset/offset.          */
    double  alpha;     /* Time constant variable.                      */
    double  alpha2;    /* Time constant variable.                      */
    short   state;     /* -1 = falling; 1 = rising; 0 = no odor.       */
    char   *filename;  /* Name of odor event file.                     */
    FILE   *file;      /* Odor event file pointer.                     */
    struct odor_event *next_odor;  /* Info about the next odor event.  */
};



#endif  /* BULB_STRUCT_H */


