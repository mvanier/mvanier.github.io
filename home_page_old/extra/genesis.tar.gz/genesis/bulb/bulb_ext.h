/*
 *
 * FILE: bulb_ext.h
 *
 *      Externally-required definitions for the bulb library.
 *
 *
 * AUTHOR: Mike Vanier
 *
 */

#ifndef BULB_EXT_H
#define BULB_EXT_H

#include <stdlib.h>
#include <string.h>

#include "sim_ext.h"
#include "util_expt.h"

/*
 * External functions used by this library.  Ansi-style declarations
 * don't seem to work due to type conversion weirdnesses.  Oh well.
 */

extern int       Error();
extern int       Warning();
extern int       InvalidAction();
extern int       CallEventAction();
extern char     *Pathname();
extern Interpol *create_interpol();
extern float     ran1();
extern int       initopt();
extern int       G_getopt();
extern int       printoptusage();


/* Exported functions specific to this library: */

#include "bulb_expt.h"


/* Global neuromodulation values, defined in piriform library. */

/*
 * MAX_NEUROMODULATED represents the maximum number of
 * neuromodulated parameters.
 */

#define MAX_NEUROMODULATED 100
extern double nm[MAX_NEUROMODULATED];


#endif /* BULB_EXT_H */
