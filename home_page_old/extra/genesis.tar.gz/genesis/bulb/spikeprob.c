/*
 *
 * FILE: spikeprob.c
 *
 *     This file contains the code for a genesis "mini-object" that
 *     manages calculating spike probabilities given ISI distributions.
 *     spikeprob is not a true genesis object, but is used by the
 *     olfactory_bulb object.
 *
 * AUTHOR: Mike Vanier
 *
 */


#include "bulb_ext.h"


/**********************************************************************
 * Forward declarations.
 **********************************************************************/

int
Spikeprob_invariant(struct spikeprob_type *sp);

void
Spikeprob_dump(struct spikeprob_type *sp, Element *parent);

/**********************************************************************
 * End of forward declarations.
 **********************************************************************/


/* Checking invariants. */

#undef  CHECK_INVARIANT
#ifdef  INVARIANT
#define CHECK_INVARIANT assert(Spikeprob_invariant(sp))
#else
#define CHECK_INVARIANT
#endif




/*
 * FUNCTION
 *     Spikeprob_create
 *
 * DESCRIPTION
 *     Creates the object.  NOTE: allocation of memory for
 *     the ISI histogram/distribution structs will be done
 *     in Spikeprob_load().
 *
 * ARGUMENTS
 *     Element *parent -- address of parent element
 *
 * RETURN VALUE
 *     struct spikeprob_type * -- the address of the newly-created
 *                                object, or NULL for failure.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

struct spikeprob_type *
Spikeprob_create(Element *parent)
{
    struct spikeprob_type *sp;

    sp = (struct spikeprob_type *)calloc(1, sizeof(struct spikeprob_type));

    ERRORN_IF (sp == NULL,
               "object: %s: Spikeprob_create: could not allocate memory.\n",
               PARENTPATH);

    sp->filename  = NULL;
    sp->nbins     = 0;
    sp->dx        = 0.0;
    sp->xmax      = 0.0;
    sp->isih      = NULL;
    sp->isid      = NULL;
    sp->ncisid    = NULL;
    sp->nscalef   = 1;
    sp->ratescale = 1.0;

    return sp;
}




/*
 * FUNCTION
 *     Spikeprob_destroy
 *
 * DESCRIPTION
 *    Deallocates memory for the spikeprob object.  You must pass a
 *    pointer to the address so the address can be set to NULL.
 *
 * ARGUMENTS
 *     struct spikeprob_type **sp -- pointer to address of spikeprob object
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Spikeprob_destroy(struct spikeprob_type **sp)
{
    Gfree((*sp)->filename);
    Gfree((*sp)->isih);
    Gfree((*sp)->isid);
    Gfree((*sp)->ncisid);
    Gfree(*sp);
}





/*
 * FUNCTION
 *     Spikeprob_clear
 *
 * DESCRIPTION
 *    Deallocates memory for the spikeprob object tables
 *    and resets it to the state it would be in after being
 *    newly created, except that the filename and nscalef
 *    values aren't changed.  In other words, the ISI file is
 *    ready to be re-loaded after this function exits.
 *    Mostly called on error conditions.
 *
 * ARGUMENTS
 *     struct spikeprob_type *sp -- address of spikeprob object
 *
 * RETURN VALUE
 *     void
 *
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Spikeprob_clear(struct spikeprob_type *sp)
{
    Gfree(sp->isih);
    Gfree(sp->isid);
    Gfree(sp->ncisid);

    sp->nbins    = 0;
    sp->dx       = 0.0;
    sp->xmax     = 0.0;
    sp->isih     = NULL;
    sp->isid     = NULL;
    sp->ncisid   = NULL;
}





/*
 * FUNCTION
 *     Spikeprob_make_isid
 *
 * DESCRIPTION
 *    This function transforms the ISI histogram loaded in from a file
 *    into an ISI probability density function.  In the process, it
 *    may scale the number of points in the original histogram and
 *    use linear interpolation to get the new values.
 *
 * ARGUMENTS
 *     struct spikeprob_type *sp -- address of spikeprob object
 *     Element *parent           -- address of parent element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Spikeprob_make_isid(struct spikeprob_type *sp, Element *parent)
{
    int     old_nbins;
    double  old_dx;
    double *tmp;    /* Temporary storage for the isi probability density. */
    double *slopes; /* Array of slopes. */
    double  sum_counts, isid_int;
    int     i, j;
    double  isid_yscale;
    int     offset, index, data_index, lowindex, highindex;
    double  myslope, dx2, data;

#ifdef PRECONDITIONS
    assert_printd(sp->dx > 0.0,      sp->dx);
    assert_printd(sp->dx < sp->xmax, sp->dx);
    assert_printi(sp->nbins > 0,     sp->nbins);
    assert_printi(sp->nscalef >= 1,  sp->nscalef);
    assert(sp->isih != NULL);
#endif

    old_nbins = sp->nbins;
    old_dx    = sp->dx;

    /*
     * Create the isi probability density in temporary storage;
     * this is before scaling.
     */

    tmp = (double *)calloc((size_t)sp->nbins, sizeof(double));

    ERROR_IF (tmp == NULL,
              "object: %s: Spikeprob_make_isid: "
              "error allocating memory for ISI probability density.\n",
              PARENTPATH);


    /* Sum the counts in the histogram. */

    sum_counts = 0.0;

    for (i = 0; i < sp->nbins; i++)
        sum_counts += sp->isih[i];

    assert_printd(sum_counts > 0.0, sum_counts);


    /*
     * Calculate the ISI probability density function without scaling.
     */

    for (i = 0; i < sp->nbins; i++)
        tmp[i] = (sp->isih[i] / sum_counts) / sp->dx;


    /* Check that the ISI probability density integrates to 1.0. */

    isid_int = 0.0;

    for (i = 0; i < sp->nbins; i++)
        isid_int += tmp[i];

    isid_int *= sp->dx;

    ERROR_IF (fabs(isid_int - 1.0) > TINY,
              "object: %s: Spikeprob_make_isid: "
              "ISI probability density does not integrate to 1.0\n",
              PARENTPATH);


    /*
     * Now scale the ISI probability density if needed and load it into
     * permanent storage.
     */

    ERROR_IF (sp->nscalef < 1,
              "object: %s: Spikeprob_make_isid: "
              "nscalef must be >= 1\n",
              PARENTPATH);

    ERROR_IF (sp->nscalef % 2 == 0,
              "object: %s: Spikeprob_make_isid: "
              "nscalef must be odd!\n",
              PARENTPATH);

    if (sp->nscalef == 1)  /* No scaling needed. */
    {
        sp->isid = tmp;
        /* Don't free the tmp array, of course. */
        return 1;
    }

    assert_printi(sp->nscalef > 1, sp->nscalef);

    sp->nbins *= sp->nscalef;
    sp->dx    /= ((double)sp->nscalef);

    /* Allocate memory for the scaled density. */

    sp->isid = (double *)calloc((size_t)sp->nbins, sizeof(double));

    ERROR_IF (sp->isid == NULL,
              "object: %s: Spikeprob_make_isid: "
              "error allocating memory for ISI probability density.\n",
              PARENTPATH);

    /* Allocate memory for an array of slopes. */

    slopes = (double *)calloc((size_t)(old_nbins - 1), sizeof(double));

    ERROR_IF (slopes == NULL,
              "object: %s: Spikeprob_make_isid: "
              "error allocating memory for slopes.\n",
              PARENTPATH);


    /*
     * Interpolate the new probability density values.
     */

    /*
     * 1) Fill the new density array with -1's to indicate that the places
     *    haven't been filled with real probabilities yet.
     */

    for (i = 0; i < sp->nbins; i++)
        sp->isid[i] = -1.0;

    /*
     * 2) Fill the array of slopes.
     */

    for (i = 0; i < (old_nbins - 1); i++)
        slopes[i] = (tmp[i+1] - tmp[i]) / old_dx;

    /*
     * 3) Load the previous data points in the midpoints of the
     *    corresponding slices of the new array.
     */

    offset = sp->nscalef / 2;  /* Index offset. */

    assert((2 * offset + 1) == sp->nscalef);

    for (i = 0; i < old_nbins; i++)
    {
        index = i * sp->nscalef + offset;

        assert_printi(index >= 0, index);
        assert_printi(index < sp->nbins, index);

        sp->isid[index] = tmp[i];
    }

    /*
     * 4) Use the slopes to calculate the new values in the
     *    unoccupied spaces.
     */

    /*
     * 4a) Initial values, those up to but not including the first
     *     supplied data point.  They use slopes[0], as will
     *     the next set of unfilled points.  They interpolate
     *     BACKWARDS from the first data point, but truncate
     *     probabilities below zero to zero.
     */

    myslope = slopes[0];
    data    = tmp[0];

    assert(data == sp->isid[offset]);

    for (i = 0; i < offset; i++)
    {
        dx2 = ((double)(offset - i)) * sp->dx; /* Distance to data point. */
        sp->isid[i] = data - dx2 * myslope;

        if (sp->isid[i] < 0.0)  /* Truncate to zero. */
            sp->isid[i] = 0.0;
    }

    /*
     * 4b) End values, those beyond the last supplied data point.
     *     They use the last slope value and data point and interpolate
     *     forwards from there, also truncating values below zero.
     */

    myslope    = slopes[old_nbins - 2];  /* Last slope value. */
    data       = tmp[old_nbins - 1];     /* Last data point.  */
    data_index = sp->nbins - 1 - offset;

    assert(data == sp->isid[data_index]);

    for (i = sp->nbins - offset; i < sp->nbins; i++)
    {
        dx2 = (i - data_index) * sp->dx;  /* Distance to data point. */
        sp->isid[i] = data + dx2 * myslope;

        if (sp->isid[i] < 0.0)   /* Truncate to zero. */
            sp->isid[i] = 0.0;
    }

    /*
     * 4c) Values between data points.  Do this in groups of sp->nscalef
     *     consecutive points.  There are (old_nbins - 1) such groups,
     */

    for (i = 0; i < old_nbins - 1; i++)
    {
        /*
         * lowindex and highindex are the indices of old data points
         * that bracket this slice.
         */

        lowindex  = sp->nscalef * i + offset;
        highindex = lowindex + sp->nscalef;
        myslope   = slopes[i];

        for (j = lowindex + 1; j < highindex; j++)
        {
            assert_printd(sp->isid[j] == -1.0, sp->isid[j]);

            dx2 = (j - lowindex) * sp->dx;
            sp->isid[j] = sp->isid[lowindex] + dx2 * myslope;
        }
    }


    /*
     * Since the scaled densities will probably not integrate
     * exactly to 1.0 due to the interpolation, we have to rescale it
     * again.
     */

    isid_int = 0.0;

    for (i = 0; i < sp->nbins; i++)
        isid_int += sp->isid[i];

    isid_int *= sp->dx;

    isid_yscale = 1.0 / isid_int;

    for (i = 0; i < sp->nbins; i++)
        sp->isid[i] *= isid_yscale;


    /* Now check that the ISI densities do indeed integrate to 1.0. */

    isid_int = 0.0;

    for (i = 0; i < sp->nbins; i++)
        isid_int += sp->isid[i];

    isid_int *= sp->dx;

    ERROR_IF (fabs(isid_int - 1.0) > TINY,
              "object: %s: Spikeprob_make_isid: "
              "ISI probability densities integrate to %g instead of 1.0\n",
              PARENTPATH, isid_int);


#ifdef DEBUG2
    /* Print out the isid array, to make sure it's OK. */

    for (i = 0; i < sp->nbins; i++)
        printf("isid[%d] = %g\n", i, sp->isid[i]);

    /* Print out the tmp array, for comparison. */

    for (i = 0; i < old_nbins; i++)
        printf("old isid[%d] = %g\n", i, tmp[i]);
#endif

    /* Free temporary storage. */

    Gfree(tmp);
    Gfree(slopes);

#ifdef POSTCONDITIONS
    for (i = 0; i < sp->nbins; i++)
    {
        assert_printd(sp->isid[i] >= 0.0, sp->isid[i]);
        assert_printd((sp->isid[i] * sp->dx) <= 1.0, (sp->isid[i] * sp->dx));
    }
#endif

    return 1;
}




/*
 * FUNCTION
 *     Spikeprob_load
 *
 * DESCRIPTION
 *    This function loads an ISI histogram from a file and transforms
 *    it into the ISI probability density and the negative cumulative ISI
 *    distribution.
 *
 * ARGUMENTS
 *     struct spikeprob_type *sp -- address of spikeprob object
 *     Element *parent           -- address of parent element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Spikeprob_load(struct spikeprob_type *sp, Element *parent)
{
    FILE   *isi_file;
    int     ir;         /* Generic integer return value. */
    char   *sr;         /* Generic char* ("string") return value. */
    double  xmax;
    int     nbins;
    int     i;
    double  bin_count;
    double  ncum_isi;
    char    line[MAX_LINE_LEN];

    PRINT_ENTERT;

    ERROR_IF (sp->filename == NULL,
              "object: %s: Spikeprob_load: "
              "ISI histogram filename not specified.\n",
              PARENTPATH);

    isi_file = fopen(sp->filename, "r");

    ERROR_IF (isi_file == NULL,
              "object: %s: Spikeprob_load: "
              "can't read ISI histogram file: %s\n",
              PARENTPATH, sp->filename);

    /*
     * The ISI file should consist of one line with just the
     * maximum x value and the number of bins followed by lines
     * with bin counts:
     *     xmax nbins
     *     counts1
     *     counts2
     *     [etc.]
     *
     * If end-of-file occurs before nbins lines are read in, an error is
     * signaled.  If nbins lines have been read in, the file is closed,
     * and further lines in the file (if any) are ignored.
     *
     * The range of the table works like this:
     *
     * bin1: 0 -> bin_width
     * ...
     * last bin: xmax - bin_width -> xmax
     *
     * NOTE: The bin "count" values DO NOT have to be integers.  They can be
     *       averages, smoothed values of counts, etc.  They are converted
     *       to doubles regardless.
     *
     * FIXME: Add capability to ignore `#' comments.
     *
     */

    /* Read in the first line. */

    sr = fgets(line, MAX_LINE_LEN, isi_file);

    if (feof(isi_file) || (sr == NULL))
    {
        Error();
        printf("object: %s: Spikeprob_load: "
               "error reading ISI file: %s\n",
               PARENTPATH, sp->filename);
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }

    ir = sscanf(line, "%lg %d", &xmax, &nbins);

    if ((ir == 0) || (ir == EOF))
    {
        Error();
        printf("object: %s: Spikeprob_load: "
               "error reading first line in ISI file: %s\n"
               "First line must be: xmax nbins\n",
               PARENTPATH, sp->filename);
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }

    if (xmax <= 0.0)
    {
        Error();
        printf("object: %s: Spikeprob_load: "
               "invalid xmax: %g in ISI file: %s\n",
               PARENTPATH, xmax, sp->filename);
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }

    if (nbins <= 0)
    {
        Error();
        printf("object: %s: Spikeprob_load: "
               "invalid nbins: %d in ISI file: %s\n",
               PARENTPATH, nbins, sp->filename);
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }

    sp->xmax  = xmax;
    sp->nbins = nbins;
    sp->dx    = xmax / ((double)nbins);


    /* Create the histogram table. */

    sp->isih = (double *)calloc((size_t)sp->nbins, sizeof(double));

    if (sp->isih == NULL)
    {
        Error();
        printf("object: %s: Spikeprob_load: "
               "error allocating memory for ISI histogram.\n",
               PARENTPATH);
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }


    /*
     * Load the histogram table.
     * Read in the bin counts as doubles.
     */

    i = 0;

    while (1)
    {
        sr = fgets(line, MAX_LINE_LEN, isi_file);

        if (feof(isi_file) || (sr == NULL))
            break;

        RC(i, sp->nbins);
        sscanf(line, "%lg", &bin_count);

        if (bin_count < 0.0)
        {
            Error();
            printf("object: %s: Spikeprob_load: "
                   "ISI histogram bin %d has negative counts!\n",
                   PARENTPATH, i);
            Spikeprob_clear(sp);
            fclose(isi_file);
            return 0;
        }

        sp->isih[i++] = bin_count;
    }


    /* Check that we've read all the bins. */

    if (i != sp->nbins)
    {
        Error();
        printf("object: %s: Spikeprob_load: "
               "only %d bins out of %d were read; aborting.\n",
               PARENTPATH, i, sp->nbins);
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }

    /*
     * Convert the histogram table to the ISI density and negative
     * cumulative ISI distribution.
     *
     * VERY IMPORTANT! PAY ATTENTION TO THIS!!!
     *
     * NOTE: the ISI densities `isid' has nbins entries in the table,
     *       while the negative cumulative ISI distribution `ncisid' has
     *       (nbins + 1) entries.  This is because the entries in the ISI
     *       densities table reflect a value which applies all over an
     *       interval (no interpolation is done) but the ncisid values
     *       correspond to the *endpoints* of the intervals.  isid is a
     *       zero-order approximation to the real ISI probability densities
     *       while ncisid is a first-order (linear) approximation to the real
     *       negative cumulative ISI distribution.  This is necessary since
     *       ncisid has to be determined by integrating isid; if isid was
     *       linearly interpolated we'd get quadratic terms in ncisid,
     *       which is not worth the effort of computing them.  Instead, to
     *       improve accuracy, we can scale the number of points in the
     *       original ISI probability density table.
     *
     * To be nauseatingly explicit, ncisid's format is as follows:
     *
     *       ncisid[0] = 1.0
     *       ncisid[1] = 1.0 - isid[0] * dx
     *       ncisid[2] = ncisid[1] - isid[0] * dx
     *       ...
     *       ncisid[nbins] = 0.0
     *
     */

    /*
     * Make the isi probability density table and scale the number of points.
     * NOTE: this will change sp->nbins and sp->dx.
     */

    if (Spikeprob_make_isid(sp, parent) == 0)
    {
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }


    /*
     * Calculate the negative cumulative ISI distribution.
     * Note that sp->ncisid[0] = 1.0 by definition.
     */

    sp->ncisid = (double *)calloc((size_t)sp->nbins + 1, sizeof(double));

    if (sp->ncisid == NULL)
    {
        Error();
        printf("object: %s: Spikeprob_load: "
               "error allocating memory for negative cumulative "
               "ISI distribution.\n",
               PARENTPATH);
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }

    sp->ncisid[0] = ncum_isi = 1.0;  /* Starting value. */

    for (i = 1; i <= sp->nbins; i++)
    {
        ncum_isi -= sp->isid[i-1] * sp->dx;

        /*
         * ncum_isi may be < 0.0 by a tiny amount due to roundoff
         * error.  If so, truncate it.  If it's off by more than
         * a small amount, issue a warning.
         */

        if (ncum_isi < -TINY)
        {
            Warning();
            printf("object: %s: Spikeprob_load: "
                   "ncum_isi at position %d = %g\n",
                   PARENTPATH, i, ncum_isi);
            ncum_isi = 0.0;
        }
        else if (ncum_isi < 0.0)
        {
            ncum_isi = 0.0;
        }

        sp->ncisid[i] = ncum_isi;
    }

    /* Check that the last entry of ncisid equals 0.0. */

    if (fabs(ncum_isi - 0.0) > TINY)
    {
        Error();
        printf("object: %s: Spikeprob_load: "
               "last entry of negative cumulative ISI distribution is %g, "
               "not 0.0.\n",
               PARENTPATH, ncum_isi);
        Spikeprob_clear(sp);
        fclose(isi_file);
        return 0;
    }

    /* Set last value of ncisid to exactly zero -- what the hell. */

    sp->ncisid[sp->nbins] = 0.0;


    /* Clean up. */

    fclose(isi_file);


#ifdef POSTCONDITIONS
    assert_printd(sp->dx    > 0.0, sp->dx);
    assert_printi(sp->nbins > 0,   sp->nbins);
    assert_printd(sp->xmax  > 0.0, sp->dx);

    for (i = 0; i < sp->nbins; i++)
    {
        assert_printd((sp->isid[i] * sp->dx) >= 0.0, (sp->isid[i] * sp->dx));
        assert_printd((sp->isid[i] * sp->dx) <= 1.0, (sp->isid[i] * sp->dx));
    }

    assert(sp->ncisid[0] == 1.0);

    for (i = 1; i <= sp->nbins; i++)
    {
        assert_printd(sp->ncisid[i] >= 0.0, sp->ncisid[i]);
        assert_printd(sp->ncisid[i] <= 1.0, sp->ncisid[i]);
        assert(sp->ncisid[i] <= sp->ncisid[i-1]);
    }
#endif

#ifdef DEBUG2
    Spikeprob_dump(sp, parent);
#endif

    CHECK_INVARIANT;
    PRINT_EXITT;

    return 1;
}

/*
 * IMPROVEME: Write a dump2 function that uses dt and
 * interpolation to dump the probability distribution
 * as a function of time since the last spike!
 */




/*
 * FUNCTION
 *     Spikeprob_dump
 *
 * DESCRIPTION
 *     Debugging function to dump the stored ISI histogram
 *     and the computed distributions.
 *
 * ARGUMENTS
 *     struct spikeprob_type *sp -- address of spikeprob object
 *     Element *parent           -- address of parent element
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Spikeprob_dump(struct spikeprob_type *sp,
               Element *parent)
{
    int i;

    printf("Dumping spikeprob in element %s\n",
           PARENTPATH);

    printf("filename = %s\n", sp->filename);
    printf("nbins = %d\tdx = %g\txmax = %g\n",
           sp->nbins, sp->dx, sp->xmax);

    printf("ISI histogram: \n");
    for (i = 0; i < (sp->nbins / sp->nscalef); i++)
        printf("bin[%d] = %g\n", i, sp->isih[i]);

    printf("ISI distribution: \n");
    for (i = 0; i < sp->nbins; i++)
        printf("bin[%d] = %g\n", i, sp->isid[i]);

    printf("negative cumulative ISI distribution: \n");
    for (i = 0; i < sp->nbins; i++)
        printf("bin[%d] = %g\n", i, sp->ncisid[i]);
}




/*
 * FUNCTION
 *     Spikeprob_get_table_value
 *
 * DESCRIPTION
 *     Performs a simple linear interpolation on a table of
 *     data values.
 *
 * ARGUMENTS
 *     double *table -- 1-D array of table values
 *     double  x     -- x value we want to access
 *     int     len   -- length of table
 *     double  xmin  -- minimum x value
 *     double  xmax  -- maximum x value
 *     double  dx    -- x interval between data points
 *
 * RETURN VALUE
 *     double -- the interpolated value.
 *
 * NOTES
 *     The first table entry is table[xmin];
 *     the last is table[xmax].
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

/* CHECKME: does inlining here help at all? */

#ifndef DEBUG
inline double
Spikeprob_get_table_value(double *table, double x, double dx)
#else
double
Spikeprob_get_table_value(double *table, double x,
                          int len, double xmin, double xmax, double dx)
#endif
{
    int    i_low, i_high;
    double x_offset, slope, result;

#ifdef PRECONDITIONS
    assert_printi(len > 0, len);
    assert_printd(x >= xmin, x);
    assert_printd(x <= xmax, x);
    assert_printd(dx > 0.0, dx);
    assert(table != NULL);
#endif

    /*
     * Find the index values that bracket x.
     */

    i_low  = (int)(x / dx);
    i_high = i_low + 1;

    assert_printi(i_low  >= 0,   i_low);
    assert_printi(i_high <  len, i_high);

    /*
     * Interpolate table value.
     */

    x_offset = x - i_low * dx;

    /* Compensate for possible roundoff error. */
    if (fabs(x_offset) < VTINY)
        x_offset = 0.0;

    assert_printd(x_offset >= 0.0, x_offset);
    assert_printd(x_offset < dx,   x_offset);

    slope  = (table[i_high] - table[i_low]) / dx;
    result = table[i_low] + x_offset * slope;

#ifdef POSTCONDITIONS
    assert(result <= MAX(table[i_low], table[i_high]));
    assert(result >= MIN(table[i_low], table[i_high]));
#endif

    return result;
}




/*
 * FUNCTION
 *     Spikeprob_get_spike_prob
 *
 * DESCRIPTION
 *     Calculates the probability of spiking this time step
 *     given the time step, the last spike time and the current
 *     degree of spike rate modulation.
 *
 * ARGUMENTS
 *     struct spikeprob_type *sp -- address of spikeprob object
 *     double t    -- the current time
 *     double dt   -- the time step size
 *     double last -- last spike time
 *     double mod  -- spike rate modulation
 *
 * RETURN VALUE
 *     double -- the spike probability.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

double
Spikeprob_get_spike_prob(struct spikeprob_type *sp,
                         double t, double dt, double last,
                         double mod)
{
    double prob;             /* Probability of spiking.                 */
    double dt_last;          /* Time since last spike.                  */
    double isid, ncisid;     /* interpolated values of isid and ncisid. */
    int    index;

#ifdef PRECONDITIONS
    assert(sp != NULL);
    assert_printi(sp->nbins > 0, sp->nbins);
    assert(sp->isid != NULL);
    assert(sp->ncisid != NULL);

    assert_printd(dt > 0.0, dt);
#endif

    /*
     * If t = 0.0 (which it will be on the first time step)
     * just return a zero probability.  Similarly, if mod = 0.0,
     * return a zero probability.  Sorry about the floating comparisons.
     */

    if ((t == 0.0) || (mod == 0.0))
    {
        CHECK_INVARIANT;
        return 0.0;
    }

    assert_printd(t > last, t);
    assert_printd(t > 0.0, t);
    assert_printd(mod > 0.0, mod);

    /*
     * Scale "mod" by the static spike rate modulation value.
     */

    mod *= sp->ratescale;

    /*
     * Calculate effective time since last spike.  Modulation
     * changes the time base, so doubling the spike rate has
     * the effect of making the time since the last spike seem
     * twice as long as it actually was.  Note that dt_last can
     * be anything in the range [0, +infinity] due to the effect
     * of modulation.
     */

    dt_last = (t - last) * mod;

    assert_printd(dt_last >= 0.0, dt_last);

    /*
     * Check for extreme conditions.  If the effective time since the last
     * spike is >= than the last x entry, return a probability of 1.0.
     * Similarly, if the effective time is < dt, return a probability of 0.0.
     * This last is necessary since the spiking probability represents the
     * probability of spiking in the last dt seconds, and is not defined
     * otherwise.
     *
     * IMPROVEME: This could probably be improved as follows: if dt_last
     * is < dt but > 0, consider p(spiking) = p(isi = dt_last) and use
     * interpolation to get that value.  In other words, ignore ncisid,
     * or, equivalently, set it to be 1.0.
     */

    if (dt_last >= sp->xmax)
    {
        CHECK_INVARIANT;
        return 1.0;
    }

    if (dt_last < dt)
    {
        CHECK_INVARIANT;
        return 0.0;
    }

    /*
     * Get the value ncisid(t) by linear interpolation.  The value of
     * isid is simply gotten by indexing.  Conceptually, isid[i] is the
     * value of the ISI density over the i'th interval.  We don't linearly
     * interpolate the ISI density because if we did, the ncisid would have
     * to be interpolated quadratically (because it's a function of the
     * integral of the ISI density), and that isn't worth the effort.
     * Instead, we can use scaling to get a lot of ISI density points from
     * a smaller number of histogram values (see Spikeprob_load() and
     * Spikeprob_make_isid() above).
     *
     * isid is made into a probability by multiplying by dt.  Multiply isid
     * by mod to make sure the density integrates to 1.0.  ncisid is
     * already a probability.
     */

    index   = (int)(dt_last / sp->dx);

    assert_printi(index >= 0, index);
    assert_printi(index < sp->nbins, index);

    isid    = sp->isid[index];
    isid   *= mod * dt;
#ifdef DEBUG
    ncisid  = Spikeprob_get_table_value(sp->ncisid, dt_last, sp->nbins + 1,
                                        0.0, sp->xmax, sp->dx);
#else
    ncisid  = Spikeprob_get_table_value(sp->ncisid, dt_last, sp->dx);
#endif

    assert_printd(isid   >= 0.0, isid);
    assert_printd(isid   <= 1.0, isid);
    assert_printd(ncisid >= 0.0, ncisid);
    assert_printd(ncisid <= 1.0, ncisid);


    /*
     * Calculate firing probability:
     *
     * Probability that (ISI is in range (t, t+dt)) =
     *   (Probability that the cell spikes in (t, t+dt)) *
     *   (Probability that the cell has NOT spiked in (0, t)
     *
     * which is the same as:
     *
     *   (p_i(t) * dt) = (p_s(t) * dt) * (1 - P_c(t))
     *
     * because P_c(t) is the probability that the cell HAS spiked
     * already before t-dt.   Thus, we have
     *
     *   (p_s(t) * dt) = (p_i(t) * dt) / (1 - P_c(t))
     *
     */

    if (isid > ncisid)
    {
        /*
         * isid can be > ncisid if mod > 1.0; that isn't an error.
         * Regardless, return 1.0.
         */

#ifdef DEBUG
        if (mod <= 1.0)
        {
            printf("Warning: Spikeprob_get_spike_prob: "
                   "isid: %g > ncisid: %g\tat time: %g at dt_last: %g\n",
                   isid, ncisid, t, dt_last);
        }
#endif
        return 1.0;
    }

    prob = isid / ncisid;

    assert_printd(prob >= 0.0, prob);
    assert_printd(prob <= 1.0, prob);

    CHECK_INVARIANT;

    return prob;
}




/*
 * FUNCTION
 *     Spikeprob_get_random_ISI
 *
 * DESCRIPTION
 *     Calculates a random ISI value from the ISI distribution.
 *     The algorithm is as follows:
 *
 *     1) Calculate a random number in (0,1); call it x.
 *     2) Find the time whose cumulative probability value from the
 *        cumulative ISI distribution equals x.  This is the (random)
 *        last spike time.
 *     3) Scale it to the current value of spike rate modulation.
 *
 *     This function is used by the synchrony coding code to handle cases
 *     where active cells don't respond to synchronization events but
 *     rather spike at the background rate.  To do this they need to have a
 *     last spike time, but if they've been synchronized to previous
 *     synchronization events the last spike time might be very
 *     uncharacteristic of background spiking.  For instance, if the last
 *     synchronization event was two seconds ago, the last spike was almost
 *     two seconds ago but the maximum ISI is one second, then as soon as
 *     the cell decides not to synchronize with the next event it will fire
 *     i.e. it will look like it *does* synchronize with the event.  That's
 *     why we give it a random value for the last spike time.
 *
 * ARGUMENTS
 *     struct spikeprob_type *sp -- address of spikeprob object
 *     double mod -- spike rate modulation
 *
 * RETURN VALUE
 *     double -- the random last spike time.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

double
Spikeprob_get_random_ISI(struct spikeprob_type *sp, double mod)
{
    double r;                 /* Random number in (0,1). */
    double t;                 /* Time value desired.     */
    double t_low, t_high;
    double p_low, p_high;
    double slope;
    int    i, i_low, i_high;

#ifdef PRECONDITIONS
    assert(sp != NULL);
    assert_printi(sp->nbins > 0, sp->nbins);
    assert(sp->isid != NULL);
    assert_printd(mod > 0.0, mod);

    /* Check that the ISI distribution is valid. */
    CHECK_INVARIANT;
#endif

    r = mran2(1);
    assert((r >= 0.0) && (r <= 1.0));

    /* Take care of endpoint.  Don't forget to take mod into account. */

    if (fabs(r - 1.0) <= TINY)
    {
        /* xmax is the maximum ISI in the distribution. */
        return sp->xmax / mod;
    }

    /*
     * Find the first place in the cumulative ISI distribution where the
     * cumulative distribution is >= r.  Since we actually store the
     * negative cumulative ISI distribution (1 - cum. dist.) rather than
     * the cumulative distribution itself, we have to look for the location
     * in the negative cumulative distribution where its value is less than
     * (1-r).
     */

    r = 1.0 - r;  /* Now r is the random value of ncisid. */

    /*
     * First find the indices that bracket the desired value.  Use -1 as a
     * marker for "index not found".  Don't forget that ncisid has
     * (nbins+1) entries, each representing the endpoints of the
     * distribution.  over an interval, with the first entry equal to 1.0
     * (see above).
     *
     * IMPROVEME: we use a simple linear search here.  A binary search
     * would be much faster.
     */

    i_low = i_high = -1;

    assert(sp->ncisid[0] >= r);

    for (i = 1; i <= sp->nbins; i++)
    {
        if ((sp->ncisid[i-1] >= r) && (sp->ncisid[i] < r))
        {
            i_low  = i - 1;
            i_high = i;
            break;
        }
    }

    assert(i_low  >= 0);
    assert(i_high >= 1);
    assert(i_high <= sp->nbins);
    assert(i_high == (i_low + 1));

    /*
     * Get the interpolated value of the ISI time.  Take the current
     * value of mod into account.
     */

    t_low   = i_low * sp->dx;
    t_high  = t_low + sp->dx;
    assert(t_high > t_low);

    p_low   = sp->ncisid[i_low];
    p_high  = sp->ncisid[i_high];
    slope   = (p_high - p_low) / (t_high - t_low); /* dy/dx */
    assert_printd(slope < 0.0, slope);

    assert(r <= p_low);
    t = t_low + (r - p_low) / slope;

    /*
     * Scale for mod value.  The higher the mod value, the faster the
     * spiking and hence the shorter the ISIs.
     */

    t /= mod;

#ifdef POSTCONDITIONS
    assert(t >= 0.0);
    assert(t <= sp->xmax);
#endif

    return t;
}




/* FIXME: the next two functions can be factored! */

/*
 * FUNCTION
 *     Spikeprob_check
 *
 * DESCRIPTION
 *     Checks integrity of object.
 *
 * ARGUMENTS
 *     struct spikeprob_type *sp -- address of spikeprob object
 *     Element *parent           -- address of parent element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Spikeprob_check(struct spikeprob_type *sp, Element *parent)
{
    int i;

    ERROR_IF (sp->nbins <= 0,
              "object: %s: Spikeprob_check: "
              "spikeprob object must have nbins > 0\n",
              PARENTPATH);

    ERROR_IF (sp->dx <= 0.0,
              "object: %s: Spikeprob_check: "
              "spikeprob object must have dx > 0.0\n",
              PARENTPATH);

    ERROR_IF (sp->xmax <= 0.0,
              "object: %s: Spikeprob_check: "
              "spikeprob object must have xmax > 0.0\n",
              PARENTPATH);

    ERROR_IF (sp->dx > sp->xmax,
              "object: %s: Spikeprob_check: "
              "spikeprob object must have dx <= xmax\n",
              PARENTPATH);

    for (i = 0; i < (sp->nbins / sp->nscalef); i++)
    {
        ERROR_IF (sp->isih[i] < 0.0,
                  "object: %s: Spikeprob_check: "
                  "spikeprob object: invalid isih[%d] = %g\n",
                  PARENTPATH, i, sp->isih[i]);
    }

    for (i = 0; i < sp->nbins; i++)
    {
        ERROR_IF ((sp->isid[i] < 0.0) || (sp->isid[i] * sp->dx > 1.0),
                  "object: %s: Spikeprob_check: "
                  "spikeprob object: invalid isid[%d] = %g\n",
                  PARENTPATH, i, sp->isid[i]);

        ERROR_IF ((sp->ncisid[i] < 0.0) || (sp->ncisid[i] > 1.0),
                  "object: %s: Spikeprob_check: "
                  "spikeprob object: invalid ncisid[%d] = %g\n",
                  PARENTPATH, i, sp->ncisid[i]);

        /*
         * Check monotonicity of ISI distribution.
         */

        if (i == 0)
            continue;

        ERROR_IF (sp->ncisid[i] > sp->ncisid[i-1],
                  "object: %s: Spikeprob_check: "
                  "spikeprob object: invalid non-monotonic ncisid[%d] "
                  "= %g\n",
                  PARENTPATH, i, sp->ncisid[i]);
    }

    /* Check endpoints of ncisid. */

    ERROR_IF (fabs(sp->ncisid[0] - 1.0) > TINY,
              "object: %s: Spikeprob_check: "
              "spikeprob object: invalid ncisid[0] = %g;\n"
              "should be 1.0.",
              PARENTPATH, sp->ncisid[0]);

    ERROR_IF (fabs(sp->ncisid[sp->nbins]) > TINY,
              "object: %s: Spikeprob_check: "
              "spikeprob object: invalid ncisid[nbins] = %g;\n"
              "should be 0.0.",
              PARENTPATH, sp->ncisid[sp->nbins]);

    ERROR_IF (sp->nscalef < 1,
              "object: %s: Spikeprob_check: "
              "spikeprob object: invalid nscalef = %d;\n"
              "should be >= 1.",
              PARENTPATH, sp->nscalef);

    ERROR_IF (sp->nscalef % 2 == 0,
              "object: %s: Spikeprob_check: "
              "spikeprob object: invalid nscalef = %d;\n"
              "should be odd.",
              PARENTPATH, sp->nscalef);

    return 1;
}




/*
 * FUNCTION
 *     Spikeprob_invariant
 *
 * DESCRIPTION
 *     Checks integrity of object.  Like Spikeprob_check, but
 *     doesn't require knowledge of the parent object name.
 *
 * ARGUMENTS
 *     struct spikeprob_type *sp -- address of spikeprob object
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Spikeprob_invariant(struct spikeprob_type *sp)
{
    int i;

    ERROR_IF (sp->nbins <= 0,
              "Spikeprob_invariant: "
              "spikeprob object must have nbins > 0\n");

    ERROR_IF (sp->dx <= 0.0,
              "Spikeprob_invariant: "
              "spikeprob object must have dx > 0.0\n");

    ERROR_IF (sp->xmax <= 0.0,
              "Spikeprob_invariant: "
              "spikeprob object must have xmax > 0.0\n");

    ERROR_IF (sp->dx > sp->xmax,
              "Spikeprob_invariant: "
              "spikeprob object must have dx <= xmax\n");

    for (i = 0; i < (sp->nbins / sp->nscalef); i++)
    {
        ERROR_IF (sp->isih[i] < 0.0,
                  "Spikeprob_invariant: "
                  "spikeprob object: invalid isih[%d] = %g\n",
                  i, sp->isih[i]);
    }

    for (i = 0; i < sp->nbins; i++)
    {
        ERROR_IF ((sp->isid[i] < 0.0) || (sp->isid[i] * sp->dx > 1.0),
                  "Spikeprob_invariant: "
                  "spikeprob object: invalid isid[%d] = %g\n",
                  i, sp->isid[i]);

        ERROR_IF ((sp->ncisid[i] < 0.0) || (sp->ncisid[i] > 1.0),
                  "Spikeprob_invariant: "
                  "spikeprob object: invalid ncisid[%d] = %g\n",
                  i, sp->ncisid[i]);

        /*
         * Check monotonicity of ISI distribution.
         */

        if (i == 0)
            continue;

        ERROR_IF (sp->ncisid[i] > sp->ncisid[i-1],
                  "Spikeprob_invariant: "
                  "spikeprob object: invalid non-monotonic ncisid[%d] "
                  "= %g\n",
                  i, sp->ncisid[i]);
    }

    /* Check endpoints of ncisid. */

    ERROR_IF (fabs(sp->ncisid[0] - 1.0) > TINY,
              "Spikeprob_invariant: "
              "spikeprob object: invalid ncisid[0] = %g;\n"
              "should be 1.0.",
              sp->ncisid[0]);

    ERROR_IF (fabs(sp->ncisid[sp->nbins]) > TINY,
              "Spikeprob_invariant: "
              "spikeprob object: invalid ncisid[nbins] = %g;\n"
              "should be 0.0.",
              sp->ncisid[sp->nbins]);

    ERROR_IF (sp->nscalef < 1,
              "Spikeprob_invariant: "
              "spikeprob object: invalid nscalef = %d;\n"
              "should be >= 1.",
              sp->nscalef);

    ERROR_IF (sp->nscalef % 2 == 0,
              "Spikeprob_invariant: "
              "spikeprob object: invalid nscalef = %d;\n"
              "should be odd.",
              sp->nscalef);

    return 1;
}

