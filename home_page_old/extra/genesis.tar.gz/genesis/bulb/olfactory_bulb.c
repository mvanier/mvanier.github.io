/*
 *
 * FILE: olfactory_bulb.c
 *
 *     This file contains the definition of the olfactory bulb
 *     spike-generating object.  This object emphatically
 *     DOES NOT model the internal dynamics of the olfactory
 *     bulb; it merely spits out spikes in a manner similar
 *     to what is seen in experiments.  It also has some
 *     features that let the user experiment with different
 *     coding strategies for olfactory information, but
 *     these are highly speculative.
 *
 *
 * AUTHOR: Mike Vanier
 *
 */

#include "bulb_ext.h"


/* Forward declarations. */

int
OlfactoryBulb_CHECK(struct olfactory_bulb_type *element);


/* Checking invariants. */

#undef  CHECK_INVARIANT
#ifdef  INVARIANT
#define CHECK_INVARIANT assert(OlfactoryBulb_CHECK(element))
#else
#define CHECK_INVARIANT
#endif




/*
 * Utility functions for dealing with odor response patterns.
 */


/*
 * FUNCTION
 *     OlfactoryBulb_set_pattern_value
 *
 * DESCRIPTION
 *     Sets a particular pattern value for a particular mitral cell.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *     int   cell -- index of cell in mitral cell array
 *     int   i    -- index of odor response to be set
 *     short val  -- the odor response pattern
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * NOTES
 *     Odors use 1-based indexing while cells use 0-based indexing.
 *     This is necessary because odor 0 means no odor.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_set_pattern_value(struct olfactory_bulb_type *element,
                                int cell, int i, short val)
{
    int index;

#ifdef PRECONDITIONS
    assert(element->cell != NULL);
    assert_printi(cell >= 0, cell);
    assert_printi(cell < element->ncells, cell);
    assert_printi(i > 0, i);
    assert_printi(i <= element->max_odors, i);
    assert_printi(val >= 0, val);
#endif

    index = element->max_odors * cell + (i - 1);
    element->odor_effect[index] = val;
    return 1;
}




/*
 * FUNCTION
 *     OlfactoryBulb_get_pattern_value
 *
 * DESCRIPTION
 *     Gets a particular pattern value for a particular mitral cell.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *     int cell -- index of cell in mitral cell array
 *     int i    -- number of bit to be read
 *
 * RETURN VALUE
 *     short -- the pattern value or -1 if an error occurs.
 *
 * NOTES
 *     Odors use 1-based indexing while cells use 0-based indexing.
 *     This is necessary because odor 0 means no odor.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

short
OlfactoryBulb_get_pattern_value(struct olfactory_bulb_type *element,
                                int cell, int i)
{
    char val;
    int  index;

#ifdef PRECONDITIONS
    assert(element->cell != NULL);
    assert_printi(cell >= 0, cell);
    assert_printi(cell < element->ncells, cell);
    assert_printi(i > 0, i);
    assert_printi(i <= element->max_odors, i);
#endif

    index = element->max_odors * cell + (i - 1);
    val = element->odor_effect[index];

#ifdef POSTCONDITIONS
    assert_printi(val >= 0, val);
#endif

    return val;
}




/*
 * FUNCTION
 *     OlfactoryBulb_get_odor_response
 *
 * DESCRIPTION
 *     Gets the value of a particular odor response at a particular
 *     time after the odor onset.  This value is a modulation of the
 *     background firing rate.  It's calculated by linear interpolation
 *     of the available data points.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *     int resp_type                       -- type of response
 *
 * RETURN VALUE
 *     double -- the computed rate modulation value.
 *
 * NOTES
 *     This is only used for implementing rate coding.
 *     element->rate_code->curr_index must have been computed
 *     before calling this function.  This uses 1-based indexing
 *     for the odor responses, since response 0 is, by definition,
 *     equal to the background response (i.e. the mod value is
 *     always 1.0).
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

double
OlfactoryBulb_get_odor_response(struct olfactory_bulb_type *element,
                                int resp_type)
{
    int    lower;       /* Time index value below odor_time. */
    int    upper;
    double mod, dt;
    double lmod, umod;  /* Values that bracket correct mod value. */
    double delta;

    lower = element->rate_code->curr_index;
    upper = lower + 1;
    mod   = 1.0;
    dt    = element->rate_code->dt;
    delta = element->odor_time - (lower * dt);

#ifdef PRECONDITIONS
    assert_printi(resp_type >= 1, resp_type);
    assert_printi(lower >= 0, lower);
    assert_printi(lower < element->rate_code->nrespt, lower);
    assert_printd(delta >= 0.0, delta);
    assert_printd(dt > 0.0, dt);
#endif

#ifdef DEBUG2
    printf("lower = %d\todor_time = %g\tdt = %g\tdelta = %g\n",
           lower, element->odor_time, dt, delta);
#endif

    /*
     * Change from 1-based to 0-based array indexing for resp_type.
     */

    resp_type--;

    if (delta == 0.0)
    {
        /* Handle boundary conditions. */

        mod = element->rate_code->resp[resp_type][lower];
    }
    else
    {
        /* Use linear interpolation to get the correct mod value. */

        lmod = element->rate_code->resp[resp_type][lower];

#ifdef DEBUG2
        printf("lmod = %g\n", lmod);
#endif

        /*
         * If lower is the last entry in the table, use 1.0 for the
         * next mod value, corresponding to the end of the odor.
         */

        if (upper == element->rate_code->nrespt)
            umod = 1.0;
        else
            umod = element->rate_code->resp[resp_type][upper];

        mod = lmod + ((umod - lmod) / dt) * delta;
    }

#ifdef POSTCONDITIONS
    assert_printd(mod >= 0.0, mod);
#endif

#ifdef DEBUG2
    printf("resp_type = %d\tmod = %g\n", resp_type, mod);
#endif

    return mod;
}




/*
 * FUNCTION
 *     OlfactoryBulb_free_odor_response_data
 *
 * DESCRIPTION
 *     Frees the odor response data.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     void
 *
 * NOTES
 *     This is only used with rate coding.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
OlfactoryBulb_free_odor_response_data(struct olfactory_bulb_type *element)
{
    int i;

    if (element->rate_code == NULL)
        return;  /* Nothing to free. */

    if (element->rate_code->resp == NULL)
        return;  /* Nothing to free. */

    for (i = 0; i < element->max_odors; i++)
        Gfree(element->rate_code->resp[i]);

    Gfree(element->rate_code->resp);
}




/*
 * Utility functions for dealing with the mitral cell array.
 */


/*
 * FUNCTION
 *     OlfactoryBulb_initialize_mitral_cells
 *
 * DESCRIPTION
 *    This function initializes the mitral cell spike generator array.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_initialize_mitral_cells(struct olfactory_bulb_type *element)
{
    int i, ncells;

    PRINT_ENTERT;

    ncells = element->ncells;

    ERROR_IF (ncells <= 0,
              "olfactory_bulb object: %s: can't have < 0 cells.\n",
              MYPATH);

    element->cell = (struct Mitral *)
        calloc((size_t)ncells, sizeof(struct Mitral));

    ERROR_IF (element->cell == NULL,
              "olfactory_bulb object: %s: "
              "failed to allocate memory for cells.\n",
              MYPATH);

    for (i = 0; i < ncells; i++)
    {
        element->cell[i].spiking = 0;

        /*
         * NOTE: The initial values of `last_spike_time' are set
         * in the RESET action.
         */

        element->cell[i].last_spike_time = 0.0;

        /*
         * Set msgout field to NULL; once SPIKE messages are added these
         * fields will have pointers to those messages.
         */

        element->cell[i].msgout = NULL;
    }

    PRINT_EXITT;

    return 1;
}


/*
 **********************************************************************
 *
 * Action functions.
 *
 **********************************************************************
 */


/*
 * FUNCTION
 *     OlfactoryBulb_CREATE
 *
 * DESCRIPTION
 *     This action sets default values for a number of fields,
 *     and allocates memory for a number of structs.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_CREATE(struct olfactory_bulb_type *element)
{
    PRINT_ENTERT;

    /* Spikeprob object. */

    element->isi = Spikeprob_create((Element *)element);

    if (element->isi == NULL)
        return 0;

    /*** Cell array. ***/

    element->ncells = 0;     /* No cells to start with. */
    element->cell   = NULL;

    /*** Output data. ***/

    element->output = (struct ob_output_data *)
        calloc((size_t)1, sizeof(struct ob_output_data));

    ERROR_IF (element->output == NULL,
              "olfactory_bulb object: %s: error allocating memory.\n",
              MYPATH);

    element->output->enabled  = 0;    /* Not recording. */
    element->output->flush    = 0;    /* Default: don't flush after write. */
    element->output->filename = NULL;
    element->output->file     = NULL;

    /*** Pattern-related information. ***/

    element->max_odors        = 0;    /* No odor patterns loaded. */
    element->odor_effect      = NULL;

    /*** Coding information. ***/

    element->coding_mode      = NO_CODING;  /* Only background responses. */

    /** 1. Rate coding. **/

    element->rate_code        = NULL;

    /** 2. Synchrony coding. **/

    element->sync_code        = NULL;

    /*** Odor information. ***/

    element->bg_odor         = 0;     /* Background odor at start. */
    element->odor            = 0;
    element->new_odor        = 0;     /* An odor has not just come on. */
    element->odor_start      = 0.0;
    element->odor_time       = 0.0;

    /*** Neuromodulation. ***/

    element->mod_index  = -1;    /* No neuromodulation to begin with. */

    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     OlfactoryBulb_DESTROY
 *
 * DESCRIPTION
 *     This action deallocates all previously-allocated memory
 *     and closes all open files.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
OlfactoryBulb_DESTROY(struct olfactory_bulb_type *element)
{
    int i;

    PRINT_ENTERT;

    /* Close open files. */

    if (element->output->enabled)
        fclose(element->output->file);

    /*
     * Deallocate memory.
     */

    /*** ISI data. ***/

    Spikeprob_destroy(&(element->isi));


    /*** Mitral cell array. ***/

    Gfree(element->cell);
    element->ncells = 0;


    /*** Output data. ***/

    Gfree(element->output->filename);
    Gfree(element->output);


    /*** Odor effect pattern information. ***/

    Gfree(element->odor_effect);


    /*** Odor response rate information. ***/

    OlfactoryBulb_free_odor_response_data(element);


    /*** Coding data. ***/

    switch (element->coding_mode)
    {
    case RATE_CODING:
        for (i = 0; i < element->max_odors; i++)
            Gfree(element->rate_code->resp[i]);

        Gfree(element->rate_code);

        break;

    case SYNCHRONY_CODING:
        Sync_destroy(&(element->sync_code));

    default:
        /* Do nothing. */
        break;
    }

    PRINT_EXITT;
}




/*
 * FUNCTION
 *     OlfactoryBulb_INITRATEINFO
 *
 * DESCRIPTION
 *     This action creates and initializes the rate coding structs.
 *     FIXME: there should be a corresponding action for synchrony
 *     coding.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_INITRATEINFO(struct olfactory_bulb_type *element)
{
    int i;

    PRINT_ENTERT;

    /*
     * Free the previously-existing rate code structt if any.
     */

    if (element->rate_code != NULL)
    {
        for (i = 0; i < element->max_odors; i++)
            Gfree(element->rate_code->resp[i]);

        Gfree(element->rate_code);
    }

    /* Allocate the new struct and set its fields. */

    element->rate_code = (struct rate_coding_data *)
        calloc((size_t)1, sizeof(struct rate_coding_data));

    ERROR_IF (element->rate_code == NULL,
              "olfactory_bulb object: %s: error allocating memory.\n",
              MYPATH);

    element->rate_code->filename   = NULL;
    element->rate_code->nrespt     = 0;
    element->rate_code->tresp      = 0.0;
    element->rate_code->dt         = 0.0;
    element->rate_code->curr_index = 0;
    element->rate_code->resp       = NULL;

    CHECK_INVARIANT;
    PRINT_EXITT;

    return 1;
}





/*
 * FUNCTION
 *     OlfactoryBulb_INITIALIZE
 *
 * DESCRIPTION
 *    This action gets called manually after the bulb object has been
 *    created and the relevant fields have been set, but before a
 *    reset.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_INITIALIZE(struct olfactory_bulb_type *element)
{
    PRINT_ENTERT;

    /* Create the ISI distribution. */

    if (Spikeprob_load(element->isi, (Element *)element) == 0)
        return 0;

    /* Create the cell array. */

    if (OlfactoryBulb_initialize_mitral_cells(element) == 0)
        return 0;

    /* Create the struct corresponding to the coding mode desired. */

    switch (element->coding_mode)
    {
    case RATE_CODING:
        OlfactoryBulb_INITRATEINFO(element);
        break;

    case SYNCHRONY_CODING:
        element->sync_code = Sync_create(element);

    case NO_CODING:
        /* No coding mode selected, so do nothing. */
        break;

    default:
        ERROR ("olfactory_bulb object: %s: invalid coding mode: %d.\n",
               MYPATH, element->coding_mode);

        /* Do nothing. */
        break;
    }

    CHECK_INVARIANT;
    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     OlfactoryBulb_RESET
 *
 * DESCRIPTION
 *     Opens an output file if requested.
 *     Initializes last spike time of mitral cells.
 *     Resets rate coding and/or sync coding data.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_RESET(struct olfactory_bulb_type *element)
{
    int i;

    PRINT_ENTERT;

    /*** Odor information. ***/

    element->odor       = element->bg_odor;  /* Start with bg odor. */
    element->odor_start = 0.0;
    element->odor_time  = 0.0;


    /* Open the output file if requested. */

    if (element->output->enabled)
    {
        ERROR_IF (element->output->filename == NULL,
                  "olfactory_bulb object: %s: "
                  "no output filename specified.\n",
                  MYPATH);

        element->output->file = fopen(element->output->filename, "w");

        ERROR_IF (element->output->file == NULL,
                  "olfactory_bulb object: %s: "
                  "can't open output file: %s.\n",
                  MYPATH, element->isi->filename);
    }

    /*
     * Set `last_spike_time' values to be random values based on the
     * ISI histogram.  This simulates what you'd see in a snapshot
     * of the object after it had been running for a long time.
     */

    for (i = 0; i < element->ncells; i++)
    {
        double mod;

        if (element->mod_index < 0)  /* No neuromodulation. */
            mod = 1.0;
        else
            mod = nm[element->mod_index];

        element->cell[i].last_spike_time =
            -Spikeprob_get_random_ISI(element->isi, mod);
    }


    /*
     * NOTE: resetting the rate and synchrony code information is done
     *       automatically when a new odor comes on.
     */

    CHECK_INVARIANT;
    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     OlfactoryBulb_CHECK
 *
 * DESCRIPTION
 *     Checks the integrity of the element.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_CHECK(struct olfactory_bulb_type *element)
{
    int i, j;
    int result = 1;

    /*
     * Don't check the element->isi fields, since their only function
     * is as temporary storage while the element->isi_dist values
     * are being calculated.
     */

    /*** Check ISI distribution. ***/

    Spikeprob_check(element->isi, (Element *)element);


    /*** Check the mitral cell array. ***/

    ERROR_IF (element->ncells < 0,
              "olfactory_bulb object: %s: ncells must be >= 0.\n",
              MYPATH);

    /*** Check odor effect data. ***/

    ERROR_IF (element->max_odors < 0,
              "olfactory_bulb object: %s: "
              "max_odors must be >= 0.\n",
              MYPATH);


    /*** Check coding information. ***/

    /*
     * The maximum value of coding_mode is currently 2,
     * but this may change.
     */

    ERROR_IF ((element->coding_mode < 0) || (element->coding_mode > 2),
              "olfactory_bulb object: %s: coding_mode: "
              "%d must be in the range [0,2].\n",
              MYPATH, element->coding_mode);


    /*
     * Check rate coding data if there is any.
     * FIXME: This causes a lot of INVARIANT-checking code to break
     *        because it's applied before LOADRATEINFO is called.
     *        How do we fix this?  The right way is to have different
     *        functions for invariant checking instead of just (ab)using
     *        CHECK for this purpose.
     */

    if (element->rate_code != NULL)
    {
        ERROR_IF (element->rate_code->nresp <= 0,
                  "olfactory_bulb object: %s: "
                  "rate_code->nresp must be > 0\n",
                  MYPATH);

        ERROR_IF (element->rate_code->nrespt <= 0,
                  "olfactory_bulb object: %s: "
                  "rate_code->nrespt must be > 0\n",
                  MYPATH);

        ERROR_IF (element->rate_code->tresp <= 0.0,
                  "olfactory_bulb object: %s: "
                  "rate_code->tresp must be > 0.0\n",
                  MYPATH);

        ERROR_IF (element->rate_code->dt <= 0.0,
                  "olfactory_bulb object: %s: "
                  "rate_code->dt must be > 0.0\n",
                  MYPATH);

        /* Make sure the array of responses is valid. */

        for (i = 0; i < element->rate_code->nresp; i++)
        {
            for (j = 0; j < element->rate_code->nrespt; j++)
            {
                ERROR_IF (element->rate_code->resp[i][j] < 0.0,
                          "olfactory_bulb object: %s: "
                          "rate_code->resp[%d][%d] must be >= 0.0\n",
                          MYPATH, i, j);
            }
        }
    }

    /*
     * Check odor information.  This is mainly useful when the
     * simulation is in progress.
     */

    ERROR_IF ((element->bg_odor != -1) && (element->bg_odor != 0),
              "olfactory_bulb object: %s: bg_odor must be -1 or 0.\n",
              MYPATH);

    ERROR_IF (element->odor < -1,
              "olfactory_bulb object: %s: odor must be >= -1.\n",
              MYPATH);

    ERROR_IF ((element->new_odor != 0) && (element->new_odor != 1),
              "olfactory_bulb object: %s: new_odor must be 0 or 1.\n",
              MYPATH);

    ERROR_IF (element->odor_start < 0.0,
              "olfactory_bulb object: %s: odor_start must be >= 0.0.\n",
              MYPATH);

    ERROR_IF (element->odor_time < 0.0,
              "olfactory_bulb object: %s: odor_time must be >= 0.0.\n",
              MYPATH);

    /* FIXME: Check that only one ODOR message at most is being received. */

    return result;
}




/*
 * FUNCTION
 *     OlfactoryBulb_ADDMSGOUT
 *
 * DESCRIPTION
 *     When an outgoing SPIKE message is added to the message list,
 *     a pointer to the message has to be copied to one of the mitral
 *     cell structs, so that we don't have to do an expensive message
 *     lookup operation every time a spike needs to be triggered.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *     Action *action                      -- address of action
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_ADDMSGOUT(struct olfactory_bulb_type *element,
                        Action *action)
{
    Msg   *msg;
    int    i, result;
    short  found;

    PRINT_ENTERT;

    msg = (Msg *) action->data;

#ifdef DEBUG
    printf("olfactory_bulb: ADDMSGOUT: "
           "Adding message of type %d from %s to %s\n",
           msg->type, Pathname(msg->src), Pathname(msg->dst));
#endif

    result = 1;

    if (msg->type == SPIKE)
    {
        /*
         * Add the message to the first available mitral cell.
         */

        found = 0;

        for (i = 0; i < element->ncells; i++)
        {
            if (element->cell[i].msgout == NULL)
            {
                element->cell[i].msgout = msg;
                found = 1;
                break;
            }
        }

        if (!found)
        {
            Error();
            printf("olfactory_bulb: ADDMSGOUT: "
                   "no available mitral cells for SPIKE message.\n"
                   "Please delete this SPIKE message: from %s to %s\n",
                   Pathname(msg->src), Pathname(msg->dst));

            /*
             * FIXME: This is a cop-out.  The message should get deleted
             * automatically, but I don't know if it's possible to delete
             * a message from within an ADDMSGOUT action.
             */

            result = 0;
        }
    }

    PRINT_EXITT;

    return result;
}




/*
 * FUNCTION
 *     OlfactoryBulb_DELETEMSGOUT
 *
 * DESCRIPTION
 *     When an outgoing SPIKE message is deleted from the message list,
 *     a pointer to the message which existed in one of the mitral
 *     cell structs has to be reset to NULL.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *     Action *action                      -- address of action
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_DELETEMSGOUT(struct olfactory_bulb_type *element,
                           Action *action)
{
    Msg   *msg;
    int    i, result;
    short  found;

    PRINT_ENTERT;

    msg = (Msg *) action->data;

#ifdef DEBUG
    printf("olfactory_bulb: DELETEMSGOUT: "
           "Deleting message of type %d from %s to %s\n",
           msg->type, Pathname(msg->src), Pathname(msg->dst));
#endif

    result = 1;

    if (msg->type == SPIKE)
    {
        /*
         * Find the message in the mitral cell array (if it exists) and
         * set its value to NULL.
         */

        found = 0;

        for (i = 0; i < element->ncells; i++)
        {
            if (element->cell[i].msgout == msg)
            {
                element->cell[i].msgout = NULL;
                found = 1;
            }
        }

        ERROR_IF (!found,
                  "olfactory_bulb: DELETEMSGOUT: "
                  "SPIKE message not found in mitral cell array.\n");
    }

    PRINT_EXITT;

    return result;
}




/*
 * FUNCTION
 *     OlfactoryBulb_MSGINFO
 *
 * DESCRIPTION
 *     Prints information about SPIKE messages leaving
 *     the object.  This is useful to know who is and
 *     who isn't connected, and to whom.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
OlfactoryBulb_MSGINFO(struct olfactory_bulb_type *element)
{
    int   i;
    int   count1, count2;
    Msg  *msgout;

    printf("\nMessage data for olfactory_bulb object: %s\n\n",
           MYPATH);

    /* Count the number of SPIKE messages being sent by the object. */

    count1 = 0;

    MSGOUTLOOP(element, msgout)
        {
            if (msgout->type == SPIKE)
                count1++;
        }

    /*
     * Now count the number of SPIKE messages in the mitral cells.
     * They should be the same.  Also print out the message data
     * at the same time.
     */

    count2 = 0;

    for (i = 0; i < element->ncells; i++)
    {
        msgout = element->cell[i].msgout;

        if (msgout == NULL)
        {
            printf("cell[%d]: no SPIKE message being sent.\n", i);
        }
        else
        {
            printf("cell[%d]: SPIKE message being sent to %s\n",
                   i, Pathname(msgout->dst));

            count2++;
        }
    }

    printf("\n");

    if (count1 != count2)
    {
        Warning();
        printf("Useless SPIKE messages exist; please delete them.\n\n");
    }
}




/*
 * FUNCTION
 *     OlfactoryBulb_LOADPATTERNS
 *
 * DESCRIPTION
 *     Loads odor pattern information from a file.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element  -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * NOTES
 *     This action must be called AFTER the mitral cell
 *     array has been allocated.  In particular, ncells,
 *     max_odors and pattern_filename must be set.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_LOADPATTERNS(struct olfactory_bulb_type *element)
{
    FILE *fp;
    char  line[MAX_LINE_LEN];
    int   cell;
    short v;
    int   i;
    int   size;
    char *sr;  /* Generic char* ("string") return value. */
    short_array *sha;


    PRINT_ENTERT;


    /* Make sure there is a file to load. */

    ERROR_IF (element->patterns_filename == NULL,
              "olfactory_bulb object: %s: LOADPATTERNS: "
              "no pattern filename specified.\n",
              MYPATH);

    fp = fopen(element->patterns_filename, "r");

    ERROR_IF (fp == NULL,
              "olfactory_bulb object: %s: LOADPATTERNS: "
              "couldn't open pattern file: %s\n",
              MYPATH, element->patterns_filename);

    /*
     * Allocate memory for the array based on ncells and max_odors.
     * Allocate as a 1-D array to prevent large numbers of malloc's,
     * which waste time.  CHECKME: is this right?
     */

    size = element->ncells * element->max_odors;

    ERROR_IF (size <= 0,
              "olfactory_bulb object: %s: LOADPATTERNS: "
              "require: ncells * max_odors > 0\n",
              MYPATH);

    element->odor_effect = (short *)calloc((size_t)size, sizeof(short));

    ERROR_IF (element->odor_effect == NULL,
              "olfactory_bulb object: %s: LOADPATTERNS: "
              "failed to allocate memory for patterns.\n",
              MYPATH);

    /*
     * The pattern file should consist of ncells lines which each have
     * max_odor non-negative short integers.  Read the file in
     * line-by-line; if any mistake occurs, report it and free the pattern
     * storage.  Each line contains the odor responses of a given cell
     * i.e. the integer represents a particular odor response type
     * (e.g. time-dependent modulation) for a particular cell when a
     * particular odor is present.
     */

    cell = 0;

    while(1)
    {
        assert_printi(cell <= element->ncells, cell);

        /* Read in a line of shorts max_odors long. */

        sr = fgets(line, MAX_LINE_LEN, fp);

        ERROR_IF ((sr == NULL) && !feof(fp),
                  "olfactory_bulb object: %s: LOADPATTERNS: "
                  "error reading pattern file: %s, line: %d\n",
                  MYPATH, element->patterns_filename, cell);

        if (feof(fp)) /* No more lines to read. */
            break;

        sha = split_line_n_shorts(line, "\t ", element->max_odors);

        if (sha == NULL)
        {
            Error();
            printf("olfactory_bulb object: %s: LOADPATTERNS: "
                   "invalid pattern line in file: %s, line: %d; "
                   "freeing pattern storage...\n",
                   MYPATH,
                   element->patterns_filename, cell);
            Gfree(element->odor_effect);
            return 0;
        }

        for (i = 0; i < element->max_odors; i++)
        {
            /*
             * Set the array location to v.
             * Note that odors are 1-indexed, so add 1 to i.
             */

            v = sha->array[i];
            OlfactoryBulb_set_pattern_value(element, cell, i + 1, v);
        }

        free_short_array(&sha);
        cell++;
    }

    fclose(fp);

    if (cell != element->ncells)
    {
        Error();
        printf("olfactory_bulb object: %s: LOADPATTERNS:\n"
               "\tincorrect amount of pattern data in file: %s\n"
               "\tonly read %d lines; expected %d lines.\n",
               MYPATH, element->patterns_filename, cell, element->ncells);
        Gfree(element->odor_effect);
        return 0;
    }

    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     OlfactoryBulb_SHOWPATTERNS
 *
 * DESCRIPTION
 *     Displays information about odor effect response patterns.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_SHOWPATTERNS(struct olfactory_bulb_type *element)
{
    int   i, j;
    short r;

    printf("\nPattern data for olfactory_bulb object: %s\n\n",
           MYPATH);

    ERROR_IF ((element->max_odors == 0)
              || (element->odor_effect == NULL)
              || (element->ncells == 0),
              "olfactory_bulb object: %s: SHOWPATTERNS: "
              "no patterns loaded!\n",
              MYPATH);

    assert_printi(element->max_odors > 0, element->max_odors);
    assert_printi(element->ncells    > 0, element->ncells);

    /*
     * Since there will (almost) always be more cells than patterns, we
     * display the cells on the vertical axis and the pattern info on the
     * horizontal axis.  This means that a given pattern is on a vertical
     * line.
     */

    for (i = 0; i < element->ncells; i++)
    {
        /*
         * For each cell, display which patterns it's a part of.
         */

        printf("Cell: %4d -- ", i);

        for (j = 0; j < element->max_odors; j++)
        {
            /* Odors are 1-indexed so add 1 to j. */
            r = OlfactoryBulb_get_pattern_value(element, i, j + 1);
            printf("%d ", r);
        }

        printf("\n");
    }

    printf("\n");

    return 1;
}




/*
 * FUNCTION
 *     OlfactoryBulb_LOADRATEINFO
 *
 * DESCRIPTION
 *     Loads time-dependent odor response patterns from a file.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * NOTES
 *     Accessing these response patterns uses 1-based indexing,
 *     since pattern 0 just means firing at the background rate
 *     (which is equivalent to the mod values being all 1's).
 *     This is only used for implementing rate coding.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_LOADRATEINFO(struct olfactory_bulb_type *element)
{
    int     i, j;
    FILE   *fp;
    char    line[MAX_LINE_LEN];
    int     npts, nresp;
    double  duration;
    int     linecount = 0;
    double_array *values;
    char    ir;              /* Generic integer return value. */
    char   *sr;              /* Generic char* ("string") return value. */

    PRINT_ENTERT;


    ERROR_IF (element->rate_code == NULL,
              "olfactory_bulb object: %s: OlfactoryBulb_LOADRATEINFO: "
              "rate code struct not initialized.\n",
              MYPATH);

    /* Make sure there is a file to load. */

    ERROR_IF (element->rate_code->filename == NULL,
              "olfactory_bulb object: %s: OlfactoryBulb_LOADRATEINFO: "
              "no odor rate response filename specified.\n",
              MYPATH);

    fp = fopen(element->rate_code->filename, "r");

    ERROR_IF (fp == NULL,
              "olfactory_bulb object: %s: OlfactoryBulb_LOADRATEINFO: "
              "couldn't open odor rate response file: %s\n",
              MYPATH, element->rate_code->filename);

    /*
     * Read in the first line.  It should contain:
     * number_of_odor_responses number_of_time_points total_duration
     */

    sr = fgets(line, MAX_LINE_LEN, fp);

    ERROR_IF (sr == NULL,
              "olfactory_bulb object: %s: LOADRATEINFO: "
              "error reading pattern file: %s, line: %d\n",
              MYPATH,
              element->rate_code->filename, linecount);

    ir = sscanf(line, "%d %d %lg", &nresp, &npts, &duration);

    ERROR_IF (ir != 3,
              "olfactory_bulb object: %s: LOADRATEINFO: "
              "error reading pattern file: %s, line: %d\n"
              "\tshould have had: nresp, npts, duration",
              MYPATH,
              element->rate_code->filename, linecount);

    /* Error checking. */

    ERROR_IF (nresp <= 0,
              "olfactory_bulb object: %s: LOADRATEINFO: "
              "error reading pattern file: %s, line: %d\n"
              "nresp must be > 0",
              MYPATH,
              element->rate_code->filename, linecount);

    ERROR_IF (npts <= 0,
              "olfactory_bulb object: %s: LOADRATEINFO: "
              "error reading pattern file: %s, line: %d\n"
              "npts must be > 0",
              MYPATH,
              element->rate_code->filename, linecount);

    ERROR_IF (duration <= 0.0,
              "olfactory_bulb object: %s: LOADRATEINFO: "
              "error reading pattern file: %s, line: %d\n"
              "duration must be > 0.0",
              MYPATH,
              element->rate_code->filename, linecount);

    element->rate_code->nresp  = nresp;
    element->rate_code->nrespt = npts;
    element->rate_code->tresp  = duration;
    element->rate_code->dt     = duration / npts;

    /*
     * Allocate memory for the array.
     */

    element->rate_code->resp = (double **)calloc((size_t)nresp,
                                                 sizeof(double *));

    for (i = 0; i < nresp; i++)
    {
        element->rate_code->resp[i] = (double *)calloc((size_t)npts,
                                                       sizeof(double));
    }

    /*
     * Load the array.  Check that each line is the right length
     * and has the right contents.  Free the array if an error occurs.
     */

    for (i = 0; i < npts; i++)
    {
        sr = fgets(line, MAX_LINE_LEN, fp);

        if ((sr == NULL) && !feof(fp)) /* Read error. */
        {
            Error();
            printf("olfactory_bulb object: %s: LOADRATEINFO: "
                   "error reading pattern file: %s, line: %d\n",
                   MYPATH,
                   element->rate_code->filename, linecount);
            OlfactoryBulb_free_odor_response_data(element);
            return 0;
        }

        if (feof(fp))
            break;

        /* Read in the values from the line. */

        values = split_line_n_doubles(line, " \t", nresp);

        if (values == NULL) /* Read error. */
        {
            Error();
            printf("olfactory_bulb object: %s: LOADRATEINFO: "
                   "error reading pattern file: %s, line: %d\n"
                   "no tokens found!\n",
                   MYPATH,
                   element->rate_code->filename, linecount);
            OlfactoryBulb_free_odor_response_data(element);
            return 0;
        }

        for (j = 0; j < nresp; j++)
            element->rate_code->resp[j][i] = values->array[j];

        free_double_array(&values);
    }

    /* Make sure we read in the correct number of lines. */

    if (i != npts)
    {
        Error();
        printf("olfactory_bulb object: %s: LOADRATEINFO: "
               "error reading pattern file: %s;\n"
               "total line count %d is less than claimed: %d\n",
               MYPATH,
               element->rate_code->filename, linecount, npts);
        OlfactoryBulb_free_odor_response_data(element);
        return 0;
    }

    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     OlfactoryBulb_PROCESS
 *
 * DESCRIPTION
 *     Checks to see if any cell fires in this time step.
 *     If the outputs are being recorded to a file this happens here.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb_PROCESS(struct olfactory_bulb_type *element)
{
    int     i;
    Msg    *msgin;
    Msg    *msgout;
    double  prob;
    int     odor, conc, resp_type;
    double  mod;        /* Internal modulation of spike rate. */
    double  dt;         /* Simulation time step.    */
    double  time;       /* Current simulation time. */


    odor = element->odor;       /* In case no ODOR message comes in. */
    mod  = 1.0;                 /* Default modulation value. */
    dt   = Clockrate(element);
    time = SimulationTime();


    /* Get incoming messages. */

    MSGLOOP(element, msgin)
    {
    case ODOR:
        odor = MSGVALUE(msgin, 0);
        conc = MSGVALUE(msgin, 1);  /* Not currently used. */

        /*
         * This is a hack.  The odor_in object considers an odor
         * of zero to be "no odor" i.e. background odor.  What this
         * actually corresponds to from the standpoint of the
         * olfactory_bulb object is determined by the contents of
         * the `bg_odor' field, which can be 0 (background spiking)
         * or -1 (no spiking).
         */

        if (odor == 0) /* background odor */
            odor = element->bg_odor;

        break;
    }

    assert_printd(element->odor_time >= 0.0, element->odor_time);


    /*
     * If a new non-background odor has just come on, reset the odor time.
     * Otherwise, if a non-background odor is on, increment the odor_time
     * field.  Note that the "blocked nostril" odor (odor = -1) is
     * considered as a real odor for this purpose.
     */

    if (odor != element->odor)
    {
        /*
         * A new odor has come on.  Check that the odor is OK.
         */

        ERROR_IF ((odor < -1) || (odor > element->max_odors),
                  "olfactory_bulb object: %s: PROCESS: "
                  "input odor #%d is out of range!\n",
                  MYPATH, odor);

        element->new_odor = 1;

        /*
         * Set odor fields based on new odor information.
         */

        element->odor       = odor;
        element->odor_start = time;
        element->odor_time  = 0.0;

#ifdef DEBUG
        printf("olfactory_bulb.c: Odor %d came on at time %g\n",
               element->odor, time);
#endif
    }
    else
    {
        element->new_odor = 0;  /* Not a new odor. */
    }

    /*
     * CHECKME: I can't guarantee that this will work if bg_odor is -1
     * and you have an odor number 0.
     */

    if (element->odor != element->bg_odor)
    {
        /* Set odor time information. */

        element->odor_time = time - element->odor_start;
    }

    assert_printd(element->odor_time >= 0.0, element->odor_time);


    /*
     * Check for new spikes in the mitral cell array.
     */

    /* If odor = -1, then there are no spikes, so just return. */

    if (element->odor == -1)
    {
        CHECK_INVARIANT;
        return 1;  /* CHECKME: should we make return void? */
    }


    /* Otherwise, set cells to non-spiking by default. */

    for (i = 0; i < element->ncells; i++)
        element->cell[i].spiking = 0;


    /* If odor = 0 (no odor), then just emit background spikes. */

    if (element->odor == 0)
    {
        for (i = 0; i < element->ncells; i++)
        {
            if (element->mod_index >= 0)
            {
                prob = Spikeprob_get_spike_prob(
                    element->isi,
                    time,
                    dt,
                    element->cell[i].last_spike_time,
                    nm[element->mod_index]);
            }
            else
            {
                prob = Spikeprob_get_spike_prob(
                    element->isi,
                    time,
                    dt,
                    element->cell[i].last_spike_time,
                    1.0);  /* No neuromodulation. */
            }

            if (random_hit(prob))  /* The cell fires a spike. */
                element->cell[i].spiking = 1;
        }
    }
    else
    {
        /*
         * Otherwise, figure out which cells spike based on the coding
         * mode.
         */

        switch (element->coding_mode)
        {
        case RATE_CODING:
            /*
             * Find the closest time index into the response arrays.  This
             * can be anywhere in the range
             * (0, element->rate_code->nrespt - 1). Having this here speeds
             * up interpolation considerably.
             */

            ERROR_IF (element->odor_time >= element->rate_code->tresp,
                      "olfactory_bulb object: %s: PROCESS: "
                      "odor_time %g is >= maximum: %g\n",
                      MYPATH,
                      element->odor_time, element->rate_code->tresp);

            /*
             * NOTE: the value of element->rate_code->curr_index is used
             *       by the get_odor_response() function.
             */

            element->rate_code->curr_index =
                floor((element->odor_time / element->rate_code->tresp)
                      * ((double)element->rate_code->nrespt));

            for (i = 0; i < element->ncells; i++)
            {
                mod = 1.0;

                /*
                 * Change the mod value depending on the rate coding
                 * parameters.
                 */

                assert(element->odor > 0);

                resp_type =
                    (int)OlfactoryBulb_get_pattern_value(element, i,
                                                         element->odor);

                assert(resp_type >= 0);

                /*
                 * If resp_type == 0, don't change the mod value; it's
                 * just background firing.
                 */

                if (resp_type > 0)
                {
                    mod = OlfactoryBulb_get_odor_response(element,
                                                          resp_type);
                }

#ifdef DEBUG0
                ERROR_IF (isnan(mod) == 1,
                          "olfactory_bulb object: %s: PROCESS: "
                          "mod value %g is not a number!\n",
                          MYPATH, mod);
#endif

                if (element->mod_index >= 0)
                {
                    prob = Spikeprob_get_spike_prob(
                        element->isi,
                        time,
                        dt,
                        element->cell[i].last_spike_time,
                        mod * nm[element->mod_index]);
                }
                else
                {
                    prob = Spikeprob_get_spike_prob(
                        element->isi,
                        time,
                        dt,
                        element->cell[i].last_spike_time,
                        mod);
                }

                if (random_hit(prob))  /* The cell fires a spike. */
                    element->cell[i].spiking = 1;
            }

            break; /* RATE_CODING */


        case SYNCHRONY_CODING:
            if (element->mod_index >= 0)
            {
                Sync_update(element->sync_code, element, time, dt,
                            nm[element->mod_index]);
            }
            else
            {
                Sync_update(element->sync_code, element, time, dt, 1.0);
            }

            break;  /* SYNCHRONY_CODING */


        case NO_CODING:
            /* Emit background spikes. */

            for (i = 0; i < element->ncells; i++)
            {
                if (element->mod_index >= 0)
                {
                    prob = Spikeprob_get_spike_prob(
                        element->isi,
                        time,
                        dt,
                        element->cell[i].last_spike_time,
                        nm[element->mod_index]);
                }
                else
                {
                    prob = Spikeprob_get_spike_prob(
                        element->isi,
                        time,
                        dt,
                        element->cell[i].last_spike_time,
                        1.0);  /* No neuromodulation. */
                }

                if (random_hit(prob))  /* The cell fires a spike. */
                    element->cell[i].spiking = 1;
            }

            break;


        default:
            ERROR ("olfactory_bulb object: %s: PROCESS: "
                   "coding_mode %d is not defined.\n",
                   MYPATH, element->coding_mode);

            /*NOTREACHED*/
            break;
        }
    }


    /*
     * Deal with all spikes that have occurred.
     */

    for (i = 0; i < element->ncells; i++)
    {
        if (element->cell[i].spiking)
        {
            /* Send event to destination element. */
            msgout = element->cell[i].msgout;

            if (msgout != NULL)
            {
#ifdef DEBUG
                printf("olfactory_bulb object: %s: "
                       "sending a SPIKE message at time %.10g to %s\n",
                       MYPATH, time,
                       Pathname(msgout->dst));
#endif
                CallEventAction((Element *)element, msgout);
            }

            /*
             * If recording output, write the spike time to the output
             * file.  Print the cell number as well.  They should be in
             * the given order to make it easier to generate scatter
             * plots.
             */

            if (element->output->enabled)
            {
                fprintf(element->output->file, "%f\t%d\n",
                        time, i);

                if (element->output->flush)
                    fflush(element->output->file);
            }

            /* Record the time of this spike. */

            RC(i, element->ncells);
            element->cell[i].last_spike_time = time;
        }
    }

    CHECK_INVARIANT;

    return 1; /* CHECKME: should we make return void? */
}





/**********************************************************************/

/*
 * OBJECT
 *     olfactory_bulb
 *         This object is an array of spike generators that generate
 *         spikes according to a user-defined ISI distribution.
 *
 * FUNCTION
 *     OlfactoryBulb
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *element -- address of element
 *     Action *action                      -- address of action
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
OlfactoryBulb(struct olfactory_bulb_type *element, Action *action)
{
    int result = 1;

    switch (action->type)
    {
    case CREATE:
        /* Set up defaults. */

        result = OlfactoryBulb_CREATE(element);

        break;


    case DESTROY:
        /* Deallocate memory, close files etc. */

        OlfactoryBulb_DESTROY(element);

        break;


    case INITIALIZE:
        /* Initialize ISI distribution and cell array. */

        result = OlfactoryBulb_INITIALIZE(element);

        break;


    case RESET:

        result = OlfactoryBulb_RESET(element);

        break;


    case PROCESS:

        result = OlfactoryBulb_PROCESS(element);

        break;


    case ADDMSGOUT:
        /* Extra code when adding a SPIKE message. */

        result = OlfactoryBulb_ADDMSGOUT(element, action);

        break;


    case DELETEMSGOUT:
        /* Extra code when deleting a SPIKE message. */

        result = OlfactoryBulb_DELETEMSGOUT(element, action);

        break;


    case CHECK:

        result = OlfactoryBulb_CHECK(element);

        break;


    case MSGINFO:
        /* Print data about messages. */

        OlfactoryBulb_MSGINFO(element);

        break;


    case LOADPATTERNS:
        /* Load odor effect patterns from file. */

        result = OlfactoryBulb_LOADPATTERNS(element);

        break;


    case SHOWPATTERNS:
        /* Display pattern data. */

        result = OlfactoryBulb_SHOWPATTERNS(element);

        break;


    case INITRATEINFO:
        /* Initialize rate coding struct. */

        result = OlfactoryBulb_INITRATEINFO(element);

        break;


    case LOADRATEINFO:
        /* Load rate coding odor response patterns from file. */

        result = OlfactoryBulb_LOADRATEINFO(element);

        break;


    case LOADSYNCINFO:
        /* Initialize synchrony coding data. */

        result = Sync_init(element->sync_code, element);

        break;


    default:

        InvalidAction("olfactory_bulb", (Element *)element, action);
        result = 0;

        break;
    }


    return result;
}

