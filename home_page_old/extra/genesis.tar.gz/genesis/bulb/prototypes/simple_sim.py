#! /usr/bin/env python

#
# simple_sim.py: a simple class which implements a simple simulation engine.
#                This is so that prototype code doesn't have to worry
#                about stuff normally taken care of by the rest of
#                genesis.
#

import sys, string
from whrandom import uniform

class sim:
    """The sim class:

This class is a simple simulation class that calls the sync_data class
and updates the time step of the simulation.  It also reads a file of
odor onset/offset times to determine which odor (if any) is on, and
how long it has been on.
    """

    def __init__(self, dt, verbose = 0):
        self.verbose       = verbose   # Print extra debugging information.
        self.t             = 0.0
        self.dt            = dt
        self.odor_on       = 0        # Flag: is there an odor on?
        self.odor          = 0        # ... and if so, which odor is it?
        self.odor_start    = 0.0      # When the most recent odor came on.
        self.odor_time     = 0.0      # How long the most recent odor has been on.
        self.odor_end      = 0.0      # When the most recent odor will go off.
        self.odor_events   = []       # List of odor time events: (odor,on,off)

    def load_odors(self, filename):
        """Load a list of odor events from a file.
These take the form of (odor, onset, duration) triples.  The offset of each
odor must occur before the onset of the next.  All odors must start
after time = 0.0.
"""
        lines = open(filename, 'r').readlines()
        odor_end = 0.0
        for line in lines:
            words  = string.split(line)
            odor   = string.atoi(words[0])
            onset, duration = map(string.atof, words[1:])
            offset = onset + duration
            assert(1 <= odor <= 9)  # This is a genesis-related hack.
            assert(offset > onset)
            assert(odor_end < onset)
            self.odor_events.append((odor, onset, offset))
            odor_end = offset

    def update_odor(self, t):
        """Update odor status.  
Check to see if a new odor has just come on or an old one gone off.  
Set odor variables to the correct values.  If an old odor is no
longer applicable then remove it from the event list."""
        if self.odor == 0:  # No odor is on currently.
            if self.odor_events == []:  # No more odors.
                return

            # Has the next odor come on?
            if t >= self.odor_events[0][1]: # Yes.
                self.odor_on = 1
                self.odor, self.odor_start, self.odor_end = self.odor_events[0]
                self.odor_time = 0.0
                self.odor_events = self.odor_events[1:]  # Pop first event.
                if self.verbose:
                    sys.stdout.write("Odor %d on at time %g\n" % (self.odor, t))
            return
        else:  # An odor is on.
            # Has the odor gone off?
            if t > self.odor_end: # Yes
                if self.verbose:
                    sys.stdout.write("Odor %d off at time %g\n" % (self.odor, t))
                self.odor_on = 0
                self.odor_time = 0.0
                self.odor, self.odor_start, self.odor_end = 0, 0.0, 0.0
            else:
                self.odor_time = t - self.odor_start
                assert(self.odor_time >= 0.0)
        # End of update_odor

            

    def update(self):
        self.t = self.t + self.dt 
        self.update_odor(self.t)

    # End of class sim.


#
# Test routine:
#

if __name__ == "__main__":
    dt      = 0.000020  # 20 usec
    ncells  = 100
    width   = 0.020
    tmax    = 5.0
    
    s = sim(dt)
    s.verbose = 1
    s.load_odors("sync_odor_events")

    while s.t < tmax:
        s.update()



