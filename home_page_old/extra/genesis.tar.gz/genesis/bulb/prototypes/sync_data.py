#
# sync_data.py: A second prototype of the implementation of a spike generator
#               which generates synchronized spikes for use in genesis.
#               The distinguishing feature of this version is that there is
#               now support for different odors which can produce different
#               events.  Among other things, this means that the spike event 
#               list is really a 2-D array.
#

#
# NOTES:
#
# The same odor ALWAYS generates the same sequence of firing events except
# for the probabilistic stuff.  This is a limitation, but one I can live
# with.  For an alternative you can use the random event generating
# mechanism, which is the other extreme :-)
#
# Synchrony duration ('sync_duration') will be a fixed parameter in
# genesis, because the randomness of the spiking process will make it
# effectively variable enough.  I could make it modulatable, but why bother?
#

#
# TODO -- genesis
#
# -- Change the facility for sync'ing spikes to a random series of events;
#    here these are Poisson-distributed events; in the real genesis model
#    they will be ISIs selected from the usual ISI distribution.  This will
#    involve changing some parameters (described below).
#
# -- Add background spiking for cells that aren't sync'ed to an event
#    stream.  There's no point in doing this here because the form
#    of the solution would be totally different in genesis.
#



import sys, string, struct
from whrandom import uniform
from Numeric import array, transpose

class sync_data:
    """The sync_data class:

    This class implements an array of spike generators that synchronize
    their outputs to spike events from a set of hypothetical reference
    cells.  Spike event sequences "from" the reference cell are either read
    in from a file or generated randomly.  A separate file is read in to
    determine how each cell responds to each odor (i.e. with which
    reference cell spike event sequence or with the background spiking
    response).  After each spike event, each active cell (i.e. those not
    exhibiting the background spiking response) probabilistically chooses
    if it will respond to the event.  If so, it uses a Poisson spiking
    probability (i.e. a fixed probability per time step) to choose whether
    or not it spikes at any given time step.  Once it spikes, it does not
    spike again until the next reference cell spike event occurs.  If it
    does not respond to the spike event it will spike in accordance with
    the background spiking pattern (in genesis, but not here).  The
    reference cell spike event sequences last a certain time and then stop;
    they can't go beyond the duration of the odor but may end sooner.  If
    they do end before the odor goes off the previously-synchronized cells
    then spike in accordance with the background spiking pattern.

    """

    def __init__(self):
        """Initialize the sync_data object."""

        # Note that "width" stands (roughly) for the average width of the
        # distribution of spikes following the event.  Actually it
        # represents the time at which the 1/e point of the ISI
        # distribution is reached.

        #
        # Note on sync_modes:
        # ------------------
        #
        #     In sync_mode 0:
        #         Each cell can respond to a given odor with a given sequence of
        #         events.  The particular event sequences are read in from a file.
        #         Another file is read in containing the responses of each cell
        #         to each odor.  The responses have to be integers in the range
        #         0-9; 0 means "background response" i.e. no change.  Each number
        #         represents a given spike sequence.  Thus only 8 distinct non-
        #         background response patterns are possible. 
        #
        #     In sync_mode 1:
        #         The events are generated randomly according to a particular
        #         probability distribution (here Poisson; in genesis the ISI
        #         distribution of the cell).  The cell responses are read in
        #         from a file as in sync_mode 0.  In this mode all nonzero
        #         numbers are equivalent; the only distinction is between 0
        #         and nonzero.
        #


        #
        # Data members:
        #

        # General:
        # -- scalars:
        self.verbose          =  0    # Print extra debugging information.
        self.sync_mode        =  0    # 0 = read events from file;
                                      # else generate events probabilistically.
        self.ncells           =  0    # Number of cells.
        self.odor_on          =  0    # Flag for whether the odor is on or not.
        self.event_prob       =  1.0  # Probability of responding to an event.
        self.width            =  0.0  # Parameter to use to calculate spikeprob.
        self.dt               =  0.0  # Simulation time step.
        self.spikeprob        =  0.0  # Spike probability for each time step.
        self.nevent_seqs      =  0    # Number of distinct event sequences.
        self.sync_duration    = -1.0  # Duration of synchrony;
                                      # (sync_duration < 0) => as long as the odor is on.
        # -- 2D arrays: 
        self.spiked           = []    # Flags: have the cells which responds to a
                                      # given sequence spiked? (nseqs * ncells)
        self.active           = []    # With which event sequence do the cells
                                      # respond to the odors? (nodors * ncells)
                                            
        # Sync_mode 0 only (read sync events from file):
        # -- 1D arrays: each of length nevent_seqs
        self.next_event_index = []    # Index of next event for each sequence.
        self.current_event    = []    # Current event of each sequence.
        self.next_event       = []    # Next event of each sequence.
        # -- 2D arrays:
        self.event            = []    # Time (relative to odor onset) of spike events
                                      # in a sequence (nseqs * nevents).
        
        # Sync_mode 1 only (generate sync events probabilistically):
        # -- scalars:
        #    -- These are not going to be in the genesis version;
        #       use a simple Poisson generator to get events.
        self.sync_mode_1_rate = 0.0   # Rate of random "event" firings.
        self.sync_mode_1_prob = 0.0   # Event occurrence probability.
                
        # End method __init__().
        

    def init2(self):
        """Basic initialization of the event after all fields are
        specified by the user.  This will be called in a RESET action
        in genesis."""
        
        self.spikeprob = self.dt / self.width  # Spike probability for each time step.
        self.load_odor_activities()            

        if self.sync_mode == 0:                
            self.load_events()  # Load events from file.
        else:  # sync_mode 1: use Poisson generator to generate events.
            self.sync_mode_1_prob = self.sync_mode_1_rate * self.dt # N.B. not in genesis.
            self.nevent_seqs = 1  # HACK: this is a place-holder.
            assert(0.0 <= self.sync_mode_1_prob <= 1.0)
        
        # End method init2().


    def load_events(self):
        """Read in the list of spike event sequences from a file.

        Each event represents a time >= 0 after the onset of an odor and
        each event must occur after the preceding one in the same sequence.

        The format of the input file is: each *column* contains one
        distinct spike sequence.  Columns are padded with -1.0's to make
        the entire file equivalent to a 2D array.  This is mainly to
        simplify the file format and the file reading code.
        
        """

        assert(self.sync_mode == 0)  # This function is not needed for sync_mode 1.

        file      = open(self.events_filename, 'r')
        vals      = []    # The spike event sequences.
        first     = 1     # Flag for first line read.
        maxspikes = 0     # Maximum number of spikes in a sequence (computed).

        # Read in the spike event sequences.
        while 1:
            line = file.readline()
            if not line:
                break

            # N.B. define a C function equivalent to string.split, please!!!
            # Convert number strings to floats.
            words = string.split(line)
            numbers = []
            for word in words:
                numbers.append(string.atof(word))
                               
            if first:  # First line read.
                nseqs = len(numbers) # Number of odor responses for the cell.
                assert(nseqs < 9)    # Allow only up to 8 distinct sequences.
                first = 0
            else:
                # Make sure that all lines have the same number of numbers.
                assert(len(numbers) == nseqs)
                
            vals.append(numbers)  # Collect numbers in the 2D array vals.
            maxspikes = maxspikes + 1

        # Now each column is a single spike sequence.
        # Swap rows and columns in vals.  
        # Convert to/from an array; it's easier.
        # N.B. This should be a separate transpose() function in C.

        vals = map(list, transpose(array(vals)))  # Tricky code alert :-)

        # Now each *row* is a spike sequence (this is easier to manipulate).
        # Check that the spike sequences are valid.
        
        self.check_spike_sequences(vals, nseqs, maxspikes)

        self.event = vals
        self.nevent_seqs = nseqs
        file.close()

        # End method load_events().


    def check_spike_sequences(self, vals, nseqs, maxspikes):
        """Check that the array of spike events sequences read in from
        a file are valid (sync_mode 0 only)."""

        assert(self.sync_mode == 0)
        
        last = [-1.0] * nseqs  # Temporary storage for the last event in each sequence.

        for seq in range(nseqs):
            assert(len(vals[seq]) == maxspikes)
            for spike in range(maxspikes):
                # Make sure that the previous spike in each spike sequence 
                # occurred before the current one.  If a negative number is 
                # reached, the sequence is finished.
                if vals[seq][spike] < 0.0:
                    break
                
                assert(vals[seq][spike] > last[seq])
                last[seq] = vals[seq][spike]
                
        # End method check_sequences()
        

    def init_events(self):
        """Initialize the synchronization events (sync_mode 0 only)."""

        assert(self.sync_mode == 0)
        
        self.current_event    = [-1.0] * self.nevent_seqs  # Marker for no event.
        self.next_event       = [-1.0] * self.nevent_seqs
        self.next_event_index = [0] * self.nevent_seqs
        
        for i in range(self.nevent_seqs):
            self.get_next_event(i)         # Get the first events in each sequence.

        # End method init_events().


    def get_next_event(self, seq):
        """Get next spike event from sequence 'seq' (sync_mode 0 only).
        Make previous 'next_event' the current event.
        """
        
        assert(self.sync_mode == 0)
        assert(0 <= seq < self.nevent_seqs)
        self.current_event[seq] = self.next_event[seq]
        
        try:
            self.next_event[seq]       = self.event[seq][self.next_event_index[seq]]
            self.next_event_index[seq] = self.next_event_index[seq] + 1
        except IndexError:  # No more events in sequence 'seq'.
            self.next_event[seq]       = -1.0   # Marker for no event.
            self.next_event_index[seq] = -1     # Marker for no event.

        if self.verbose:
            sys.stdout.write("next event[%d]: %g\n" % (seq, self.next_event[seq]))
            sys.stdout.flush()

        # End method get_next_event().
                        

    def load_odor_activities(self):
        """Read in the list of odor activities.

        Each activity is an integer > zero, corresponding to the index of
        the spike event sequence that it synchronizes to, or zero, which
        represents background firing.
        
        """

        self.active = []  # Initialize 2D array (nodors * ncells).
        file  = open(self.activities_filename, 'r')
        first = 1  # Flag for first string read.

        while 1:
            line = file.readline()
            if not line:
                break

            # Each line contains the response of a given cell to all odors.
            # Remove leading and trailing whitespace and newline.
            # N.B. make l,rstrip function(s) in C.
            line = string.lstrip(string.rstrip(line))  
            
            if first:
                self.nodors = len(line)
                first = 0
            else:
                # All lines must be the same length.
                assert(len(line) == self.nodors)

            # Read the line as a list of one-char integers.
            vals = map(string.atoi, struct.unpack('c' * self.nodors, line))
            for val in vals:
                assert(0 <= val <= 9)       
            self.active.append(vals)
            
        # Transpose 'self.active'.
        self.active = map(list, transpose(array(self.active)))
        file.close()

        # End method load_odor_activities().


    def clear_spiked_flags(self):
        """Set the spiked flags to zero (sync_mode 0 only)."""
        
        # NOTE: *EACH* *SEQUENCE* has its own set of spiked flags.  Cells
        # that aren't part of that sequence have these flags set to 1 for
        # the duration of the sequence.
        
        self.spiked = [None] * self.nevent_seqs
        
        for i in range(self.nevent_seqs):
            # N.B. define an array_fill() function in C.
            self.spiked[i] = [0] * self.ncells

        # End method clear_spiked_flags().


    def init_spiked_flags(self, odor, seq, random):
        """Set the spiked flags for a given odor and pre-set event sequence.

        This function is for sync_mode 0 only.  Set the 'spiked' flags to 1
        for the cells that won't be responding to this odor with this
        sequence.  Set the rest to 0.  Note that cells that don't respond
        to this odor with this sequence can still respond to this odor with
        a different sequence or can spike in background mode.  This
        function also takes into account probabilistic responses to an
        event.
        
        """

        assert(0.0 <= self.event_prob <= 1.0)
        assert(odor >= 0)
        
        for cell in range(self.ncells):
            if random:  # Use randomly generated spike event sequences.
                # If the 'active' value is nonzero it's considered to be
                # in the sequence; if it is 0 it means background firing.
                not_in_seq = (self.active[odor][cell] == 0)
            else:       # Use spike event sequences read in from file.
                # Add one to seq when comparing it to the 'active' values
                # because an 'active' value of 0 means background firing.
                not_in_seq = (self.active[odor][cell] != (seq + 1))
                
            # Set the 'spiked' flag to 1 if the cell isn't part of this
            # sequence for this odor or if it is randomly chosen not
            # to respond.
            if not_in_seq or (uniform(0.0, 1.0) <= (1.0 - self.event_prob)):
                self.spiked[seq][cell] = 1  # The cell has (conceptually) already "spiked".
            else:
                self.spiked[seq][cell] = 0  # The cell is ready to spike.

        if self.verbose:
            self.print_spiked(seq)
            
        # End method init_spiked_flags().


    def get_random_sync_prob(self, last_spike_time, current_time):
        """Return the probability of a random synchronization event
        occurring.
        """

        # TODO -- genesis.
        # This is trivial here because we're just generating a Poisson
        # sequence.  It'll be more involved in genesis, and will use
        # the last_spike_time and current_time values, of course.

        return self.sync_mode_1_prob

        # End method get_random_sync_prob().


    def spike_notify(self, cell, time):
        """Do whatever needs to be done when a spike occurs."""

        # TODO -- genesis: this will be totally different, of course.
        sys.stdout.write("%g\t%d\n" % (time, cell))
        sys.stdout.flush()

        # End method spike_notify().
        

    #
    # Print functions, for debugging.
    #

    def print_spiked(self, seq):
        """Print the 'spiked' flags of the 'seq'th sequence."""

        sys.stdout.write("Sequence %d: " % seq)
        
        for cell in range(len(self.spiked[seq])):
            sys.stdout.write("%s" % self.spiked[seq][cell])
            
        sys.stdout.write("\n")
        sys.stdout.flush()

        # End method print_spiked().


    def print_active(self):
        """Print the 'active' flags for all cell/odor pairs."""
        
        for odor in range(len(self.active)):
            for cell in range(len(self.active[odor])):
                sys.stdout.write("%s" % self.active[odor][cell])
            sys.stdout.write("\n")
            sys.stdout.flush()
            
        # End method print_active().


    def update_cells(self, seq, time):
        """Determine which cells spike after an event."""

        for cell in range(self.ncells):
            if not self.spiked[seq][cell]:
                # Does the cell spike this time step?
                if uniform(0.0, 1.0) < self.spikeprob:
                    # The cell spikes!
                    self.spike_notify(cell, time)
                    self.spiked[seq][cell] = 1
                    
        # End method update_cells().


    def update_sync_mode_0(self, odor, odor_time, time):
        """Update procedure for sync_mode 0.

        This function is called when an odor is on to determine
        which of the active cells spike if any."""

        assert(self.sync_mode == 0)

        odor = odor - 1  # Correct the odor number for 1-based indexing.
       
        for seq in range(self.nevent_seqs):
            # Are there any new events wrt this spike sequence this time step?
            # If so, initialize the spiked flags for the sequence.                
            if (self.next_event[seq] >= 0.0) and \
               (odor_time >= self.next_event[seq]): # There is a new event.
                self.get_next_event(seq)
                # 'next_event[seq]' is now 'current_event[seq]'
                self.init_spiked_flags(odor, seq, 0)
                
            # Does any cell spike this time step?
            if (self.current_event[seq] >= 0.0) and \
               (odor_time >= self.current_event[seq]):  # An event has occurred previously.
                self.update_cells(seq, time)

        # End method update_sync_mode_0().


    def update_sync_mode_1(self, odor, odor_time, time):
        """Update procedure for sync_mode 1.

        This function is called when an odor is on to determine
        which of the active cells spike if any."""

        assert(self.sync_mode == 1)

        odor = odor - 1  # Correct the odor number for 1-based indexing.

        # Is there a new event this time step?
        # If so, initialize the spiked flags for the sequence.
        # HACK: use current_event[0] for the time of the last random event.
        if uniform(0.0, 1.0) < self.get_random_sync_prob(self.current_event[0], time):
            # A new event occurs!
            self.current_event[0] = time
            self.init_spiked_flags(odor, 0, 1)

        # Does any cell spike this time step?
        if (self.current_event[0] >= 0.0):  # An event has occurred.
            self.update_cells(0, time)

        # End method update_sync_mode_0().



    #
    # Main update function.
    #

    def update(self, time, odor_on, odor, odor_time):
        """Figure out which cells spike if this time step
        and take appropriate action."""

        # Has the odor just switched off?
        if self.odor_on and not odor_on:
            if self.verbose:
                print "odor %d off at time %g" % (odor, time)
            self.odor_on = 0
            return

        # Has the odor just switched on?
        if odor_on and not self.odor_on:
            if self.verbose:
                print "odor %d on at time %g" % (odor, time)
            self.odor_on = 1
            self.clear_spiked_flags()
            
            if self.sync_mode == 0:  # Use sync events from file.
                self.init_events()
            else:                    # Generate random sync events.
                # HACK: just create and use position 0 in current_event array.
                self.current_event = [-1.0]

        # If the odor is off, just generate "background odor" spikes.
        if not odor_on:
            assert(odor == 0)
            # TODO -- genesis: add background spiking functionality to this.
            return

        # Has the odor been on longer than the sync_duration?
        if self.sync_duration >= 0.0 and odor_time > self.sync_duration:
            # TODO -- genesis: switch to background spikes.
            return

        assert(odor > 0)
        
        if self.sync_mode == 0:  # Use synchronization events from file.
            self.update_sync_mode_0(odor, odor_time, time)
        else:  # Generate random synchronization events.
            self.update_sync_mode_1(odor, odor_time, time)

        # End method update().

    # End class sync_data.



