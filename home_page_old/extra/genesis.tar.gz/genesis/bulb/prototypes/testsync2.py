#! /usr/bin/env python

#
# testsync2b: a test of a prototype of a method for synchronizing
#             spikes from the olfactory_bulb object in genesis.
#

import pdb, profile
import sys, string
from sync_data  import *
from simple_sim import *

profile = 0

def run_sim():
    #
    # Parameters:
    #
    
    verbose = 0         # Gives extra print information.
    dt      = 0.000020  # 20 usec
    ncells  = 100
    width   = 0.002
    tmax    = 5.0

    # Main body of simulation:
    
    s = sim(dt, verbose)
    s.verbose = verbose
    s.load_odors("sync_odor_events")

    sync = sync_data()
    sync.ncells    = ncells
    sync.dt        = dt
    sync.width     = width
    sync.verbose   = verbose
    sync.sync_mode = 0
    sync.sync_duration       = -1.0  # seconds; negative values = as long as odor is on.
    # For sync_mode 0:
    sync.events_filename     = "sync_spike_events"
    # For sync_mode 1:
    sync.sync_mode_1_rate    = 40.0   # Hz
    sync.activities_filename = "sync_activities4"
    sync.event_prob = 0.9
    sync.init2()

    s.update()
    sync.update(s.t, s.odor_on, s.odor, s.odor_time)


    while s.t < tmax:
        if verbose:
            if (int(round(s.t * 100000)) % 10000 == 0):
                sys.stdout.write("time = %g\todor = %d\todor_on = %d\n" % \
                                 (s.t, s.odor, s.odor_on))
                sys.stdout.flush()
        s.update()
        sync.update(s.t, s.odor_on, s.odor, s.odor_time)
    

if profile:
    profile.run('run_sim()', 'syncprof')
else:
    run_sim()
