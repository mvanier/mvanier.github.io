/*
 *
 * FILE: spikeprob.h
 *     Interface for the spikeprob.c file.
 *
 * AUTHOR: Mike Vanier
 *
 */

#ifndef SPIKEPROB_H
#define SPIKEPROB_H

extern struct spikeprob_type *
Spikeprob_create(Element *parent);

extern void
Spikeprob_destroy(struct spikeprob_type **sp);

extern int
Spikeprob_load(struct spikeprob_type *sp, Element *parent);

extern double
Spikeprob_get_spike_prob(struct spikeprob_type *sp,
                         double t, double dt, double last,
                         double mod);

extern double
Spikeprob_get_random_ISI(struct spikeprob_type *sp, double mod);

extern int
Spikeprob_check(struct spikeprob_type *sp, Element *parent);

#endif /* SPIKEPROB_H */

