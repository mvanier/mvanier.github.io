/*
 *
 * FILE: sync.h
 *       Interface for the code which implements spike synchronization
 *       among active mitral cells.
 *
 * AUTHOR: Mike Vanier
 *
 */

extern struct sync_coding_data *
Sync_create(struct olfactory_bulb_type *parent);

extern void
Sync_destroy(struct sync_coding_data **sync);

extern int
Sync_init(struct sync_coding_data *sync,
          struct olfactory_bulb_type *parent);

extern void
Sync_update(struct sync_coding_data *sync,
            struct olfactory_bulb_type *parent,
            double time, double dt, double mod);




