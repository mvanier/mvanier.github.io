/*
 *
 * FILE: spikebuffer.c
 *
 *     This file contains the definition of the spikebuffer object,
 *     which is used to interface the olfactory_bulb object to the
 *     rest of the genesis simulation.  Specifically, we set up the
 *     olfactory_bulb object so each "mitral cell" sends exactly one
 *     outgoing message to a spikebuffer object, which then sends messages
 *     to the rest of the simulation.  This allows us to use the
 *     usual planar/volumeconnect commands etc. to set up the connectivity
 *     between the bulb and the cortex.  The main issue is that for
 *     the spikes to be delivered at the correct time the spikebuffer
 *     object has to be simulated later in the schedule than the
 *     olfactory_bulb object.
 *
 *     Alternatively, we could always just send messages directly from the
 *     olfactory_bulb object directly to the receiving object(s), but then
 *     we couldn't use planar/volumeconnect etc. to set up aggregate
 *     connection patterns, so the bookkeeping is worse.
 *
 * AUTHOR: Mike Vanier
 *
 */


#include "bulb_ext.h"


/*
 * OBJECT
 *     spikebuffer
 *         This object is a utility object to manage the fanout of
 *         synaptic connections from a single "mitral cell" from
 *         the olfactory_bulb object.
 *
 * FUNCTION
 *     SpikeBuffer
 *
 * ARGUMENTS
 *     struct spikebuffer_type *element -- address of element
 *     Action                  *action  -- address of action
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
SpikeBuffer(struct spikebuffer_type *element,
            Action *action)
{
    Msg    *msg, *msgout;
    int     mcount, smcount;
    int     result = 1;

    switch (action->type)
    {
    case RESET:
        /* Nothing! */

        break;


    case CHECK:
        /*
         * Make sure there is only ONE incoming message, and that
         * it's a SPIKE message.
         */

        mcount = 0;
        smcount = 0;

        MSGLOOP(element, msg)
            {
            case SPIKE:
                smcount++;
                mcount++;
                break;

            default:
                mcount++;
                break;
            }

        ERROR_IF (mcount != smcount,
                  "Spikebuffer object: %s: CHECK: "
                  "not all incoming messages are SPIKE messages!\n",
                  MYPATH);

        ERROR_IF (smcount > 1,
                  "Spikebuffer object: %s: CHECK: "
                  "maximum of one incoming SPIKE message permitted.\n",
                  MYPATH);

        /*
         * Check that all outgoing messages are SPIKE messages.
         */

        mcount = 0;
        smcount = 0;

        MSGOUTLOOP(element, msgout)
            {
                mcount++;

                if (msgout->type == SPIKE)
                    smcount++;
            }

        ERROR_IF (mcount != smcount,
                  "Spikebuffer object: %s: CHECK: "
                  "not all outgoing messages are SPIKE messages!\n",
                  MYPATH);

        break;


    case ADDMSGIN:
        /* Check that incoming message to be added is a SPIKE message. */

        msg = (Msg *) action->data;

        ERROR_IF (msg->type != SPIKE,
                  "Spikebuffer object: %s: ADDMSGIN: "
                  "attempted to add a non-SPIKE incoming message.\n",
                  MYPATH);

        break;


    case ADDMSGOUT:
        /* Check that outgoing message to be added is a SPIKE message. */

        msgout = (Msg *) action->data;

        ERROR_IF (msgout->type != SPIKE,
                  "Spikebuffer object: %s: ADDMSGIN: "
                  "attempted to add a non-SPIKE outgoing message.\n",
                  MYPATH);

        break;


    case EVENT:

        /*
         * This action is executed when a spike occurs at any of the
         * spikegen elements which are presynaptic to the synchan.
         */

#ifdef DEBUG
        printf("spikebuffer object: %s: "
               "received a spike event at time %.10g.\n",
               MYPATH, SimulationTime());
#endif

        /* Send event to destination elements */

        MSGOUTLOOP(element, msgout)
            {
                CallEventAction((Element *)element, msgout);
            }

        break;


    case PROCESS:
        /* Nothing! */

        break;


    default:

        InvalidAction("spikebuffer", (Element *)element, action);
        result = 0;
        break;
    }

    return result;
}


