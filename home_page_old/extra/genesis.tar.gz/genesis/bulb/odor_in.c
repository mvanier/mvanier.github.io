/*
 *
 * FILE: odor_in.c
 *
 *     This file contains the definition of the odor_in object,
 *     which is used to generate odor patterns for the use of
 *     the olfactory_bulb object.
 *
 * AUTHOR: Mike Vanier
 *
 */


#include "bulb_ext.h"

/*
 * Thresholds; these represent five time constants of exponential
 * decay to 0 or five time constants of exponential increase to 1.
 */

#define LOWER_THRESHOLD 0.00673794699909
#define UPPER_THRESHOLD 0.993262053001


/*
 * FUNCTION
 *     Odor_in_clear_next_odor_info
 *
 * DESCRIPTION
 *     Clears all information about the next odor from the object.
 *
 * ARGUMENTS
 *     struct odor_in_type *element -- address of element
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Odor_in_clear_next_odor_info(struct odor_in_type *element)
{
    /* FIXME: these next two lines should be elsewhere. */
    element->odor = 0;
    element->conc = 0.0;

    element->next_odor->odor     = 0;
    element->next_odor->onset    = 0.0;
    element->next_odor->offset   = 0.0;
}




/*
 * FUNCTION
 *     Odor_in_read_odor
 *
 * DESCRIPTION
 *     Reads in odor data from a file.
 *
 * ARGUMENTS
 *     struct odor_in_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Odor_in_read_odor(struct odor_in_type *element)
{
    char   *sr;                 /* Generic char* ("string") return value. */
    char    line[MAX_LINE_LEN];
    int     odor_num;
    double  onset_time, duration;
    int     nread;
    short   found = 0; /* 1 means a next odor line was found. */

    assert(element->file != NULL);

#ifdef DEBUG
    printf("odor_in.c: reading new odor from file %s at time %g\n",
           element->filename, SimulationTime());
#endif

    /*
     * Read in the next line.  It should have the form:
     *
     * odor#  onset-time   duration
     *
     * If the end of file has been reached or there is a problem
     * reading the file, clear all the odor information.  No more
     * processing will occur this simulation.  If a bogus line occurs,
     * flag the error, ignore the line and try to read the next line.
     *
     * Also, lines starting with the `#' character are considered comments
     * and are skipped.
     *
     * WARNING! WARNING! WARNING!
     *
     * The last odor in the file MUST BE FOLLOWED BY A NEWLINE!
     * Failure to do so will cause the last odor in the file to be ignored.
     *
     */

    while (!found)
    {
        sr = fgets(line, MAX_LINE_LEN, element->file);

        if (feof(element->file))
        {
            Odor_in_clear_next_odor_info(element);
#ifdef DEBUG
            printf("odor_in.c: EOF encounted in file at time %g\n",
                   SimulationTime());
#endif
            return 0;
        }
        else if (sr == NULL)
        {
            Error();
            printf("odor_in object: %s: "
                   "error reading odor event file: %s\n",
                   MYPATH, element->filename);
            /* Try to close the file if possible. */
            fclose(element->file);
            element->file = NULL;
            Odor_in_clear_next_odor_info(element);
            return 0;
        }

        if ((strlen(line) > 0) && (line[0] == '#'))
            continue;   /* Skip comment line. */

        nread = sscanf(line, "%d %lg %lg",
                       &odor_num, &onset_time, &duration);

        if (nread != 3)
        {
            Error();
            printf("odor_in object: %s: error reading odor event file: "
                   "%s, line: %s; not all needed values found.\n"
                   "Reading next line...\n",
                   MYPATH, element->filename, line);
            Odor_in_clear_next_odor_info(element);
            continue;
        }

        /*
         * Check that the odor number, duration and onset are reasonable.
         */

        if (odor_num < -1)
        {
            Error();
            printf("odor_in object: %s: invalid odor number in file: "
                   "%s, line: %s\n"
                   "Reading next line...\n",
                   MYPATH, element->filename, line);
            Odor_in_clear_next_odor_info(element);
            continue;
        }

        if (duration <= 0.0)
        {
            Error();
            printf("odor_in object: %s: invalid odor duration in file: "
                   "%s, line: %s\n"
                   "Reading next line...\n",
                   MYPATH, element->filename, line);
            Odor_in_clear_next_odor_info(element);
            continue;
        }

        /*
         * Check for the case where the new odor onset time is negative
         * or occurs before the current simulation time.
         */

        if (onset_time <= 0.0)
        {
            Error();
            printf("odor_in object: %s: invalid (negative) "
                   "odor onset time in\n"
                   "file: %s, line: %s\n"
                   "Reading next line...\n",
                   MYPATH, element->filename, line);
            Odor_in_clear_next_odor_info(element);
            continue;
        }

        if (onset_time <= SimulationTime())
        {
            Error();
            printf("odor_in object: %s: invalid odor onset time in\n"
                   "file: %s, line: %s\n"
                   "Odor onset time > simulation time: %g\n"
                   "Reading next line...\n",
                   MYPATH, element->filename, line, SimulationTime());
            Odor_in_clear_next_odor_info(element);
            continue;
        }

        /*
         * If we got here, we must have found what we want.
         */

        found = 1;
    }

    element->next_odor->odor   = odor_num;
    element->next_odor->onset  = onset_time;
    element->next_odor->offset = onset_time + duration;

#ifdef DEBUG
    printf("odor_in object: %s\n", MYPATH);
    printf("\tnext_odor->odor: %d\n",   element->next_odor->odor);
    printf("\tnext_odor->onset: %g\n",  element->next_odor->onset);
    printf("\tnext_odor->offset: %g\n", element->next_odor->offset);
#endif

    return 1;
}





/*
 **********************************************************************
 *
 * Action functions.
 *
 **********************************************************************
 */

/*
 * FUNCTION
 *     Odor_in_CREATE
 *
 * DESCRIPTION
 *     Initializes the object.
 *
 * ARGUMENTS
 *     struct odor_in_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Odor_in_CREATE(struct odor_in_type *element)
{
    element->file     = NULL;
    element->filename = NULL;
    element->tau      = 0.0;
    element->alpha    = 0.0;
    element->alpha2   = 0.0;
    element->state    = 0;    /* no odor yet. */

    element->next_odor = (struct odor_event *)
        calloc(1, sizeof(struct odor_event));

    ERROR_IF (element->next_odor == NULL,
              "odor_in object: %s: CREATE: could not allocate memory.\n",
              MYPATH);

    Odor_in_clear_next_odor_info(element);
    return 1;
}




/*
 * FUNCTION
 *     Odor_in_DESTROY
 *
 * DESCRIPTION
 *     Frees memory for the object.
 *
 * ARGUMENTS
 *     struct odor_in_type *element -- address of element
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Odor_in_DESTROY(struct odor_in_type *element)
{
    Gfree(element->next_odor);
}




/*
 * FUNCTION
 *     Odor_in_RESET
 *
 * DESCRIPTION
 *     Reads in the first odor event and recalculates the alpha value.
 *
 * ARGUMENTS
 *     struct odor_in_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Odor_in_RESET(struct odor_in_type *element)
{
    double dt;

    PRINT_ENTERT;

    element->state = 0; /* No odor yet. */

    Odor_in_clear_next_odor_info(element);

    /*
     * Close the previously-opened file if any.
     */

    if (element->file != NULL)
    {
        fclose(element->file);
        element->file = NULL;
    }

    /*
     * If the filename is not NULL, open the file.  If the filename is
     * unchanged this is equivalent to rewinding the file.
     */

    if (element->filename != NULL)
    {
        element->file = fopen(element->filename, "r");

        ERROR_IF (element->file == NULL,
                  "odor_in object: %s: can't open event file: %s.\n",
                  MYPATH, element->filename);

        /*
         * Read in the next odor presentation from the file if any.
         */

        if (Odor_in_read_odor(element) == 0)
            return 0;
    }

    /*
     * Calculate the alpha value.  It is a multiplier which
     * controls how fast the concentration rises or falls.
     * If tau = 0.0 then alpha is set to 0.0.
     */

    dt = Clockrate(element);  /* Simulation time step. */

    ERROR_IF (element->tau < 0.0,
              "odor_in object: %s: tau must be >= 0.0\n",
              MYPATH);

    if (element->tau == 0.0)
        element->alpha = 0.0;
    else
        element->alpha = exp(-dt / element->tau);

    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     Odor_in_PROCESS
 *
 * DESCRIPTION
 *     Calculates the odor concentration if any.  Reads in the
 *     next line from the odor file if necessary.
 *
 * ARGUMENTS
 *     struct odor_in_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Odor_in_PROCESS(struct odor_in_type *element)
{
    /*
     * If there's no next odor event, just return.
     * NOTE: There can be a next_odor whose offset time
     * is already past; this is an odor in its falling phase.
     * A new odor event isn't read in until the concentration of
     * the old one has gone to zero.
     */

    if (element->next_odor->odor == 0)
    {
        assert_printi(element->odor  == 0,   element->odor);
        assert_printd(element->conc  == 0.0, element->conc);
        assert_printi(element->state == 0,   element->state);

        return 1;
    }


    /*
     * If there's no odor currently, check to
     * see if the next odor has come on yet.
     */

    if (element->odor == 0)
    {
        assert_printi(element->state == 0, element->state);

        if (element->next_odor->onset <= SimulationTime())
        {
            /*
             * The next odor has just come on.
             * We're in the rising phase of the odor.
             */

            element->odor   = element->next_odor->odor;
            element->state  = 1;
            element->alpha2 = element->alpha;
            element->conc   = 1.0 - element->alpha2;

#ifdef DEBUG
            printf("odor_in.c: Odor %d came on at time %g\n",
                   element->odor, SimulationTime());
#endif
        }

        /* Otherwise, do nothing. */

        return 1;
    }

    /*
     * There is an odor on.
     */

    assert_printi(element->state != 0, element->state);

    if (element->state == 1)
    {
        /* The odor is in its rising or plateau phase. */

        if (SimulationTime() > element->next_odor->offset)
        {
            /* Switch to falling phase. */
            element->state = -1;
        }
        else
        {
            element->alpha2 *= element->alpha;

            assert_printd(element->alpha2 >= 0.0, element->alpha2);

            element->conc = 1.0 - element->alpha2;

            /*
             * Set the conc to its maximum value when we're
             * five time constants past the odor onset.
             */

            if (element->conc > UPPER_THRESHOLD)
                element->conc = 1.0;

            return 1;
        }
    }

    /*
     * If we got here, we must be in the falling phase of
     * the odor.  Decrement the odor concentration; when
     * it reaches zero, read in a new odor event from the file
     * (if there are any more odors events).
     */

    assert_printi(element->state == -1, element->state);
    assert(SimulationTime() > element->next_odor->offset);

    element->conc *= element->alpha;

    /*
     * Set the conc to zero when we're five time constants
     * past the odor offset.  Adjust the state and read in
     * a new odor event if possible.
     */

    if (element->conc < LOWER_THRESHOLD)  /* The odor is done. */
    {
#ifdef DEBUG
        printf("odor_in.c: time %g: odor is done.\n", SimulationTime());
#endif
        element->conc  = 0.0;
        element->state = 0;
        element->odor  = 0;
        Odor_in_clear_next_odor_info(element);
        return Odor_in_read_odor(element);
    }

    return 1;
}




/*
 * FUNCTION
 *     Odor_in_CHECK
 *
 * DESCRIPTION
 *     Checks the object's integrity.
 *
 * ARGUMENTS
 *     struct odor_in_type *element -- address of element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Odor_in_CHECK(struct odor_in_type *element)
{
    ERROR_IF (element->odor < -1,
              "odor_in object: %s: odor number %d is out of range.\n",
              MYPATH, element->odor);

    ERROR_IF (element->conc < 0.0,
              "odor_in object: %s: concentration must be >= 0.0\n",
              MYPATH);

    ERROR_IF (element->tau < 0.0,
              "odor_in object: %s: tau must be >= 0.0\n",
              MYPATH);

    ERROR_IF (element->alpha < 0.0,
              "odor_in object: %s: alpha must be >= 0.0\n",
              MYPATH);

    ERROR_IF ((element->state < -1) || (element->state > 1),
              "odor_in object: %s: invalid state: %d\n",
              MYPATH, element->state);

    ERROR_IF (element->next_odor->odor < -1,
              "odor_in object: %s: invalid next_odor number: %d\n",
              MYPATH, element->next_odor->odor);

    ERROR_IF (element->next_odor->onset > element->next_odor->offset,
              "odor_in object: %s: next_odor: onset must be < offset.\n",
              MYPATH);

    return 1;
}






/**********************************************************************/

/*
 * OBJECT
 *     odor_in
 *         This object reads odor identity/onset/duration information
 *         from a file and converts it into data that can be sent
 *         to an olfactory_bulb object via an ODOR message.
 *
 * FUNCTION
 *     Odor_in
 *
 * ARGUMENTS
 *     struct odor_in_type *element -- address of element
 *     Action              *action  -- address of action
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Odor_in(struct odor_in_type *element, Action *action)
{
    int result;

    result = 1;

    switch (action->type)
    {
    case CREATE:
        result = Odor_in_CREATE(element);

        break;


    case DESTROY:
        Odor_in_DESTROY(element);

        break;


    case RESET:
        result = Odor_in_RESET(element);

        break;


    case CHECK:
        result = Odor_in_CHECK(element);

        break;


    case PROCESS:
        result = Odor_in_PROCESS(element);

        break;


    default:

        InvalidAction("odor_in", (Element *)element, action);
        result = 0;
        break;
    }

    return result;
}


