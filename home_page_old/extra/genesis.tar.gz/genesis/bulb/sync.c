/*
 *
 * FILE: sync.c
 *       Code which implements spike synchronization among active mitral
 *       cells.
 *
 * AUTHOR: Mike Vanier
 *
 */

#include "bulb_ext.h"

/*
 * NOTE: in order to use these functions and get correct results
 * the mran2() random number generator must be seeded.  This is
 * normally done from within a genesis script, but caveat modeler.
 */


/************************************************************************
 * Forward declarations.
 ************************************************************************/

int Sync_load_odor_activities(struct sync_coding_data *sync,
                              struct olfactory_bulb_type *parent);

int Sync_check_spike_sequences(struct sync_coding_data *sync,
                               struct olfactory_bulb_type *parent);

int Sync_load_events(struct sync_coding_data *sync,
                     struct olfactory_bulb_type *parent);

void
Sync_get_next_event(struct sync_coding_data *sync, int seq);

void
Sync_print_spiked_flags(struct sync_coding_data *sync, int seq);

void
Sync_print_active_flags(struct sync_coding_data *sync);

/************************************************************************
 * End of forward declarations.
 ************************************************************************/


/************************************************************************
 * Helper functions for load_sync_events().  These have been copied from
 * the `util' library and slightly modified.
 ************************************************************************/

/*
 * FUNCTION
 *     split_line_doubles_prob
 *
 * DESCRIPTION
 *     Utility function to split a line into a newly-malloc'ed
 *     array of doubles.  The last token on the line may be a
 *     probability value, which is returned as well.
 *
 * ARGUMENTS
 *     char *in_str -- the input string
 *     char *delim  -- the character or characters to split on,
 *                     generally " \t"
 *     double *prob -- probability value if found, else -1.0.
 *
 * RETURN VALUE
 *     double_array* -- a newly-allocated array of doubles,
 *                      or NULL on failure.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

double_array*
split_line_doubles_prob(char *in_str, char *delim, double *prob)
{
    int           i;
    char         *line, *str;
    double       *out;
    double_array *da;
    int           n;
    short         has_prob;


   /*
    * `has_prob' is a flag; it's 1 if there's a probability
    * at the end of the line.
    */

    has_prob =  0;
    *prob    = -1.0;  /* Default: no probability value given. */

    n = count_tokens(in_str, delim);

    if (n < 1)
    {
        Error();
        printf("Error: split_line_doubles_prob: "
               "not enough tokens on line: %s.\n", in_str);
        return NULL;
    }

    /*
     * Copy in_str to a buffer.  This is necessary since strtok() will
     * be used to split the string, and it destroys the string it
     * splits.
     */

    line = malloc(strlen(in_str) + 1);

    if (line == NULL)
    {
        Error();
        printf("Error: split_line_doubles_prob: "
               "could not allocate memory.\n");
        return NULL;
    }

    strcpy(line, in_str);

    /*
     * Allocate memory for the double array.
     */

    out = calloc((size_t)n, sizeof(double));

    if (out == NULL)
    {
        Error();
        printf("Error: split_line_doubles_prob: "
               "could not allocate memory.\n");
        Gfree(line);
        return NULL;
    }

    /*
     * Read in the tokens one by one and copy them to the output array.
     */

    /* The first token is treated differently by strtok(). */

    str = strtok(line, delim);

    if (str != NULL)  /* There's at least 1 token. */
    {
        /*
         * NOTE: if there's only one token it's assumed to be a valid
         * double, not a probability.
         */

        out[0] = atof(str); /* FIXME: do error checking! */

        /*
         * Loop through the rest of the tokens except the last one,
         * which may be a probability.
         */

        for (i = 1; i < (n - 1); i++)
        {
            str = strtok(NULL, delim);
            out[i] = atof(str); /* FIXME: do error checking! */
        }

        /*
         * Now handle the last token.
         */

        if (n > 1)  /* Skip if there only was one token. */
        {
            str = strtok(NULL, delim);

            if (str[0] == 'p')  /* It's a probability. */
            {
                str++;  /* Skip the 'p'. */
                *prob    = atof(str); /* FIXME: do error checking! */

                if ((*prob < 0.0) || (*prob > 1.0))
                {
                    Error();
                    printf("Error: split_line_doubles_prob: "
                           "invalid probability value: %g.\n", *prob);
                    Gfree(line);
                    Gfree(out);
                    return NULL;
                }

                has_prob = 1;
            }
            else
            {
                out[n-1] = atof(str); /* FIXME: do error checking! */
                *prob    = -1.0;
                has_prob = 0;
            }
        }
    }

    Gfree(line);

    /*
     * Package everything into the double_array struct.
     */

    da = malloc(sizeof(double_array));

    if (da == NULL)
    {
        Error();
        printf("Error: split_line_doubles_prob: "
               "could not allocate memory.\n");
        Gfree(out);
        return NULL;
    }

    if (has_prob)
        da->length = n - 1;
    else
        da->length = n;

    da->array = out;
    return da;
}




/*
 * FUNCTION
 *     load_event_array_from_file
 *
 * DESCRIPTION
 *     Utility function to load a 2D array of doubles from a file.
 *     Each double represents an spike synchronization event.
 *     Each line must have the same number of doubles.
 *     Each line MAY have a probability value at the end with the
 *     syntax pPROB, where PROB is a double.  Comments starting with
 *     `#' (as the first character on the line) are removed.
 *
 * ARGUMENTS
 *     char *filename       -- the name of the file to be loaded.
 *     double_array **probs -- probability array.
 *
 * RETURN VALUE
 *     double_2array* -- a newly-allocated 2D array of doubles,
 *                       or NULL on failure.
 *
 * SIDE EFFECTS
 *     The probs array (a double_array struct) is also filled with
 *     probability values if any are supplied.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

double_2array*
load_event_array_from_file(char *filename, double_array **probs)
{
    int   i, j, lineno, nlines, ntokens;
    FILE *fp;
    char  line[MAX_FILE_LINE_LEN];
    double_array  *da;
    double_2array *d2a;
    double prob;

    /*
     * `has_prob' is a flag; it's 1 if probabilities are being
     * read in in the event file.
     *
     * NOTE: The convention is that if probabilities are specified at all,
     *       then probabilities not specified will inherit the probability of
     *       the previous event (`last_prob').  If the first such probability
     *       is not specified, it defaults to 1.0.  `first_prob' is a flag
     *       which is 1 for the first probability to be read in.
     *
     */

    short  has_prob   = 0;
    short  first_prob = 1;
    double last_prob  = 1.0;

    /* Open the file. */

    fp = fopen(filename, "r");

    if (fp == NULL)
    {
        fprintf(stderr,
                "Error: load_event_array_from_file: "
                "could not open file `%s'.\n", filename);
        return NULL;
    }

    /*
     * First, run through the file line-by-line to determine the
     * dimensions of the file and to make sure it is a valid
     * file (i.e. that there is nothing but doubles in the file,
     * and that each line has the same number of doubles).
     *
     * Lines beginning with `#' (with no trailing whitespace) are
     * considered comments and are ignored.
     *
     */

    lineno  = 1;
    ntokens = -1;

    while (1)
    {
        if (fgets(line, MAX_FILE_LINE_LEN, fp) == NULL)
        {
            if (feof(fp))
            {
                break;
            }
            else
            {
                fprintf(stderr,
                        "Error: load_event_array_from_file: "
                        "could not read line: %d in: %s.\n",
                        lineno, filename);
                return NULL;
            }
        }

        /*
         * Scan the line for doubles.  Make sure each line has the
         * same number of doubles.
         */

        if ((strlen(line) > 0) && (line[0] == '#'))
            continue;  /* Skip comment line. */

        da = split_line_doubles_prob(line, " \t", &prob);

        if (prob > -1.0)
            has_prob = 1;  /* We're specifying event probabilities. */

        if (ntokens == -1) /* First line. */
        {
            ntokens = da->length;
        }
        else if (ntokens >= 0)
        {
            if (da->length != ntokens)
            {
                fprintf(stderr,
                        "Error: load_event_array_from_file: "
                        "Invalid number of tokens in line: %d in: %s;\n"
                        "\tshould be %d.\n",
                        lineno, filename, ntokens);
                free_double_array(&da);
                return NULL;
            }
        }
        else /* This should never happen. */
        {
            fprintf(stderr,
                    "Error: load_event_array_from_file: "
                    "Error reading line: %d in: %s.\n", lineno, filename);
            free_double_array(&da);
            return NULL;
        }

        free_double_array(&da);
        lineno++;
    }

    /*
     * We advanced one line past the end of the file, so nlines
     * is 1 less than lineno.
     */
    nlines = lineno - 1;

    /*
     * Now nlines has the number of rows and ntokens has the number of
     * columns.  We also know that the file is valid i.e. it contains
     * a valid 2D array of doubles, modulo the error-checking which is
     * done (or not done) by split_line_doubles().
     */

#ifdef DEBUG
    printf("rows: %d\tcolumns: %d\n", lineno, ntokens);
#endif

    rewind(fp);  /* Start again at the beginning. */

    /*
     * Create the 2D array of doubles and fill it up, line-by-line.
     */

    i = 0;
    d2a = create_double_2array(nlines, ntokens);

    if (has_prob)
    {
        /*
         * Create the probability array.  Note that the array
         * contains 0.0 values by default.
         */

        *probs = create_double_array(nlines);
    }
    else
    {
        *probs = NULL;
    }

    while (1)
    {
        if (fgets(line, MAX_FILE_LINE_LEN, fp) == NULL)
        {
            if (feof(fp))
            {
                break;
            }
            else
            {
                fprintf(stderr,
                        "Error: load_event_array_from_file: "
                        "could not read line: %d in: %s.\n",
                        lineno, filename);
                free_double_2array(&d2a);
                return NULL;
            }
        }

        if ((strlen(line) > 0) && (line[0] == '#'))
            continue;  /* Skip comment line. */

        da = split_line_doubles_prob(line, " \t", &prob);

        if (has_prob)
        {
            if (first_prob)
            {
                if (prob < 0.0)
                    prob = 1.0;

                first_prob = 0;
            }
            else
            {
                if (prob < 0.0)
                    prob = last_prob;
            }

            (*probs)->array[i] = prob;
            last_prob = prob;
        }

        if (da == NULL)
        {
            fprintf(stderr,
                    "Error: load_event_array_from_file: "
                    "Read error on line: %d in: %s;\n",
                    lineno, filename);
            free_double_array(&da);
            free_double_2array(&d2a);
            return NULL;
        }

        /* Copy the 1D array to a row of the 2D array. */

        for (j = 0; j < d2a->cols; j++)
            d2a->array[i][j] = da->array[j];

        free_double_array(&da);
        i++;
    }

    if (i != d2a->rows)
    {
        fprintf(stderr,
                "Error: load_event_array_from_file: "
                "Number of lines read: %d in: %s;\n"
                "should be: %d\n",
                i, filename, d2a->rows);
        free_double_2array(&d2a);
        return NULL;
    }

    return d2a;
}




/************************************************************************
 *
 * Functions relating to spike synchronization control.
 *
 ************************************************************************/

/*
 * FUNCTION
 *     Sync_create
 *
 * DESCRIPTION
 *     Creates an instance of the sync_coding_data struct with its fields
 *     properly initialized to default values.  This function will be
 *     called after the olfactory_bulb object is created; subsequently the
 *     user will be able to set the fields of this object.  Allocation of
 *     memory for the arrays used in this object will be done elsewhere,
 *     since several fields first have to be set by the user.
 *
 * ARGUMENTS
 *     struct olfactory_bulb_type *parent -- address of parent element
 *
 * RETURN VALUE
 *     struct sync_coding_data * -- the address of the newly-created
 *                                  object, or NULL for failure.
 *
 * AUTHOR
 *     Mike Vanier
 * */


struct sync_coding_data *
Sync_create(struct olfactory_bulb_type *parent)
{
    struct sync_coding_data *sync;

    PRINT_ENTERT;

    sync = (struct sync_coding_data*)
        calloc(1, sizeof(struct sync_coding_data));

    ERRORN_IF (sync == NULL,
               "object: %s: Sync_create: could not allocate memory.\n",
               PARENTPATH);

    /* Clear the filenames; these will be set by the user. */
    sync->sync_events_filename     = NULL;
    sync->sync_activities_filename = NULL;

    sync->sync_mode    =  0;   /* 0 = read events from file;
                                * else generate events probabilistically.  */
    sync->event_prob   =  1.0; /* Probability of responding to an event.   */
    sync->width        =  0.0; /* Parameter to use to calculate spikeprob. */
    sync->spikeprob    =  0.0; /* Poisson spike prob. for each time step.  */
    sync->nevent_seqs  =  0;   /* Number of distinct event sequences.      */
    sync->sync_duration = -1.0; /* Duration of synchrony;
                                 * (sync_duration < 0) =>
                                 * as long as the odor is on.              */
    sync->spiked       = NULL; /* Flags: have the cells which responds to
                                * a given sequence spiked? (nseqs*ncells)  */
    sync->active       = NULL; /* With which event sequence do the cells
                                * respond to the odors? (nodors * ncells)  */
    sync->nrsb         = 1;    /* Non-responding cells (cells
                                * in the pattern which don't respond to
                                * the particular event) spike at baseline
                                * rate.                                    */

    /* For sync_mode 0 only (read sync events from file). */

    sync->event_probs      = NULL; /* Array of event probabilities;
                                    * not always used.                     */
    sync->next_event_index = NULL; /* Index of next event for each seq.    */
    sync->current_event    = NULL; /* Current event of each sequence.      */
    sync->next_event       = NULL; /* Next event of each sequence.         */
    sync->events           = NULL; /* Time (relative to odor onset) of
                                    * spike events in a sequence
                                    * (nseqs * nevents).                   */

    PRINT_EXITT;

    return sync;
}




/*
 * FUNCTION
 *     Sync_destroy
 *
 * DESCRIPTION
 *     Deallocates memory for the sync object.  You must pass a
 *     pointer to the address so the address can be set to NULL.
 *
 * ARGUMENTS
 *     struct sync_coding_data **sync -- pointer to address of sync object
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_destroy(struct sync_coding_data **sync)
{
    PRINT_ENTERT;

    free_short_2array(&((*sync)->spiked));
    free_int_2array(&((*sync)->active));
    free_double_array(&((*sync)->event_probs));
    free_int_array(&((*sync)->next_event_index));
    free_double_array(&((*sync)->current_event));
    free_double_array(&((*sync)->next_event));
    free_double_2array(&((*sync)->events));
    Gfree(*sync);

    PRINT_EXITT;
}




/*
 * FUNCTION
 *     Sync_init
 *
 * DESCRIPTION
 *     Loads spike events from a file if needed, and performs
 *     various other initialization functions.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Sync_init(struct sync_coding_data *sync,
          struct olfactory_bulb_type *parent)
{
    double dt = Clockrate(parent);

    PRINT_ENTERT;

    /*
     * Calculate spiking probability per time step after an event occurs.
     * NOTE: this can be overridden by probabilities specific to a given
     * event.
     */

    if (fabs(sync->width) < TINY)
    {
        sync->spikeprob = 1.0;  /* Synchronization is immediate. */
    }
    else if (sync->width < 0.0)
    {
        ERROR ("object: %s: Sync_init: sync_width is invalid.\n",
               PARENTPATH);
    }
    else
    {
        sync->spikeprob = dt / sync->width;
    }

    Sync_load_odor_activities(sync, parent);


    /*
     * Initialize spike events.
     */

    if (sync->sync_mode == 0)  /* Load spike events from file. */
    {
        if (Sync_load_events(sync, parent) == 0)
        {
            return 0; /* Failure. */
        }

        sync->current_event    = create_double_array(sync->nevent_seqs);
        sync->next_event       = create_double_array(sync->nevent_seqs);
        sync->next_event_index = create_int_array(sync->nevent_seqs);
        sync->spiked           = create_short_2array(sync->nevent_seqs,
                                                     parent->ncells);
    }
    else /* Generate spike events as random ISIs. */
    {
        /* There's only one `sequence' for random events. */
        sync->nevent_seqs = 1;

        sync->current_event    = create_double_array(1);
        sync->next_event       = create_double_array(1);
        sync->next_event_index = create_int_array(1);
        sync->spiked           = create_short_2array(1, parent->ncells);
    }

    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     Sync_load_events
 *
 * DESCRIPTION
 *     Loads spike events from a file.  This is only meaningful for
 *     sync_mode 0.  Spike probabilities per event may also be loaded.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Sync_load_events(struct sync_coding_data *sync,
                 struct olfactory_bulb_type *parent)
{
    double_array *probs;

    PRINT_ENTERT;

    ERROR_IF (sync->sync_mode != 0,
              "object: %s: Sync_load_events: "
              "this function only valid for sync_mode = 0.\n",
              PARENTPATH);

    /* Make sure there is a filename. */

    ERROR_IF (sync->sync_events_filename == NULL,
              "object: %s: Sync_load_events: "
              "sync_events_filename has not been specified.\n",
              PARENTPATH);

    /* Open the file and get the array of spike events. */

    /*
     * Format of the events file:
     *     event event ...    (nsequences events; doubles) [pPROB]
     *
     * Events are positive doubles representing spike times.
     * Event sequences that are shorter than the maximum number of events
     * end in the sentinel value -1.0.
     *
     * Each event can have a probability value at the end, denoted by
     * the syntax pPROB where PROB is a floating-point number.
     *
     * NOTE: MAJOR LIMITATION: FIXME:
     *     Each event at a corresponding point in the event sequences
     *     can only have ONE associated probability value; this is
     *     lame but would require a significant overhaul of the data
     *     structures and parsing code to fix.  For most applications
     *     it's adequate because you usually only have one event
     *     sequence.  The way this works now is that the event probabilities,
     *     if supplied, change when sequence 0 changes.  That means you
     *     can't use them at all if you have more than one sequence, or
     *     very weird behavior will result.
     *
     *     One possibility is to have each event optionally tied to a
     *     probability like this:
     *
     *     0.025p1.0  0.530p0.6
     *     ...
     *
     * Comments can be included; a comment has `#' as the first character.
     *
     */

    sync->events
        = load_event_array_from_file(sync->sync_events_filename,
                                     &probs);

    sync->event_probs = probs;

    if (sync->events == NULL) /* Failed. */
        return 0;

    /* Transpose the event array. */

    transpose_2D_double_array(&(sync->events));

    /* Check that the spike sequences are valid. */

    sync->nevent_seqs = sync->events->rows;

    if (Sync_check_spike_sequences(sync, parent) == 0) /* error */
    {
        return 0;
    }

    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     Sync_check_spike_sequences
 *
 * DESCRIPTION
 *     Check that the array of spike event sequences read in from
 *     a file are valid (sync_mode 0 only).  A valid sequence is one
 *     where each spike event occurs after the previous ones.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Sync_check_spike_sequences(struct sync_coding_data *sync,
                           struct olfactory_bulb_type *parent)
{
    int i, j;
    double last;

    PRINT_ENTERT;

    assert(sync->sync_mode == 0);

    for (i = 0; i < sync->events->rows; i++)
    {
        last = -1.0;

        for (j = 0; j < sync->events->cols; j++)
        {
            if (sync->events->array[i][j] < 0.0) /* end of sequence */
                break;

            ERROR_IF (sync->events->array[i][j] <= last,
                      "object: %s: Sync_check_spike_sequences: "
                      "sequence %d is invalid.\n",
                      PARENTPATH, i);

            last = sync->events->array[i][j];
        }
    }

    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     Sync_init_events
 *
 * DESCRIPTION
 *     Initialize the synchronization events (sync_mode 0 only).
 *
 * ARGUMENTS
 *     struct sync_coding_data *sync -- address of sync object
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_init_events(struct sync_coding_data *sync)
{
    int i;

    PRINT_ENTERT;

    assert(sync->sync_mode == 0);
    assert(sync->nevent_seqs == sync->current_event->length);
    assert(sync->nevent_seqs == sync->next_event->length);

    for (i = 0; i < sync->nevent_seqs; i++)
        sync->current_event->array[i] = -1.0;  /* Marker for no event. */

    for (i = 0; i < sync->nevent_seqs; i++)
        sync->next_event->array[i] = -1.0;

    for (i = 0; i < sync->nevent_seqs; i++)
        sync->next_event_index->array[i] = 0;  /* Start with first event. */

    /* Get the first events in each sequence. */

    for (i = 0; i < sync->nevent_seqs; i++)
        Sync_get_next_event(sync, i);

    sync->event_probs_index = 0;  /* index into event_probs array */

    PRINT_EXITT;
}




/*
 * FUNCTION
 *     Sync_get_next_event
 *
 * DESCRIPTION
 *     Get next event from sequence `seq' (sync_mode 0 only).
 *     Make previous `next_event' the current event.
 *     Also adjust the `event_prob' if the `event_probs' array
 *     is non-NULL.
 *
 * ARGUMENTS
 *     struct sync_coding_data *sync -- address of sync object
 *     int seq -- the sequence index
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_get_next_event(struct sync_coding_data *sync, int seq)
{
    int next_index;

    PRINT_ENTERT;

    assert(sync->sync_mode == 0);
    assert((seq >= 0) && (seq < sync->nevent_seqs));

    sync->current_event->array[seq] = sync->next_event->array[seq];

    /* Is there another event? */

    next_index = sync->next_event_index->array[seq];

    if ((sync->next_event_index->array[seq] == -1)
        || (sync->events->array[seq][next_index] < 0.0)
        || (sync->next_event_index->array[seq] >= sync->events->cols))
    {
        /* No more events. */
        sync->next_event->array[seq]       = -1.0; /* Marker for no event. */
        sync->next_event_index->array[seq] = -1;   /* Marker for no event. */
    }
    else
    {
        /*
         * There are more events, so load the next one into the
         * next_event array.
         */

        sync->next_event->array[seq] = sync->events->array[seq][next_index];
        (sync->next_event_index->array[seq])++;
    }

#ifdef DEBUG
    printf("next event[%d]: %g\n", seq, sync->next_event->array[seq]);
#endif

    PRINT_EXITT;
}




/*
 * FUNCTION
 *     Sync_load_odor_activities
 *
 * DESCRIPTION
 *     Read in the list of odor activities from a file.  Each activity
 *     is an integer > 0, corresponding to the index of the spike event
 *     sequence that it synchronizes to, or 0 (zero), which represents
 *     background firing.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *
 * RETURN VALUE
 *     int -- 0 = failure and 1 = success
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

int
Sync_load_odor_activities(struct sync_coding_data *sync,
                          struct olfactory_bulb_type *parent)
{
    FILE *fp;

    PRINT_ENTERT;

    sync->active = create_int_2array(parent->max_odors, parent->ncells);

    /* Make sure there is a filename. */

    ERROR_IF (sync->sync_activities_filename == NULL,
              "object: %s: Sync_load_odor_activities: "
              "sync_activities_filename has not been specified.\n",
              PARENTPATH);

    fp = fopen(sync->sync_activities_filename, "r");

    /* Open the file and get the array of spike events. */

    /*
     * Format of the activities file:
     *     seq seq ...    (`ncells' lines; all ints)
     *
     */

    sync->active
        = load_2D_int_array_from_file(sync->sync_activities_filename);

    if (sync->active == NULL) /* Failed. */
        return 0;

    transpose_2D_int_array(&(sync->active));

    fclose(fp);

    PRINT_EXITT;

    return 1;
}




/*
 * FUNCTION
 *     Sync_clear_spiked_flags
 *
 * DESCRIPTION
 *     Set the `spiked' flags to zero (sync_mode 0 only).
 *
 * ARGUMENTS
 *     struct sync_coding_data *sync -- address of sync object
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_clear_spiked_flags(struct sync_coding_data *sync)
{
    int i, j;

    PRINT_ENTERT;

    assert(sync->spiked != NULL);

    for (i = 0; i < sync->spiked->rows; i++)
        for (j = 0; j < sync->spiked->cols; j++)
            sync->spiked->array[i][j] = 0;

    PRINT_EXITT;
}




/*
 * FUNCTION
 *     Sync_init_spiked_flags
 *
 * DESCRIPTION
 *     Set the `spiked' flags for a given odor and a pre-set spike event
 *     sequence.  Set the `spiked' flags to 1 for the cells that won't be
 *     responding to this odor with this sequence; set those that do
 *     respond to this odor with this sequence but not to this particular
 *     event to -1, and set the rest to 0 (ready to spike).  Note that
 *     cells that don't respond to this odor with this sequence can still
 *     respond to this odor with a different sequence or can spike in
 *     background mode.  This function also takes into account
 *     probabilistic responses to an event.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *     int    odor   -- the odor number
 *     int    seq    -- the spike event sequence number
 *     short  random -- flag: 1 means events are generated randomly
 *     double mod    -- neuromodulation value
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_init_spiked_flags(struct sync_coding_data *sync,
                       struct olfactory_bulb_type *parent,
                       int odor, int seq, short random,
                       double mod)
{
    int    i;
    short  not_in_seq;
    double last_spike_time;

    PRINT_ENTERT;

#ifdef DEBUG
    printf("init_spiked_flags: odor = %d, seq = %d\n", odor, seq);
#endif

    assert(sync->event_prob >= 0.0);
    assert(sync->event_prob <= 1.0);
    assert(odor >= 0);
    assert(sync->spiked != NULL);
    assert(sync->active != NULL);

    for (i = 0; i < parent->ncells; i++)
    {
        if (random) /* Use randomly generated spike event sequences. */
        {
            /*
             * If the `active' value is nonzero it's considered to be
             * in the sequence; if it's 0 it means background firing.
             */

            not_in_seq = (sync->active->array[odor][i] == 0);
        }
        else /* Use spike event sequences read in from file. */
        {
            /*
             * Add one to seq when comparing it to the `active' values
             * because an `active' value of 0 means background firing.
             */

            not_in_seq = (sync->active->array[odor][i] != (seq + 1));
        }

        /*
         * Set the 'spiked' flag to 1 if the cell isn't part of this
         * sequence or to -1 if it has been randomly selected not to
         * respond to the odor for this synchronization event.
         */

        if (not_in_seq)
        {
            sync->spiked->array[seq][i] = 1;
        }
        else if (mran2(1) <= (1.0 - sync->event_prob))
        {
            last_spike_time = (SimulationTime())
                - Spikeprob_get_random_ISI(parent->isi, mod);
#ifdef DEBUG
            printf("Setting last_spike_time of cell %d to %g\n",
                   i, last_spike_time);
#endif
            parent->cell[i].last_spike_time = last_spike_time;
            sync->spiked->array[seq][i] = -1;
        }
        else
        {
            /* The cell is ready to spike. */
            sync->spiked->array[seq][i] = 0;
        }
    }

#ifdef DEBUG
    Sync_print_spiked_flags(sync, seq);
#endif

    PRINT_EXITT;
}




/*
 * FUNCTION
 *     Sync_print_spiked_flags
 *
 * DESCRIPTION
 *     Print the `spiked' flags of the `seq' sequence.  Used for
 *     debugging.
 *
 * ARGUMENTS
 *     struct sync_coding_data *sync -- address of sync object
 *     int seq -- the event sequence
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_print_spiked_flags(struct sync_coding_data *sync, int seq)
{
    int i;

    printf("`spiked' flags for sequence %d: ", seq);

    for (i = 0; i < sync->spiked->cols; i++)
        printf("%d ", sync->spiked->array[seq][i]);

    printf("\n");
}




/*
 * FUNCTION
 *     Sync_print_active_flags
 *
 * DESCRIPTION
 *     Print the `active' flags for all cell/odor pairs.  Used for
 *     debugging.
 *
 * ARGUMENTS
 *     struct sync_coding_data *sync -- address of sync object
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_print_active_flags(struct sync_coding_data *sync)
{
    int i, j;

    for (i = 0; i < sync->active->rows; i++)
    {
        for (j = 0; j < sync->active->cols; j++)
            printf("active[%d][%d] = %d\n", i, j, sync->active->array[i][j]);

        printf("\n");
    }
}




/*
 * FUNCTION
 *     Sync_update_cells
 *
 * DESCRIPTION
 *     Determine which cells spike after an event in a given
 *     event sequence.  The spiking probability is constant over
 *     time except when a cell has already spiked in response
 *     to that event, whereupon it goes to zero.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *     int seq  -- the event sequence
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_update_cells(struct sync_coding_data *sync,
                  struct olfactory_bulb_type *parent,
                  int seq, double time, double dt, double mod)
{
    int    i;
    double prob;

    for (i = 0; i < parent->ncells; i++)
    {
        if (sync->spiked->array[seq][i] == 0)
        {
            /*
             * The cell is part of the sequence and has not yet spiked
             * for this event. Does the cell spike this time step?
             */

            if (mran2(1) < sync->spikeprob) /* The cell spikes! */
            {
                parent->cell[i].spiking = 1;  /* Notify parent. */
                sync->spiked->array[seq][i] = 1;
#ifdef DEBUG
                printf("cell %d spikes in sequence %d at time %g\n",
                       i, seq, time);
#endif
            }
        }
        else if (sync->spiked->array[seq][i] == -1)
        {
            /*
             * The cell is part of the sequence but does not respond to this
             * event.  Therefore, it goes on spiking at the background rate
             * (if the nrsb flag is set).  Note that when the cell is firing
             * at the background rate it can spike more than once per event,
             * or not at all.  If the nrsb flag is not set, the cell doesn't
             * spike until (at least) the next event.  Also, if the `bg_odor'
             * field of the parent = -1, then there is no background spiking.
             */

            if (sync->nrsb)
            {
                if (parent->bg_odor != -1)
                {
                    prob = Spikeprob_get_spike_prob(
                        parent->isi,
                        time,
                        dt,
                        parent->cell[i].last_spike_time,
                        mod);

                    if (random_hit(prob))  /* The cell fires a spike. */
                        parent->cell[i].spiking = 1;
                }
            }
        }
        else
        {
            /*
             * Otherwise, The cell is part of some sequence, but it has
             * either already spiked once for this event or it is not part
             * of this sequence.  In either case do nothing (a cell never
             * spikes twice for the same event).
             */

            assert(sync->spiked->array[seq][i] == 1);
        }
    }
}




/*
 * FUNCTION
 *     Sync_update_background
 *
 * DESCRIPTION
 *     Update the `spiking' status of the cells when all the cells
 *     are firing in background mode.  This only applies when
 *     there is a finite sync_duration value which we have exceeded.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *     double time -- the current simulation time
 *     double dt   -- the simulation time step
 *     double mod  -- the neuromodulation value
 *
 * RETURN VALUE
 *     void
 *
 * NOTE
 *     This has nothing to do with synchronized spikes.  It could have been
 *     defined in olfactory_bulb.c and perhaps should have been, in that
 *     almost the same code is used there, but there it's used in the body
 *     of the PROCESS action function.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

inline void
Sync_update_background(struct olfactory_bulb_type *parent,
                       double time, double dt, double mod)
{
    int    i;
    double prob;

    if (parent->bg_odor == -1)  /* no background spiking */
        return;

    for (i = 0; i < parent->ncells; i++)
    {
        prob = Spikeprob_get_spike_prob(parent->isi, time, dt,
                                        parent->cell[i].last_spike_time,
                                        mod);

        if (random_hit(prob))  /* The cell fires a spike. */
            parent->cell[i].spiking = 1;
    }
}




/*
 * FUNCTION
 *     Sync_update_sync_mode_0
 *
 * DESCRIPTION
 *     Update the `spiking' status of the cells when new events
 *     come on in any spike event sequence.  This is only for
 *     `sync_mode' = 0.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *     int    odor      -- the odor number
 *     double odor_time -- the time the current odor has been on
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_update_sync_mode_0(struct sync_coding_data *sync,
                        struct olfactory_bulb_type *parent,
                        int odor, double odor_time,
                        double time, double dt, double mod)
{
    int i;

    assert(sync->sync_mode == 0);

    /* Correct odor number for 1-based indexing. */

    odor--;

    for (i = 0; i < sync->nevent_seqs; i++)
    {
        /*
         * Are there any new events w.r.t. this spike sequence this time
         * step?  If so, initialize the `spiked' flags for the sequence.
         */

        if ((sync->next_event->array[i] >= 0.0) /* sequence isn't finished */
            && (odor_time >= sync->next_event->array[i])) /* new event */
        {
#ifdef DEBUG
            printf("reference spike event in sequence %d occurs at time %g\n",
                   i, time);
#endif

            Sync_get_next_event(sync, i);
            /* `next_event->array[i]' is now `current_event->array[i]'. */

            /* Load the next event probability if it exists. */

            if (sync->event_probs != NULL)
            {
                if (sync->event_probs->length >= 1)
                {
                    sync->event_prob
                        = sync->event_probs->array[sync->event_probs_index];
                    sync->event_probs_index++;
                }
            }

            Sync_init_spiked_flags(sync, parent, odor, i, 0, mod);
        }

        /* Does any cell spike this time step? */

        if ((sync->current_event->array[i] >= 0.0)
            && (odor_time >= sync->current_event->array[i]))
        {
            /*
             * An event has occurred previously, so check for spikes.
             * Since the spiking probability is uniform, we don't have
             * to give the last spike time as an argument.
             */

            /*
             * FIXME! If all cells in this sequence have spiked there
             * is no need to call this function.  Should be able to get a
             * speedup by checking this.  However, to do this we have to
             * have a new array of the number of cells that have "spiked"
             * for each event sequence.
             */

            Sync_update_cells(sync, parent, i, time, dt, mod);
        }
    }
}




/*
 * FUNCTION
 *     Sync_update_sync_mode_1
 *
 * DESCRIPTION
 *     Update the `spiking' status of the cells when new random spike events
 *     come on.  This is only for `sync_mode' = 1.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *     int    odor -- the odor number
 *     double time -- the current simulation time
 *     double dt   -- the simulation time step
 *     double mod  -- the neuromodulation value
 *
 * RETURN VALUE
 *     void
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_update_sync_mode_1(struct sync_coding_data *sync,
                        struct olfactory_bulb_type *parent,
                        int odor, double time, double dt, double mod)
{
    struct spikeprob_type *isi;
    double prob, last;

    assert(sync->sync_mode == 1);

    isi = parent->isi;

    /* Correct odor number for 1-based indexing. */

    odor--;

    /*
     * Is there a new event this time step?  If so, initialize the
     * `spiked' flags for the sequence.  We use the background
     * firing rate, suitably modified by the neuromodulation value,
     * to get random spiking events.
     *
     * HACK ALERT: we use `current_event->array[0]' for the last
     *             random event i.e. we always use sequence 0.
     */

    last = sync->current_event->array[0];

    if (last < 0.0)
    {
        /*
         * There's been no event yet, so use the init_last_spike_time
         * as the "last" value.  Leave last as -1.0 because it's
         * used as a flag below.  Pretty hacky, I know...
         */

        prob = Spikeprob_get_spike_prob(isi, time, dt,
                                        sync->init_last_spike_time, mod);

    }
    else
    {
        prob = Spikeprob_get_spike_prob(isi, time, dt, last, mod);
    }

    if (mran2(1) < prob)
    {
        /* A new event occurs! */

#ifdef DEBUG
        printf("reference spike event occurs at time %g\n", time);
#endif

        sync->current_event->array[0] = time;
        last = sync->current_event->array[0];
        Sync_init_spiked_flags(sync, parent, odor, 0, 1, mod);
    }


    /*
     * Does any cell spike this time step?
     */

    if (last >= 0.0)
    {
        /*
         * An event has occurred previously, so check for spikes.
         * Since the spiking probability is uniform, we don't have
         * to give the last spike time as an argument.
         */

        /* FIXME: same comment as for update_sync_mode_0(). */
        Sync_update_cells(sync, parent, 0, time, dt, mod);
    }
}




/*
 * FUNCTION
 *     Sync_update
 *
 * DESCRIPTION
 *     Figure out which cells spike this time step and take appropriate
 *     action.
 *
 * ARGUMENTS
 *     struct sync_coding_data    *sync   -- address of sync object
 *     struct olfactory_bulb_type *parent -- address of parent element
 *     double dt  -- the simulation time step
 *     double mod -- the neuromodulation value
 *
 * RETURN VALUE
 *     void
 *
 * NOTES
 *     This function and the functions it calls are *only* called if
 *     an odor is on (i.e. an odor other than 0 or -1).  Therefore there
 *     is no need to deal with the odors 0 and -1 here, other than to
 *     assert() that they don't occur.
 *
 * AUTHOR
 *     Mike Vanier
 *
 */

void
Sync_update(struct sync_coding_data *sync,
            struct olfactory_bulb_type *parent,
            double time, double dt, double mod)
{
    int    i, odor;
    double odor_time, prob;

    odor      = parent->odor;
    odor_time = parent->odor_time;

    assert(odor > 0);  /* An odor must be on. */

    /* Has the odor just switched on? */

    if (parent->new_odor)
    {
#ifdef DEBUG
        printf("sync.c: Odor %d came on at time %g\n", parent->odor, time);
#endif

        Sync_clear_spiked_flags(sync);

        if (sync->sync_mode == 0)
        {
            Sync_init_events(sync);
        }
        else  /* sync mode 1 (random sync events) */
        {
            /*
             * This is a hack.  Just use position 0 in current_event
             * array.  Set a fictitious init_last_spike_time to be the
             * starting last spike time for the synchronization spike
             * sequence.
             */

            sync->current_event->array[0] = -1.0;
            sync->init_last_spike_time = (SimulationTime())
                - Spikeprob_get_random_ISI(parent->isi, mod);
        }
    }

    /*
     * Has the odor been on longer than the (maximum) sync_duration?
     * If so, switch to background spiking.  A negative value of
     * sync_duration means that the sync_duration is infinite i.e.
     * the cells stay synchronized as long as the odor is on.
     */

    if ((sync->sync_duration >= 0.0)
        && (odor_time > sync->sync_duration))
    {
        Sync_update_background(parent, time, dt, mod);
    }
    else
    {
        /* Otherwise, generate spikes according to the sync mode. */

        if (sync->sync_mode == 0) /* Read sync events from file. */
        {
            Sync_update_sync_mode_0(sync, parent, odor, odor_time,
                                    time, dt, mod);
        }
        else  /* Generate sync events randomly. */
        {
            Sync_update_sync_mode_1(sync, parent, odor,
                                    time, dt, mod);
        }

        /*
         * Now deal with the cells that do not respond to *any* sequence
         * i.e.  that go on firing at the background rate.
         */

        for (i = 0; i < parent->ncells; i++)
        {
            /*
             * Use `(odor - 1)' instead of `odor' to compensate for
             * zero-based indexing.
             */

            if (sync->active->array[odor-1][i] == 0) /* background firing */
            {
                /*
                 * The cell is not part of any sequence.  Therefore, it
                 * goes on spiking at the background rate.  If the
                 * `bg_odor' field of the parent = -1, there is no
                 * background spiking.
                 */

                if (parent->bg_odor != -1)
                {
                    prob = Spikeprob_get_spike_prob(
                        parent->isi,
                        time,
                        dt,
                        parent->cell[i].last_spike_time,
                        mod);

                    if (random_hit(prob))  /* The cell fires a spike. */
                        parent->cell[i].spiking = 1;
                }
            }
        }
    }
}



