/*
 *
 * FILE: bulb_defs.h
 *
 *      Definitions for the bulb library.
 *
 *
 * AUTHOR: Mike Vanier
 *
 */

#ifndef BULB_DEFS_H
#define BULB_DEFS_H

/* New actions. */

#define DESTROY       4001
#define INITIALIZE    4002
#define MSGINFO       4003
#define LOADPATTERNS  4004
#define SHOWPATTERNS  4005
#define LOADRATEINFO  4006
#define LOADSYNCINFO  4007
#define INITRATEINFO  4008


/* New messages. */

#define ODOR  7001


/* Messages defined elsewhere. */

#define SPIKE -1  /* In newconn_defs.h */


/* Coding of odor responses. */

#define NO_CODING        0
#define RATE_CODING      1
#define SYNCHRONY_CODING 2


/*
 * Replacement for free() that nulls the pointer after freeing.
 * WARNING: If you do this to a pointer that was passed in to
 * the function, the nulling will have NO EFFECT!
 */

#ifndef Gfree
#define Gfree(x) \
    if (x != NULL) \
    { \
       free(x);    \
       x = NULL;   \
    }
#endif


/* MIN and MAX macros. */

#ifdef MIN
#undef MIN
#define MIN(A,B) (((A) < (B)) ? (A) : (B))
#endif

#ifdef MAX
#undef MAX
#define MAX(A,B) (((A) > (B)) ? (A) : (B))
#endif


/* Miscellaneous stuff. */

#ifdef MAX_LINE_LEN
#undef MAX_LINE_LEN
#endif
#define MAX_LINE_LEN 128

#ifdef TINY
#undef TINY
#endif
#define TINY 1.0e-8

#ifdef VTINY
#undef VTINY
#endif
#define VTINY 1.0e-16

#endif /* BULB_DEFS_H */
