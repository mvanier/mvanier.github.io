/*
 * FILE: h_calc.c
 *
 */

#include "hines_ext.h"

/*
 * This routine uses a large chunk of CPU time, calculating coeffs.
 * This version disobeys all rules of object orientedness, taking
 * over all the calculations that should be done by the compartments.
 */

int
do_hcalc(Hsolve *hsolve)
{
    int      ncompts = hsolve->ncompts;
    double  *values;
    int     *cip, *ri, *diag, *elmnum, *parents;
    struct   mod_compartment_type *compt, *link, **compts;
    struct   tab_channel_type *h;
    Tcinfo **hh, *hentry;
    Cinfo  **chan, *centry;
    int      i, j, k;
    int      comptindex, linkindex, chanmode;
    int      nextcip;
    double  *results;
    double   dt, sumgchan, ichan, diagterm, tbyc;
    float    Rm, Ra, Em;
    double   Vm;
    MsgIn   *msgin;
    short   *msgcompts = hsolve->msgcompts;

    values   = hsolve->values;
    results  = hsolve->results;
    cip      = hsolve->cip;
    ri       = hsolve->ri;
    diag     = hsolve->diag;
    elmnum   = hsolve->elmnum;
    parents  = hsolve->parents;
    compts   = (struct mod_compartment_type **)hsolve->compts;
    hh       = hsolve->hh;
    chan     = hsolve->chan;
    chanmode = hsolve->chanmode;

    if (BaseObject(hsolve)->method == CRANK_INT)
        dt = Clockrate(hsolve) * 0.5;
    else            /* BEULER by default */
        dt = Clockrate(hsolve);

    for (i = 0; i < ncompts; i++)
    {
        comptindex = elmnum[i];
        compt = compts[comptindex];

        /*
         * NOTE: if current injection is never used in the simulation,
         * this section can be #ifdef'd out.
         */

        if (msgcompts[comptindex])
        {
            /*
             * Search for an INJECT message.  If one is found, break
             * out of the MSGLOOP; this means that a given compartment
             * can only have one INJECT message.
             */

            MSGLOOP(compt, msgin)
            {
            case INJECT:
                compt->inject = MSGVALUE(msgin, 0);
                goto DONE;

            default:
                break;
            }
        }

    DONE:

        /*
         * MCV addition: if neuromodulation is present, adjust the
         * Em value.
         */

        if (compt->mod_index >= 0)
            compt->Em = nm[compt->mod_index];

        Vm   = compt->Vm;
        Em   = compt->Em;
        Rm   = compt->Rm;
        Ra   = compt->Ra;
        tbyc = dt / compt->Cm;

        ichan = sumgchan = 0.0;

        if (chanmode)
        {
            /* CHANMODE 1 */
            /* Calculating contribution due to tabchannels */
            for (hentry = hh[i]; hentry; hentry = hentry->next)
            {
                h = (struct tab_channel_type *)(hentry->chan);
                sumgchan += h->Gk;
                ichan += h->Ek * h->Gk;
            }
        }

        /* Calculating contribution due to other channels */
        for (centry = chan[i]; centry; centry = centry->next)
        {
            /*
             * MCV change: we use indirect pointers to the Gk, Ek
             * values.  This lets us have multiple CHANNEL messages
             * from a given object.  This only works for chanmode 0
             * and (probably) comptmode 1.  It may work for comptmode
             * 0 as well; I don't know.  This may be slightly less
             * efficient than the old method.
             *
             */

            double Gk = *(centry->Gk);
            float  Ek = *(centry->Ek);

            sumgchan += Gk;
            ichan    += Ek * Gk;
        }

        results[i] = Vm + tbyc * (compt->inject + Em / Rm + ichan);
        diagterm = tbyc * sumgchan;

        nextcip = cip[i + 1];

        for (j = cip[i]; j < nextcip; j++)
        {
            /* finding the column number */
            k = ri[j];

            /* Diagonal element */
            if (i == k)
            {
                diagterm += 1.0 + tbyc / Rm;
            }
            else
            {
                linkindex = elmnum[k];
                link = compts[linkindex];

                if (parents[linkindex] == comptindex)
                {
                    /* child elements */
                    diagterm -= (values[j] = -tbyc / link->Ra);
                }
                else if (parents[comptindex] == linkindex)
                {
                    /* parent element */
                    diagterm -= (values[j] = -tbyc / Ra);
                }
                else
                {
                    /* siblings */
                    printf("** Warning - Sibling coeffs only occur "
                           "for symcompartments\n");
                }
            }
        }

        values[diag[i]] = diagterm;
    }

    return 0;
}



