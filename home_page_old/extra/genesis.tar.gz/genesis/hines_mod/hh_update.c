/*
 * FILE: hh_update.c
 *
 */

#include "hines_ext.h"

extern double TabInterp();


/*
 * This file contains the routines for updating the coeffs of the
 * hh channels. These routines are non-object-oriented. These routines
 * typically use the most cpu time.
 */

/*
 * A utility function for do_hh_update()
 */

inline double
upi_pow(double x, float y)
{
    double  x1;

    if (y == 2.0)
        return (x * x);

    if (y == 1.0)
        return x;

    if (y == 3.0)
        return (x * x * x);

    if (y == 4.0)
    {
        x *= x;
        return (x * x);
    }

    if (y == 5.0)
    {
        x1 = x;
        x *= x;
        x *= x * x1;
        return x;
    }

    if (fabs(y) < VTINY)
        return 1.0;

    return pow(x, y);
}




/*
 * This is the plain vanilla, default version.
 * It solves the channels for chanmode 1.
 */

int
do_hh_update(Hsolve *hsolve)
{
    int      ncompts = hsolve->ncompts;
    int     *elmnum;
    struct   mod_compartment_type **compts;
    Tcinfo **hh;
    Tcinfo  *hentry;
    int      i;
    double   dt;
    double   tby2;
    double   c, g, temp;
    Tchan   *h;
    double   v;
    double   X, Y, Z;
    float    Xpow, Ypow, Zpow;

    elmnum = hsolve->elmnum;
    compts = (struct mod_compartment_type **)hsolve->compts;
    hh     = hsolve->hh;

    dt   = Clockrate(hsolve);
    tby2 = dt / 2.0;

    for (i = 0; i < ncompts; i++)
    {
        if (!(hentry = hh[i]))
            continue;

        v = compts[elmnum[i]]->Vm;

        /* looping over all hh chans on this compt */
        for (; hentry; hentry = hentry->next)
        {
            h = (Tchan *) (hentry->chan);
            g = h->Gbar;

            if ((Xpow = h->Xpower) > TINY)
            {
                /* Trapezoid method of integration */
                temp = 1.0 + tby2 * TabInterp(h->X_B, v);
                X = h->X = (h->X * (2.0 - temp)
                            + dt * TabInterp(h->X_A, v)) / temp;
                g *= upi_pow(X, Xpow);
                h->X = X;
            }

            if ((Ypow = h->Ypower) > TINY)
            {
                if (h->Y_B)
                {
                    temp = 1.0 + tby2 * TabInterp(h->Y_B, v);
                    Y = h->Y = (h->Y * (2.0 - temp)
                                + dt * TabInterp(h->Y_A, v)) / temp;
                }
                else
                {
                    Y = h->Y = (h->Y + dt * TabInterp(h->Y_A, v));
                }

                g *= upi_pow(Y, Ypow);
                h->Y = Y;
            }

            if ((Zpow = h->Zpower) != 0.0)
            {
                c = MSGVALUE(hentry->conc, 0);

                if (Zpow > TINY)
                {
                    temp = 1.0 + tby2 * TabInterp(h->Z_B, c);
                    Z = (h->Z * (2.0 - temp)
                         + dt * TabInterp(h->Z_A, c)) / temp;
                    g *= upi_pow(Z, Zpow);
                    h->Z = Z;
                }
                else
                    /* Zpow is negative */
                {
                    temp = 1.0 + tby2 * TabInterp(h->Z_B, v);
                    Z = (h->Z * (2.0 - temp)
                         + dt * (c * TabInterp(h->Z_A, v))) / temp;
                    g *= upi_pow(Z, -Zpow);
                    h->Z = Z;
                }
            }

            if (hentry->nernst)
            {
                h->Ek = hentry->nernst->E;
            }

            if (g == 0.0)
            {
                h->Gk = 0.0;
                h->Ik = 0.0;
            }
            else
            {
                h->Gk = g;
                h->Ik = g * (h->Ek - v);
            }
        }
    }

    return 0;
}


