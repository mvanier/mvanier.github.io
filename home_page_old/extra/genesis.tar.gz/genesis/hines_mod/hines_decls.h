/*
 * FILE: hines_decls.h: extern declarations for the internal use of the
 *       hines library.
 */

#ifndef HINES_DECL_H
#define HINES_DECL_H

/*
 * Functions from other parts of genesis.  Most of these are in the
 * sim library.
 */

extern int
ActionHeader();

extern int
CallActionFunc();

extern int
CallElement();

extern int
CallEventAction();

extern int
DeleteElement();

extern int
Error();

extern int
ErrorMessage();

extern int
G_getopt();

extern int
GetIndexComponent();

extern void
HsolveBlock();

extern void
HsolveEnable();

extern int
IsHsolved();

extern int
IsSilent();

extern char *
Pathname();

extern int
SetWorkingElement();

extern int
do_copy();

extern int
initopt();

extern int
printoptusage();



/*
 * Internal to hines library:
 */

extern int
bubble_sort(int *array, int nterms);

extern int
h_add_iinfo(Hsolve *hsolve, MsgIn *msgin, int op, int nop, int nchip);

extern int
h_msg_alert(Hsolve *hsolve, int type, Element *elm);

extern int
chip_get_mgblock(Hsolve *hsolve, int cindex);

extern int
chip_get_mmpump(Hsolve *hsolve, int cindex);

extern int
chip_get_tabcurrent(Hsolve *hsolve, int cindex);

extern int
chip_hcalc_init(Hsolve *hsolve);

extern int
chip_put_Ca_concen(Hsolve *hsolve, int comptno, int cindex);

extern int
chip_put_buffer(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_put_channelc3(Hsolve *hsolve, int cindex);

extern int
chip_put_compt(Hsolve *hsolve, int comptno);

extern int
chip_put_concen(Hsolve *hsolve, int cindex, int concind);

extern int
chip_put_d2buffer(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_put_difshell(Hsolve *hsolve, int comptno, int cindex);

extern int
chip_put_ghk(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_put_mgblock(Hsolve *hsolve, int cindex);

extern int
chip_put_mmpump(Hsolve *hsolve, int cindex, int concchild);

extern int
chip_put_nernst(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_put_shell(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_put_spike(Hsolve *hsolve, int cindex);

extern int
chip_put_tabchannel(Hsolve *hsolve, int cindex);

extern int
chip_put_tabcurrent(Hsolve *hsolve, int cindex);

extern int
chip_put_taupump(Hsolve *hsolve, int cindex);

extern int
chip_get_compt(Hsolve *hsolve, int comptno);

extern int
chip_get_concen(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_get_nernst(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_get_ghk(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_get_tabchannel(Hsolve *hsolve, int cindex);

extern int
chip_get_channelc3(Hsolve *hsolve, int cindex);

extern int
chip_get_shell(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_get_buffer(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_get_d2buffer(Hsolve *hsolve, int cindex, int concindex);

extern int
chip_get_taupump(Hsolve *hsolve, int cindex);

extern int
do_chip_hh2_update(Hsolve *hsolve);

extern int
do_chip_hh2noi_update(Hsolve *hsolve);

extern int
do_chip_hh4_update(Hsolve *hsolve);

extern int
do_chip_hh4ni_update(Hsolve *hsolve);

extern int
do_chip_hreset(Hsolve *hsolve, char *actionstr);

extern int
do_chip_hsave(Hsolve *hsolve);

extern int
do_chip_hsetup(Hsolve *hsolve);

extern int
do_compt_update(Hsolve *hsolve);

extern int
do_crank_hsolve(Hsolve *hsolve);

extern int
do_duplicate(Hsolve *origsolve, char *newname, char *path);

extern int
do_euler_hsolve(Hsolve *hsolve);

extern int
do_fast_hsetup(Hsolve *hsolve);

extern int
do_fast_hsolve(Hsolve *hsolve);

extern int
do_h2_conc_chip_update(Hsolve *hsolve);

extern int
do_h4_conc_chip_update(Hsolve *hsolve);

extern int
do_h_conc_solve(Hsolve *hsolve);

extern int
do_hcalc(Hsolve *hsolve);

extern int
do_hget_children(Hsolve *hsolve);

extern int
do_hh_update(Hsolve *hsolve);

extern int
do_hnum(Hsolve *hsolve, int comptno, int *hnum, int *elmnum);

extern int
do_hreset(Hsolve *hsolve);

extern int
do_hsolve(Hsolve *hsolve);

extern int
do_vm_update(Hsolve *hsolve);

extern int
duplicate_tables(Hsolve *hsolve);

extern int
h2_init(Hsolve *hsolve);

extern int
h_check_msgs(Hsolve *hsolve, Element *elm,
             int op, int comptno, int nop, int nchip);

extern int
h_delete(Hsolve *hsolve);

extern int
h_dospike_event(Hsolve *hsolve);

extern int
h_dosynchan(Hsolve *hsolve, int stabindex, int cindex);

extern int
h_failed(Hsolve *hsolve);

extern int
h_has_output(Element *elm);

extern int
h_hh_chip_init(Hsolve *hsolve);

extern int
h_hh_init(Hsolve *hsolve);

extern int
h_in_msgs(Hsolve *hsolve);

extern int
h_init(Hsolve *hsolve);

extern int
h_init_conc_chip(Hsolve *hsolve);

extern int
h_init_conc_solve(Hsolve *hsolve);

extern int
h_nernst_init(Hsolve *hsolve, Element *chan, Tcinfo *hentry);

extern int
h_out_msgs(Hsolve *hsolve);

extern int
h_rchip_change(Hsolve *hsolve, int field, int offset,
               double oldvalue, double newvalue);

extern int
h_setup_conc_solve(Hsolve *hsolve);

extern int
h_store_out(Hsolve *hsolve, int op, int comptno, int cindex);

extern int
hchild_compare(Hsolve *hsolve, int first, int sec);

extern int
hfind_elm(Hsolve *hsolve, Element *elm, int *comptno, int *cindex);

extern int
hget_elm(Hsolve *hsolve, int comptno, int cindex);

extern int
hput_elm(Hsolve *hsolve, int comptno, int cindex);

extern int
hstore_name(Hsolve *hsolve, Element *elm, int *nnames,
            char **names, char *elmname);

#endif  /* HINES_DECL_H */

