/*
 * FILE: compt_update.c
 *
 */

#include "hines_ext.h"

/* A simple function for putting data values back into elements */

int
do_compt_update(Hsolve *hsolve)
{
    struct  mod_compartment_type **compts;
    struct  mod_compartment_type *compt, *adj_compt;
    int     ncompts = hsolve->ncompts;
    int     i;
    int    *elmnum;
    double *results;
    double *v;
    double  Vm1, Ra1;
    Msg    *msg;

    compts  = (struct mod_compartment_type **)(hsolve->compts);
    elmnum  = hsolve->elmnum;
    results = hsolve->results;

    if (BaseObject(hsolve)->method == CRANK_INT)  /* CRANK NICOLSON */
    {
        for (i = 0; i < ncompts; i++)
        {
            compt = compts[elmnum[i]];
            v = &(compt->Vm);
            *v = 2.0 * results[i] - (*v);
        }
    }
    else  /* BEULER (backwards Euler) by default */
    {
        for (i = 0; i < ncompts; i++)
            compts[elmnum[i]]->Vm = results[i];
    }

    /*
     * This is a *very* nasty hack to calculate the approximate membrane
     * current for chanmode 0.  The idea is that if the Vm's are calculated
     * accurately, the difference in the instantaneous axial currents
     * is approximately equal to the current through the membrane.
     * This is probably not very accurate.  It was lifted from the
     * mod_compartment code.
     */

    for (i = 0; i < ncompts; i++)
    {
        compt = compts[elmnum[i]];
        compt->Im = 0.0;

        MSGLOOP(compt, msg)
        {
        case RAXIAL:  /* resistive axial */
            /*
             * 0 = Ra(n - 1)  1 = Vm(n - 1)
             */

            /* MSGVALUE doesn't work, for some reason. */

            /*
             * Vm1 = MSGVALUE(msg, 1);
             * Ra1 = MSGVALUE(msg, 0);
            */


            adj_compt = (struct mod_compartment_type *)(msg->src);
            Vm1 = adj_compt->Vm;
            Ra1 = adj_compt->Ra;

            /* inward positive current convention */
            compt->Im += (Vm1 - compt->Vm) / Ra1;

            break;


        case AXIAL:  /* non-resistive axial */
            /*
             * 0 = Vm(n + 1)
             */

            /* MSGVALUE doesn't work, for some reason. */
            /* Vm1 = MSGVALUE(msg, 0); */

            adj_compt = (struct mod_compartment_type *)(msg->src);
            Vm1 = adj_compt->Vm;

            /* inward positive current convention */
            compt->Im += (Vm1 - compt->Vm) / compt->Ra;

            break;


        case INJECT:  /* current injection */
            /*
             * 0 = inject
             */

            /* This probably doesn't work.  Use at your own risk. */
            compt->Im += MSGVALUE(msg, 0);

            break;
        }
    }

    return 0;
}


