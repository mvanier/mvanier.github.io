/*
 * FILE: hines_conc_4chip.c
 *
 */

#define CHANMODE4
#include "hines_conc_chip.c"
#undef CHANMODE4
