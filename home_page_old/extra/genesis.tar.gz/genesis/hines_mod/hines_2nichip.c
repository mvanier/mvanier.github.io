/*
 * FILE: hines_2nichip.c
 *
 */

/*
 * Defines variables to create do_chip_hh2noi_update(hsolve) function in
 * hines_chip.c
 *
 */

#include "hines_ext.h"
#include "hines_chip.c"
