/*
 * FILE: hh_init.c
 *
 */

#include "hines_ext.h"

/*
 * Fills up hh array according to hines numbering of parent compts,
 * and moves all vdep-channel tables into a colocated chunk so that
 * page swaps are (hopefully) minimized.
 */

/*
 * Fills up hh and chan linked lists according to hines numbering of parent
 * compartments.
 */

int
h_hh_init(Hsolve *hsolve)
{
    int       i;
    int       ncompts;
    int      *elmnum;
    Element **compts;
    Element  *compt;
    MsgIn    *msgin;
    Tcinfo  **hh = NULL;
    Tcinfo   *hentry;
    Cinfo   **chan;
    Cinfo    *centry;

    ncompts = hsolve->ncompts;
    compts  = hsolve->compts;
    elmnum  = hsolve->elmnum;

    if (hsolve->chanmode)
        hh = hsolve->hh = (Tcinfo **)calloc(ncompts, sizeof(Cinfo *));

    chan = hsolve->chan = (Cinfo **)calloc(ncompts, sizeof(Cinfo *));

    /* CHANNELs go from channels to compts */
    for (i = 0; i < ncompts; i++)
    {
        compt = compts[elmnum[i]];

        MSGLOOP(compt, msgin)
        {
            /* look for any channels */
        case CHANNEL:
            if (hsolve->chanmode
                && (strcmp(BaseObject(msgin->src)->name, "tabchannel") == 0))
            {
                /* chanmode 1: we compute tabchannels separately */
                hentry = (Tcinfo *) calloc(1, sizeof(Tcinfo));
                hentry->next = hh[i];
                hh[i] = hentry;
                hentry->chan = msgin->src;
                HsolveBlock(hentry->chan);

                if (h_nernst_init(hsolve, msgin->src, hentry))
                {
                    return ERR;
                }
            }
            else
            {
                centry       = (Cinfo *)calloc(1, sizeof(Cinfo));
                centry->next = chan[i];
                chan[i]      = centry;
                centry->chan = msgin->src;

                /*
                 * Save pointers to the Gk, Ek values in the message,
                 * which are the 0th and 1st arguments to the message
                 * (respectively).
                 *
                 * WARNING: the fields MUST have the correct types 
                 * (double for Gk, float for Ek) or they will probably
                 * generate garbage and/or a core dump.  
                 *
                 */

                centry->Gk   = (double *)(MSGPTR(msgin, 0));
                centry->Ek   = (float *)(MSGPTR(msgin, 1));
            }

            break;
        }
    }

    return 0;
}




/* Finds nernst element for channel (if present) */
int
h_nernst_init(Hsolve *hsolve, Element *chan, Tcinfo *hentry)
{
    MsgIn   *msgin;
    Element *nernst = NULL;
    MsgIn   *conc   = NULL;

    hentry->nernst = NULL;
    hentry->conc   = NULL;

    MSGLOOP(chan, msgin)
    {
    default:
        if (msgin->type == EK)
        {
            /* Make sure that we have a nernst element */
            if (strcmp(BaseObject(msgin->src)->name, "nernst") == 0)
            {
                nernst = msgin->src;
            }
            else
            {
                Error();
                printf(" during SETUP of %s: "
                       "EK message from unsupported object for %s\n",
                       Pathname(hsolve), Pathname(chan));

                return ERR;
            }
        }
        else if (msgin->type == CONCEN)
        {
            /* a concentration */
            conc = msgin;
        }
    }

    if (nernst)
    {
        if (hentry->nernst)
        {
            if ((Nernst *) nernst != hentry->nernst)
            {
                Error();
                printf(" during SETUP of %s: "
                       "more than one nernst element for %s\n",
                       Pathname(hsolve), Pathname(chan));

                return ERR;
            }
        }
        else
        {
            hentry->nernst = (Nernst *) nernst;
        }
    }

    if (conc)
    {
        if (hentry->conc)
        {
            if (conc != hentry->conc)
            {
                Error();
                printf(" during SETUP of %s: "
                       "more than one CONCEN msg for %s\n",
                       Pathname(hsolve), Pathname(chan));

                return ERR;
            }
        }
        else
        {
            hentry->conc = conc;
        }
    }

    return 0;
}


