/*
 * FILE: hines_4nichip.c
 *
 */

/*
 * Defines variables to create do_chip_hh4ni_update(hsolve) function in
 * hines_chip.c
 */

#include "hines_ext.h"
#define CHANMODE4
#include "hines_chip.c"
#undef CHANMODE4
