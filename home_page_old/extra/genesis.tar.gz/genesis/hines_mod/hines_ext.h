/*
 * FILE: hines_ext.h
 *
 */

#ifndef HINES_EXT_H
#define HINES_EXT_H

#include <stdio.h>
#include <string.h>
#include "sim_ext.h"
#include "conc_struct.h"
#include "dev_struct.h"

typedef struct nernst_type Nernst;

#include "hines_defs.h"
#include "hines_struct.h"
#include "olf_defs.h"
#include "olf_struct.h"
#include "seg_struct.h"
#include "array_utils.h"
#include "newconn_struct.h"
#include "piriform_struct.h"
#include "synaptic_event.h"

typedef struct channelC3_type Schan;
typedef struct Synchan_type   S2chan;
typedef struct Spikegen_type  Spike;
typedef struct Ca_concen_type Concen;
typedef struct ghk_type       Ghk;
typedef struct Mg_block_type  Mblock;

/*
 * Support for neuromodulated compartments.
 */

#define MAX_NEUROMODULATED 100         /* From piriform/piriform_ext.h */
extern double nm[MAX_NEUROMODULATED];


/*
 * Declarations for functions used in multiple files.
 */

#include "hines_decls.h"


#endif  /* HINES_EXT_H */

