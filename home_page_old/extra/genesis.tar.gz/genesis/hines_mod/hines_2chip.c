/*
 * FILE: hines_2chip.c
 *
 */


/*
 * Defines variables to create do_chip_hh2_update(hsolve) function in
 * hines_chip.c
 *
 */

#include "hines_ext.h"
#define SOLVEINTERPOL        /* interpolation for tabchannels */
#include "hines_chip.c"
#undef SOLVEINTERPOL
