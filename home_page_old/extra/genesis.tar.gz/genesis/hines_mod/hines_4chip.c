/*
 * FILE: hines_4chip.c
 *
 */


/*
 * Defines variables to create do_chip_hh4_update(hsolve) function in
 * hines_chip.c
 */

#include "hines_ext.h"
#define CHANMODE4
#define SOLVEINTERPOL        /* interpolation for tabchannels */
#include "hines_chip.c"
#undef CHANMODE4
#undef SOLVEINTERPOL
