/*
 * my_stdlib.h: use this because the Red Hat stdlib.h
 * is buggered wrt its gcc implementation.
 */

extern double atof(const char *nptr);
extern int    atoi(const char *nptr);
extern int    putenv(const char *string);
extern void  *malloc(size_t size);
extern void  *calloc(size_t nmemb, size_t size);
extern void   free(void *ptr);
extern void  *realloc(void *ptr, size_t size);


