
#include 	<stdio.h>
#include 	<math.h>
#include	<X11/Xlib.h>
#include 	"header.h"
#include 	"xplot_defs.h"
#include 	"xplot_struct.h"

int debug;
Graph *G;
Frame *F;
