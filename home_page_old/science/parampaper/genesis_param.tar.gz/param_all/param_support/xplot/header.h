#define INVALID    0
#define CHAR    1
#define SHORT    2
#define INT    3
#define FLOAT    4
#define DOUBLE    5
#define FUNC    6
#define FFUNC    7

#ifndef TRUE
#define TRUE    1
#define FALSE    0
#endif

#define arg_is(s)    (strcmp(argv[nxtarg],s) == 0)
#define iarg()    (atoi(argv[++nxtarg]))
#define farg()    (atof(argv[++nxtarg]))
#define arg_starts_with(c)    (argv[nxtarg][0] == c)

/* This croaks on gcc 2.95.1 for stupid reasons: */
/* long int random(void); */

#define MAXLONG            2147483641L
#define frandom(l,h)    (((float)random()/MAXLONG)*((h)-(l))+(l))
#define falloc(n,t)   (t*)malloc((unsigned)((n)*sizeof(t)))
#define MAX(x,y)    ((x) > (y) ? (x) : (y))
#define MIN(x,y)    ((x) < (y) ? (x) : (y))
#define SQR(x)        ((x)*(x))

#ifdef SYSV
#define bcopy(s1, s2, length) (int)memcpy(s2, s1, length)
#endif

typedef int (*PFI) ();
